import os
import sys
import json
import datetime
import pathlib
import time
import cv2
import carla
from collections import deque
import math
from collections import OrderedDict
from transformers import AutoModel, AutoConfig
import torch
import torch
import carla
import numpy as np
from PIL import Image
from torchvision import transforms as T

from leaderboard.autoagents import autonomous_agent

from Greg.model import Greg, RSSMBelief
from Greg.config import GlobalConfig
from team_code.planner import RoutePlanner
from scipy.optimize import fsolve
from dotenv import load_dotenv

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from BlackOut import BlackOut

load_dotenv()

SAVE_PATH = "./saved_data"
IS_BENCH2DRIVE = True
PLANNER_TYPE = 'only_ctrl'
ORIGINAL = os.environ.get("EVAL_ORIGINAL", "False") == "True"

RL_CKPT = os.environ["RL_CKPT"]

# --- Decimation / action-repeat (5 Hz training regime) ---
# The live rollout agent decimates the WHOLE loop to 5 Hz: the policy is
# sampled every DECISION_EVERY frames and BOTH steer and accel are held across the block. That
# holds the full action, not just acceleration.
#
# TRAIN_DECISION_EVERY: the training macro-step. MUST match the rollout agent's DECISION_EVERY.
#   It never gates eval control; it is the TEMPORAL SPACING the RSSM history must have, because the
#   dynamics model only ever saw transitions this far apart. Must track the active learner/rollout
#   training cadence.
TRAIN_DECISION_EVERY = 4

# EVAL_DECISION_EVERY: 1 = decide every frame; TRAIN_DECISION_EVERY = hold the control between
#   decisions, matching the training cadence exactly.
EVAL_DECISION_EVERY = 1

assert TRAIN_DECISION_EVERY % EVAL_DECISION_EVERY == 0, \
    "EVAL_DECISION_EVERY must divide TRAIN_DECISION_EVERY so the RSSM history keeps its trained spacing"
BURNIN_RING_STRIDE = TRAIN_DECISION_EVERY // EVAL_DECISION_EVERY

WARMUP_FRAMES = 51

SWITCH_TURN_IL = os.environ.get("EVAL_SWITCH_TURN_IL", "False") == "True"
TURN_COMMANDS = (0, 1)

THROTTLE_CAP = 0.75
CREEP_ESCAPE = True
CREEP_STALL_FRAMES = 800
CREEP_FORCE_FRAMES = 20

RSSM_BURNIN_K = 16
RSSM_BURNIN_L = RSSM_BURNIN_K - 1
RSSM_OBS_DIM = 512 + 10        # [frozen IL embedding, 10-d route scalars]
RSSM_DETER_DIM = 256
RSSM_STOCH_GROUPS = 16
RSSM_STOCH_CLASSES = 16
RSSM_HIDDEN = 512
RSSM_UNIMIX = 0.01

STOP_SPEED_THRESH = 0.1
STOP_MEMORY_CAP = 10.0
STOP_TICK_DT = 0.05
print('*'*10)
print(PLANNER_TYPE)
print('*'*10)

EARTH_RADIUS_EQUA = 6378137.0

Discrete_Actions_DICT = {
	0:  (0, 1, False),
	1:  (0.0, 0, False),
	2: (0.3, 0, False),
	3: (0.7, 0.0, False),
	4: (1.0, 0, False),
	5: (0.5, 0, True),
	}


def get_entry_point():
	return 'GregAgent'


class GregAgent(autonomous_agent.AutonomousAgent):
    def setup(self, path_to_conf_file):
        self.track = autonomous_agent.Track.SENSORS
        self.steer_step = 0
        self.last_moving_status = 0
        self.last_moving_step = -1
        self.last_steers = deque()
        if IS_BENCH2DRIVE:
            self.save_name = path_to_conf_file.split('+')[-1]
            self.config_path = path_to_conf_file.split('+')[0]
        else:
            self.config_path = path_to_conf_file
            self.save_name = '_'.join(map(lambda x: '%02d' % x, (now.month, now.day, now.hour, now.minute, now.second)))
        self.step = -1
        self.wall_start = time.time()
        self.initialized = False

        # BlackOut camera corruption: off unless GREG_BLACKOUT_LEVEL is set (see queue_eval.py's
        # --blackout flag / BlackOut/README.md). EVAL_ROUTE_ID (set by queue_eval.py) is the
        # per-route key that deterministically picks which corruption family this route gets;
        # falls back to save_name so a manual (non-queue) run still gets a stable, if arbitrary, key.
        self.blackout = BlackOut.from_env()
        self.blackout.new_episode(os.environ.get('EVAL_ROUTE_ID', self.save_name))

        self.config = GlobalConfig()

        self.pid_metadata = {}

        my_hf_token = os.environ.get("HF_TOKEN")

        pretrained_model_name = "facebook/dinov3-vitl16-pretrain-lvd1689m"
        custom_cache_path = "./dinov3_large_cache"
        vit_config = AutoConfig.from_pretrained(
            pretrained_model_name,
            token=my_hf_token,
            cache_dir=custom_cache_path
        )
        vit_base = AutoModel.from_config(vit_config)

        self.net = Greg(self.config, vit_base_model=vit_base)

        
        
        ckpt = torch.load(self.config_path, map_location="cuda")
        ckpt = ckpt["state_dict"]
        new_state_dict = OrderedDict()
        
        for key, value in ckpt.items():
            # Chain the replacements to scrub BOTH prefixes
            new_key = key.replace("model.", "").replace("_orig_mod.", "")
            new_state_dict[new_key] = value
            
        # RL-only modules are zero-init / identity-at-init and are absent from the IL checkpoint:
        # route_adapter, policy_adapters, embed_denoiser, belief_proj (RSSM read-in). Anything else
        # missing means a real model/checkpoint mismatch -> fail loud.
        il_missing, il_unexpected = self.net.load_state_dict(new_state_dict, strict=False)
        assert all(('route_adapter' in k) or ('policy_adapters' in k) or ('embed_denoiser' in k)
                   or ('belief_proj' in k)
                   for k in il_missing), \
            f"unexpected IL missing keys: {il_missing}"
        assert not il_unexpected, f"unexpected IL extra keys: {il_unexpected}"
        # --- RSSM recurrent belief for eval (fixed-window burn-in) ---
        # The trained actor consumes belief = q(z | h, [emb, route]) via belief_proj; eval must
        # feed the same 5 Hz-spaced K-frame context even though it queries control at 20 Hz.
        # Deterministic eval uses the MODE z (sample=False). ORIGINAL (pure-IL) eval keeps
        # belief=None: belief_proj is absent from the IL checkpoint, so it stays zero (a no-op).
        self.rssm = None
        if not ORIGINAL:
            print(f"Loading RL weights from {RL_CKPT} ...")
            RL_ckpt = torch.load(RL_CKPT, map_location="cuda")
            if 'policy_net_state_dict' in RL_ckpt:
                # sac_checkpoint_*.pth: trainable policy + separate rssm_state_dict key.
                policy_sd = RL_ckpt['policy_net_state_dict']
                rssm_sd = RL_ckpt.get('rssm_state_dict', None)
                rssm_burnin_k = RL_ckpt.get('rssm_burnin_k', None)
            else:
                # latest_actor.pth: flat trainable dict; RSSM + its burn-in metadata ride along as
                # two extra keys. Copy before popping so the loaded object remains inspectable.
                policy_sd = dict(RL_ckpt)
                rssm_sd = policy_sd.pop('rssm_state_dict', None)
                rssm_burnin_k = policy_sd.pop('rssm_burnin_k', None)
            rl_missing, rl_unexpected = self.net.load_state_dict(policy_sd, strict=False)
            assert not rl_unexpected, f"unexpected RL extra keys: {rl_unexpected}"
            print(f"Loaded RL weights ({len(policy_sd)} tensors).")
            if rssm_sd is not None:
                # The unroll length is not encoded in GRU tensor shapes, so checkpoints stamp K.
                # Never silently evaluate with a different recurrent history from the one the
                # actor was trained on.
                checkpoint_burnin_k = 4 if rssm_burnin_k is None else int(rssm_burnin_k)
                if checkpoint_burnin_k != RSSM_BURNIN_K:
                    raise RuntimeError(
                        f"RSSM burn-in mismatch: checkpoint K={checkpoint_burnin_k}, "
                        f"test agent K={RSSM_BURNIN_K}")
                self.rssm = RSSMBelief(embed_dim=RSSM_OBS_DIM, action_dim=7,
                                       deter_dim=RSSM_DETER_DIM, stoch_groups=RSSM_STOCH_GROUPS,
                                       stoch_classes=RSSM_STOCH_CLASSES, hidden=RSSM_HIDDEN,
                                       unimix=RSSM_UNIMIX).cuda()
                # latest_actor.pth omits the learner-only safety_horizon_head, which the acting
                # filter never uses; every dynamics key must still match.
                rssm_missing, rssm_unexpected = self.rssm.load_state_dict(rssm_sd, strict=False)
                bad_rssm_missing = {
                    key for key in rssm_missing
                    if not key.startswith('safety_horizon_head.')
                }
                if bad_rssm_missing or rssm_unexpected:
                    raise RuntimeError(
                        f"Unexpected RSSM weight mismatch: missing={sorted(bad_rssm_missing)}, "
                        f"unexpected={sorted(rssm_unexpected)}")
                self.rssm.eval()
                print(f"Loaded RSSM (recurrent K={RSSM_BURNIN_K} belief active for eval).")
            else:
                print("No rssm_state_dict in checkpoint -> belief-less eval (pre-RSSM policy).")

        self.net.cuda()
        self.net.eval()

        self.action_queue_size = 10
        self.action_queue = deque(maxlen=self.action_queue_size)
        for i in range(self.action_queue_size):
            self.action_queue.append(torch.tensor([0.5, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0]).cuda())
        self.creeping_cnt = 0
        self.force_move = 0
        self.cnt = 0

        self._frame_hist = deque(maxlen=BURNIN_RING_STRIDE * RSSM_BURNIN_L)
        self.decimation_frame = 0
        self._held_control = None

        self.takeover = False
        self.stop_time = 0
        self.takeover_time = 0

        self.save_path = None
        self._im_transform = T.Compose([T.ToTensor(), T.Normalize(mean=[0.485,0.456,0.406], std=[0.229,0.224,0.225])])

        self.last_steers = deque()
        if SAVE_PATH is not None:
            string = self.save_name
            print (string)

            self.save_path = pathlib.Path(os.environ['SAVE_PATH']) / string
            self.save_path.mkdir(parents=True, exist_ok=False)

            (self.save_path / 'rgb').mkdir()
            (self.save_path / 'rgb_front').mkdir()
            (self.save_path / 'meta').mkdir()
            (self.save_path / 'bev').mkdir()

    def _belief_for(self, obs):
        if self.rssm is None:
            return None
        if RSSM_BURNIN_L > 0 and len(self._frame_hist) >= BURNIN_RING_STRIDE:
            hist = list(self._frame_hist)
            # hist[-1] is the PREVIOUS decision, because the current one is appended only after its
            # control is settled. So the frame TRAIN_DECISION_EVERY frames back is hist[-stride],
            # not hist[-1]. Use all available correctly-spaced history near episode start, up to the
            # fixed K-1 window — equivalent to the learner's front-pad-with-mask-0 windows.
            available = min(RSSM_BURNIN_L, len(hist) // BURNIN_RING_STRIDE)
            frames = [hist[-k * BURNIN_RING_STRIDE] for k in range(available, 0, -1)]
            h = self.rssm.burn_in(torch.stack([f[0] for f in frames], dim=1),
                                  torch.stack([f[1] for f in frames], dim=1))
        else:
            h = self.rssm.initial(obs.shape[0], obs.device)   # episode start: window not filled yet
        belief, _ = self.rssm.posterior_belief(h, obs, sample=False)
        return belief

    def _record_frame(self, obs, action):
        if self.rssm is None or RSSM_BURNIN_L == 0:
            return
        self._frame_hist.append((obs, action[:, :-1].detach().float()))

    def _init(self):
        try:
            locx, locy = self._global_plan_world_coord[0][0].location.x, self._global_plan_world_coord[0][0].location.y
            lon, lat = self._global_plan[0][0]['lon'], self._global_plan[0][0]['lat']
            E = EARTH_RADIUS_EQUA
            def equations(vars):
                x, y = vars
                eq1 = lon * math.cos(x * math.pi / 180) - (locx * x * 180) / (math.pi * E) - math.cos(x * math.pi / 180) * y
                eq2 = math.log(math.tan((lat + 90) * math.pi / 360)) * E * math.cos(x * math.pi / 180) + locy - math.cos(x * math.pi / 180) * E * math.log(math.tan((90 + x) * math.pi / 360))
                return [eq1, eq2]
            initial_guess = [0, 0]
            solution = fsolve(equations, initial_guess)
            self.lat_ref, self.lon_ref = solution[0], solution[1]
        except Exception as e:
            print(e, flush=True)
            self.lat_ref, self.lon_ref = 0, 0
        print(self.lat_ref, self.lon_ref, self.save_name)
        #
        self._route_planner = RoutePlanner(4.0, 50.0, lat_ref=self.lat_ref, lon_ref=self.lon_ref)
        self._route_planner.set_route(self._global_plan, True)
        # Camera-only stop-sign memory: seconds since the ego last fully stopped (reset per episode).
        self.time_since_full_stop = 0.0
        self.initialized = True
        self.metric_info = {}

    def sensors(self):
        sensors =  [
                {
                    'type': 'sensor.camera.rgb',
                    'x': 0.80, 'y': 0.0, 'z': 1.60,
                    'roll': 0.0, 'pitch': 0.0, 'yaw': 0.0,
                    'width': 1600, 'height': 900, 'fov': 70,
                    'id': 'CAM_FRONT'
                },
                {
                    'type': 'sensor.camera.rgb',
                    'x': 0.27, 'y': -0.55, 'z': 1.60,
                    'roll': 0.0, 'pitch': 0.0, 'yaw': -55.0,
                    'width': 1600, 'height': 900, 'fov': 70,
                    'id': 'CAM_FRONT_LEFT'
                },
                {
                    'type': 'sensor.camera.rgb',
                    'x': 0.27, 'y': 0.55, 'z': 1.60,
                    'roll': 0.0, 'pitch': 0.0, 'yaw': 55.0,
                    'width': 1600, 'height': 900, 'fov': 70,
                    'id': 'CAM_FRONT_RIGHT'
                },
                {
                    'type': 'sensor.camera.rgb',
                    'x': -2.0, 'y': 0.0, 'z': 1.60,
                    'roll': 0.0, 'pitch': 0.0, 'yaw': 180.0,
                    'width': 1600, 'height': 900, 'fov': 110,
                    'id': 'CAM_BACK'
                },
                {
                    'type': 'sensor.camera.rgb',
                    'x': -0.32, 'y': -0.55, 'z': 1.60,
                    'roll': 0.0, 'pitch': 0.0, 'yaw': -110.0,
                    'width': 1600, 'height': 900, 'fov': 70,
                    'id': 'CAM_BACK_LEFT'
                },
                {
                    'type': 'sensor.camera.rgb',
                    'x': -0.32, 'y': 0.55, 'z': 1.60,
                    'roll': 0.0, 'pitch': 0.0, 'yaw': 110.0,
                    'width': 1600, 'height': 900, 'fov': 70,
                    'id': 'CAM_BACK_RIGHT'
                },
                {
                    'type': 'sensor.other.imu',
                    'x': -1.4, 'y': 0.0, 'z': 0.0,
                    'roll': 0.0, 'pitch': 0.0, 'yaw': 0.0,
                    'sensor_tick': 0.05,
                    'id': 'IMU'
                },
                {
                    'type': 'sensor.other.gnss',
                    'x': -1.4, 'y': 0.0, 'z': 0.0,
                    'roll': 0.0, 'pitch': 0.0, 'yaw': 0.0,
                    'sensor_tick': 0.01,
                    'id': 'GPS'
                },
                {
                    'type': 'sensor.speedometer',
                    'reading_frequency': 20,
                    'id': 'SPEED'
                },
        ]
        if IS_BENCH2DRIVE:
            sensors += [
                    {   
                        'type': 'sensor.camera.rgb',
                        'x': 0.0, 'y': 0.0, 'z': 50.0,
                        'roll': 0.0, 'pitch': -90.0, 'yaw': 0.0,
                        'width': 512, 'height': 512, 'fov': 5 * 10.0,
                        'id': 'bev'
                    }]
        return sensors

    def tick(self, input_data):
        self.step += 1
        input_data = self.blackout.apply_carla(input_data)

        def process_cell(cam_id):
            img = cv2.cvtColor(input_data[cam_id][1][:, :, :3], cv2.COLOR_BGR2RGB)
            return cv2.resize(img, (298, 256))

        fl = process_cell('CAM_FRONT_LEFT')
        f  = process_cell('CAM_FRONT')
        fr = process_cell('CAM_FRONT_RIGHT')
        bl = process_cell('CAM_BACK_LEFT')
        b  = process_cell('CAM_BACK')
        br = process_cell('CAM_BACK_RIGHT')

        top_row = np.concatenate((fl, f, fr), axis=1)
        bottom_row = np.concatenate((bl, b, br), axis=1)
        full_grid = np.concatenate((top_row, bottom_row), axis=0)

        rgb = cv2.resize(full_grid, (896, 512))

        rgb_front = cv2.cvtColor(input_data['CAM_FRONT'][1][:, :, :3], cv2.COLOR_BGR2RGB)

        bev = cv2.cvtColor(input_data['bev'][1][:, :, :3], cv2.COLOR_BGR2RGB)
        gps = input_data['GPS'][1][:2]
        speed = input_data['SPEED'][1]['speed']
        compass = input_data['IMU'][1][-1]

        if math.isnan(compass):
            compass = 0.0

        result = {
                'rgb': rgb,
                'rgb_front': rgb_front,
                'gps': gps,
                'speed': speed,
                'compass': compass,
                'bev': bev
                }
        pos = self.gps_to_location(result['gps'])
        result['gps'] = pos
        next_wp, next_cmd = self._route_planner.run_step(pos)
        result['next_command'] = next_cmd.value
        theta = compass - np.pi/2
        R = np.array([
            [np.cos(theta), np.sin(theta)],
            [-np.sin(theta),  np.cos(theta)]
            ])

        local_command_point = np.array([next_wp[0]-pos[0], next_wp[1]-pos[1]])
        local_command_point = R.dot(local_command_point)
        result['target_point'] = tuple(local_command_point)

        return result

    @torch.no_grad()
    def run_step(self, input_data, timestamp):
        if not self.initialized:
            self._init()
        tick_data = self.tick(input_data)
        print(f"Step: {self.step}")
        if self.step < self.config.seq_len:
            rgb = self._im_transform(tick_data['rgb']).unsqueeze(0)

            control = carla.VehicleControl()
            control.steer = 0.0
            control.throttle = 0.0
            control.brake = 0.0
            
            return control

        gt_velocity = torch.FloatTensor([tick_data['speed']]).to('cuda', dtype=torch.float32)
        command = tick_data['next_command']
        if command < 0:
            command = 4
        command -= 1
        assert command in [0, 1, 2, 3, 4, 5]
        cmd_one_hot = [0] * 6
        cmd_one_hot[command] = 1
        cmd_one_hot = torch.tensor(cmd_one_hot).view(1, 6).to('cuda', dtype=torch.float32)
        speed = torch.FloatTensor([float(tick_data['speed'])]).view(1,1).to('cuda', dtype=torch.float32)
        speed = speed / 12
        rgb = self._im_transform(tick_data['rgb']).unsqueeze(0).to('cuda', dtype=torch.float32)

        tick_data['target_point'] = [torch.FloatTensor([tick_data['target_point'][0]]),
                                        torch.FloatTensor([tick_data['target_point'][1]])]
        target_point = torch.stack(tick_data['target_point'], dim=1).to('cuda', dtype=torch.float32)
        state = torch.cat([speed, target_point, cmd_one_hot], 1)
        ego_speed_ms = float(tick_data['speed'])
        if ego_speed_ms < STOP_SPEED_THRESH:
            self.time_since_full_stop = 0.0
        else:
            self.time_since_full_stop = min(self.time_since_full_stop + STOP_TICK_DT, STOP_MEMORY_CAP)
        stop_mem = torch.tensor([[self.time_since_full_stop / STOP_MEMORY_CAP]], device='cuda', dtype=torch.float32)
        route_full = torch.cat([state, stop_mem], dim=1)   # 10-d


        action_queue_tensor = torch.vstack(list(self.action_queue)).flatten().unsqueeze(0)

        pred= self.net(rgb, state, target_point)

        steer_ctrl, throttle_ctrl, brake_ctrl, reverse_ctrl, metadata = self.net.process_action(pred, tick_data['next_command'], gt_velocity, target_point)

        steer_traj, throttle_traj, brake_traj, metadata_traj = self.net.control_pid(pred['pred_wp'], gt_velocity, target_point)


        
        self.cnt += 1
        if self.cnt < WARMUP_FRAMES or (SWITCH_TURN_IL and command in TURN_COMMANDS):
            pass
        else:
            is_decision = (self.decimation_frame % EVAL_DECISION_EVERY == 0)
            self.decimation_frame += 1
            if is_decision:
                rssm_obs = torch.cat([pred['join_ctrl_inp'], route_full], dim=1)
                belief_t = self._belief_for(rssm_obs)
                action, log_prob, entropy = self.net.get_actionrl(
                    pred['join_ctrl_inp'], deterministic=True, route=route_full, belief=belief_t)
                self._record_frame(rssm_obs, action)

                action_buffer = action[:,:-1]
                action = torch.cat([action[:,0].unsqueeze(-1),action[:,-1].unsqueeze(-1)], dim=1)
                action = action.detach().cpu()

                self.action_queue.append(action_buffer[0].detach())

                action = action.numpy().squeeze()
                steer_ctrl, throttle_ctrl  = action.tolist()
                throttle_ctrl, brake_ctrl, reverse_ctrl = Discrete_Actions_DICT[throttle_ctrl]
                steer_ctrl = steer_ctrl*2 - 1
                self._held_control = (steer_ctrl, throttle_ctrl, brake_ctrl, reverse_ctrl)
            elif self._held_control is not None:
                steer_ctrl, throttle_ctrl, brake_ctrl, reverse_ctrl = self._held_control

        if self.cnt < 30:
            brake_ctrl = 1
            throttle_ctrl = 0

        control = carla.VehicleControl()
        if not PLANNER_TYPE: 
            raise 'please set PLANNER_TYPE'
        if PLANNER_TYPE == 'only_traj':
            self.pid_metadata = metadata
            self.pid_metadata['agent'] = 'only_traj'
            control.steer = np.clip(float(steer_traj), -1, 1)
            control.throttle = np.clip(float(throttle_traj), 0, 0.75)
            control.brake = np.clip(float(brake_traj), 0, 1)

        elif PLANNER_TYPE == 'only_ctrl':
            self.pid_metadata = metadata
            self.pid_metadata['agent'] = 'only_ctrl'
            control.steer = np.clip(float(steer_ctrl), -1, 1)
            control.throttle = np.clip(float(throttle_ctrl), 0, 1.0)
            control.brake = np.clip(float(brake_ctrl), 0, 1)
            control.reverse = True if reverse_ctrl else False
        elif PLANNER_TYPE == 'merge_ctrl_traj':
            # traj only using when brake
            self.pid_metadata = metadata
            self.pid_metadata['agent'] = 'merge_ctrl_traj'
            self.alpha = 0.5
            control.steer = np.clip(self.alpha*steer_traj + (1-self.alpha)*steer_ctrl, -1, 1)
            control.throttle = np.clip(self.alpha*throttle_traj + (1-self.alpha)*throttle_ctrl, 0, 0.75)
            control.brake = max(np.clip(float(brake_ctrl), 0, 1), np.clip(float(brake_traj), 0, 1))

        self.pid_metadata['steer_ctrl'] = float(steer_ctrl)
        self.pid_metadata['steer_traj'] = float(steer_traj)
        self.pid_metadata['throttle_ctrl'] = float(throttle_ctrl)
        self.pid_metadata['throttle_traj'] = float(throttle_traj)
        self.pid_metadata['brake_ctrl'] = float(brake_ctrl)
        self.pid_metadata['brake_traj'] = float(brake_traj)

        if THROTTLE_CAP is not None and self.rssm is None and ORIGINAL:
            if abs(control.steer) > 0.07:
                speed_threshold = 7.0
            else:
                speed_threshold = 8.0
            if float(tick_data['speed']) > speed_threshold:
                max_throttle = 0.0
            else:
                max_throttle = THROTTLE_CAP
            control.throttle = np.clip(control.throttle, a_min=0.0, a_max=max_throttle)

        if CREEP_ESCAPE:
            if tick_data['speed']<0.1:
                self.creeping_cnt +=1
            else:
                self.creeping_cnt =0

            if self.creeping_cnt>CREEP_STALL_FRAMES:

                self.force_move = CREEP_FORCE_FRAMES
            if self.force_move>0:
                print('it is creepy=0')
                self.force_move -= 1
                control.brake = 0.0
                control.throttle = 0.4


        self.pid_metadata['steer'] = control.steer
        self.pid_metadata['throttle'] = control.throttle
        self.pid_metadata['brake'] = control.brake
        metric_info = self.get_metric_info()
        self.metric_info[self.step] = metric_info
        if SAVE_PATH is not None and self.step % 1 == 0:
            self.save(tick_data)
        return control

    def save(self, tick_data):
        frame = self.step

        Image.fromarray(tick_data['rgb_front']).save(self.save_path / 'rgb_front' / ('%04d.png' % frame))

        Image.fromarray(tick_data['bev']).save(self.save_path / 'bev' / ('%04d.png' % frame))

        outfile = open(self.save_path / 'meta' / ('%04d.json' % frame), 'w')
        json.dump(self.pid_metadata, outfile, indent=4)
        outfile.close()

        # metric info
        outfile = open(self.save_path / 'metric_info.json', 'w')
        json.dump(self.metric_info, outfile, indent=4)
        outfile.close()

    def destroy(self):
        del self.net
        torch.cuda.empty_cache()

    def gps_to_location(self, gps):
        lat, lon = gps
        scale = math.cos(self.lat_ref * math.pi / 180.0)
        my = math.log(math.tan((lat+90) * math.pi / 360.0)) * (EARTH_RADIUS_EQUA * scale)
        mx = (lon * (math.pi * EARTH_RADIUS_EQUA * scale)) / 180.0
        y = scale * EARTH_RADIUS_EQUA * math.log(math.tan((90.0 + self.lat_ref) * math.pi / 360.0)) - my
        x = mx - scale * self.lon_ref * math.pi * EARTH_RADIUS_EQUA / 180.0
        return np.array([x, y])
