# team_agent

`test_GREG.py` is the CARLA leaderboard `AutonomousAgent` entry point for GREG
(`get_entry_point() -> 'GregAgent'`) — loads the IL checkpoint, optionally overlays an RL
checkpoint (`RL_CKPT` env var), and runs the DINOv3+Greg+RSSM policy at inference time.

- `Greg/` — a copy of `../Greg_RL/GREG_RL_worker/Greg`, kept in sync (`model.py`, `config.py`, `data.py`,
  `resnet.py`, `augment.py`).
- `team_code/planner.py` — `RoutePlanner`.

## Framework dependency (not bundled)
`test_GREG.py` imports `from leaderboard.autoagents import autonomous_agent`. Put
`../Greg_RL/GREG_RL_worker/leaderboard` and `.../scenario_runner` (or a Bench2Drive/leaderboard
checkout) on `PYTHONPATH` to run this agent.

## Configuration (`.env`)
`test_GREG.py` calls `load_dotenv()`, which stops at the first `.env` it finds — both vars below
must live in **this folder's** `.env` (copy `.env.example`), not just the repo root one.
- `RL_CKPT` — which RL checkpoint to evaluate. Required; the script raises `KeyError` if unset.
- `HF_TOKEN` — Hugging Face token for the DINOv3 backbone.

## Inference precision (`GREG_PRECISION`, `GREG_ATTN`)
The agent runs the DINOv3 backbone in bfloat16 with PyTorch's fused scaled-dot-product
attention, which is the configuration the reported control-loop frame rate is measured in.
Only the backbone is cast; the control heads, the policy and the RSSM stay in fp32, and
boundary hooks cast the image in and the features back out.

- `GREG_PRECISION` (default `bf16`) accepts `bf16` or `fp32`.
- `GREG_ATTN` (default `sdpa`) accepts any `attn_implementation` transformers supports,
  e.g. `eager` to restore the stock kernel.

`fp16` is rejected on purpose. DINOv3's hidden states carry massive activations, peaking near
1.5e5 from the first block, which is well outside the fp16 range (max 65504): the backbone
overflows to inf on layer 1 and every downstream value becomes NaN. bfloat16 has the same
exponent range as fp32 and runs at the same tensor-core speed.

## `checkpoints/` (gitignored)
Holds `.pth`/`.ckpt` files fetched from training machines for local evaluation.

## Single-route testing (`run_test_route.sh`)
Runs one route through `leaderboard_evaluator.py`, pinned to one GPU/port:
```bash
./run_test_route.sh [routes_subset_id]
```
Needs `CARLA_ROOT`, `GREG_IL_CKPT`, `RL_CKPT`, `B2D_ROOT` in `.env` (`B2D_ROOT` points at a
`git clone https://github.com/Thinklab-SJTU/Bench2Drive.git` checkout — gitignored, not vendored).

Framework-agnostic by design — no scenario-set-specific script. `FRAMEWORK_ROOT`/`ROUTES` default
to Bench2Drive (`$B2D_ROOT`) but are placeholders you can point elsewhere, e.g. to run against
`Agile/`'s scenario set instead:
```bash
FRAMEWORK_ROOT=$FRAMEWORK_ROOT \
ROUTES=$FRAMEWORK_ROOT/leaderboard/data/main/Agile.xml \
./run_test_route.sh 31
```
`SCENARIO_RUNNER_ROOT`/`LEADERBOARD_ROOT` derive from `FRAMEWORK_ROOT` by default and can also be
set independently if a framework's layout doesn't match `<root>/scenario_runner`,
`<root>/leaderboard`.

## Parallel evaluation (`eval/`)
`eval/queue_eval.py` runs a shared work queue against a fixed pool of GPU "slots"
(`--slots-per-gpu`, default 2 per GPU):

```bash
python3 eval/queue_eval.py                      # every route in the dev10 set, all detected GPUs
python3 eval/queue_eval.py --route-ids 3514,3255 --gpus 0,2 --slots-per-gpu 2
```

Key flags: `--routes-file`, `--route-ids` (comma-separated subset), `--gpus`, `--slots-per-gpu`,
`--max-retries` (default 3), `--timeout` (per-attempt wall-clock seconds, default 1800), `--out-dir`
(default `eval_results/<timestamp>/`, gitignored), `--gpu-adapter-map` (override CARLA's
`-graphicsadapter` mapping if it doesn't match the physical GPU index 1:1 on a given machine, e.g.
`--gpu-adapter-map 1:3,4:6`). `queue_eval.py` spawns `run_single_route.sh` per attempt and forwards
its own environment, so the same `EVAL_FRAMEWORK_ROOT` placeholder from `run_test_route.sh` applies
here too — export it before invoking `queue_eval.py` to run against a different scenario set.

A route only counts as a final result once `leaderboard_evaluator.py` actually evaluated the
agent's driving; a run that fails for an infra reason (agent setup exception, CARLA crash, hung
past timeout, ...) is requeued instead — see the module docstring in `eval/queue_eval.py` for the
exact classification rules.

Output layout per run: `eval_results/<timestamp>/summary.json` (per-route final status/score plus
retry counts), `eval_results/<timestamp>/attempts/r<route>_a<attempt>.json` (+ `.log`).
