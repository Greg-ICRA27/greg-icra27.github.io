#!/bin/bash
# Runs a single Bench2Drive route in its own CARLA instance, on a caller-chosen port/GPU slot.
# Not meant to be invoked directly -- queue_eval.py spawns one of these per route.
# EVAL_ADAPTER: Vulkan device-enumeration index, NOT guaranteed to equal EVAL_GPU (CUDA/nvidia-smi
# index) -- wrong value manifests as CarlaUE4 segfaulting with "GameThread timed out ...".

: "${EVAL_ROUTE_ID:?EVAL_ROUTE_ID not set}"
: "${EVAL_PORT:?EVAL_PORT not set}"
: "${EVAL_TM_PORT:?EVAL_TM_PORT not set}"
: "${EVAL_GPU:?EVAL_GPU not set}"
: "${EVAL_ADAPTER:?EVAL_ADAPTER not set}"
: "${EVAL_CHECKPOINT:?EVAL_CHECKPOINT not set}"
: "${EVAL_RUN_NAME:?EVAL_RUN_NAME not set}"

source ~/miniconda3/bin/activate
conda activate greg_rl

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )/.." && pwd )"
set -a
[ -f "$SCRIPT_DIR/.env" ] && source "$SCRIPT_DIR/.env"
set +a
: "${CARLA_ROOT:?Set CARLA_ROOT in $SCRIPT_DIR/.env}"
: "${GREG_IL_CKPT:?Set GREG_IL_CKPT in $SCRIPT_DIR/.env}"
RL_CKPT="${EVAL_RL_CKPT:-$RL_CKPT}"
: "${RL_CKPT:?Set RL_CKPT in $SCRIPT_DIR/.env or pass EVAL_RL_CKPT}"
export RL_CKPT
: "${B2D_ROOT:?Set B2D_ROOT in $SCRIPT_DIR/.env (clone: git clone https://github.com/Thinklab-SJTU/Bench2Drive.git)}"

# Framework root (scenario_runner + leaderboard package) for this run. Defaults to Bench2Drive;
# override to evaluate against a different route/scenario set (e.g. EVAL_FRAMEWORK_ROOT=.../Agile),
# together with EVAL_ROUTES_FILE pointing at that framework's own routes xml -- the two are
# independent placeholders, set both when switching frameworks.
FRAMEWORK_ROOT="${EVAL_FRAMEWORK_ROOT:-$B2D_ROOT}"

export CARLA_ROOT
export SCENARIO_RUNNER_ROOT="${EVAL_SCENARIO_RUNNER_ROOT:-$FRAMEWORK_ROOT/scenario_runner}"
export LEADERBOARD_ROOT="${EVAL_LEADERBOARD_ROOT:-$FRAMEWORK_ROOT/leaderboard}"
export PYTHONPATH="${CARLA_ROOT}/PythonAPI/carla/:${SCRIPT_DIR}:${SCENARIO_RUNNER_ROOT}:${LEADERBOARD_ROOT}:${PYTHONPATH}"

export CHALLENGE_TRACK_CODENAME=SENSORS
export CUDA_VISIBLE_DEVICES="$EVAL_GPU"
export SAVE_PATH="$SCRIPT_DIR/saved_data"
mkdir -p "$SAVE_PATH"

ROUTES="${EVAL_ROUTES_FILE:-$B2D_ROOT/leaderboard/data/drivetransformer_bench2drive_dev10.xml}"
rm -f "$EVAL_CHECKPOINT"

cd "$FRAMEWORK_ROOT"
python leaderboard/leaderboard/leaderboard_evaluator.py \
  --routes="$ROUTES" \
  --routes-subset="$EVAL_ROUTE_ID" \
  --repetitions=1 \
  --track="$CHALLENGE_TRACK_CODENAME" \
  --checkpoint="$EVAL_CHECKPOINT" \
  --agent="$SCRIPT_DIR/test_GREG.py" \
  --agent-config="${GREG_IL_CKPT}+${EVAL_RUN_NAME}" \
  --debug=0 \
  --resume=False \
  --port="$EVAL_PORT" \
  --traffic-manager-port="$EVAL_TM_PORT" \
  --gpu-rank="$EVAL_ADAPTER"
exit $?
