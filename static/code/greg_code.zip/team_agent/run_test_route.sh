#!/bin/bash
set -e

_routes_subset_arg="$1"
set --
source ~/miniconda3/bin/activate
conda activate greg_rl
set -- "$_routes_subset_arg"

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
set -a
[ -f "$SCRIPT_DIR/.env" ] && source "$SCRIPT_DIR/.env"
set +a
: "${CARLA_ROOT:?Set CARLA_ROOT in $SCRIPT_DIR/.env}"
: "${GREG_IL_CKPT:?Set GREG_IL_CKPT in $SCRIPT_DIR/.env}"
: "${RL_CKPT:?Set RL_CKPT in $SCRIPT_DIR/.env}"
: "${B2D_ROOT:?Set B2D_ROOT in $SCRIPT_DIR/.env (clone: git clone https://github.com/Thinklab-SJTU/Bench2Drive.git)}"

# Framework root (scenario_runner + leaderboard package) for this run. Defaults to Bench2Drive;
# override to evaluate against a different route/scenario set (e.g. FRAMEWORK_ROOT=.../Agile),
# together with ROUTES pointing at that framework's own routes xml -- the two are independent
# placeholders, set both when switching frameworks.
FRAMEWORK_ROOT="${FRAMEWORK_ROOT:-$B2D_ROOT}"

export CARLA_ROOT
export SCENARIO_RUNNER_ROOT="${SCENARIO_RUNNER_ROOT:-$FRAMEWORK_ROOT/scenario_runner}"
export LEADERBOARD_ROOT="${LEADERBOARD_ROOT:-$FRAMEWORK_ROOT/leaderboard}"
export PYTHONPATH="${CARLA_ROOT}/PythonAPI/carla/:${SCRIPT_DIR}:${SCENARIO_RUNNER_ROOT}:${LEADERBOARD_ROOT}:${PYTHONPATH}"

export CHALLENGE_TRACK_CODENAME=SENSORS
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
# test_GREG.py writes debug artifacts (rgb/bev snapshots, meta) under $SAVE_PATH/<run_name>/.
export SAVE_PATH="$SCRIPT_DIR/saved_data"
mkdir -p "$SAVE_PATH"

ROUTES="${ROUTES:-$B2D_ROOT/leaderboard/data/drivetransformer_bench2drive_dev10.xml}"
ROUTES_SUBSET="${1:-0}"
PORT="${PORT:-30100}"
TM_PORT="${TM_PORT:-50100}"
CHECKPOINT="$SCRIPT_DIR/results_test_route.json"
rm -f "$CHECKPOINT"
RUN_NAME="greg_route_test_$(date +%Y%m%d_%H%M%S)"

cd "$FRAMEWORK_ROOT"
python leaderboard/leaderboard/leaderboard_evaluator.py \
  --routes="$ROUTES" \
  --routes-subset="$ROUTES_SUBSET" \
  --repetitions=1 \
  --track="$CHALLENGE_TRACK_CODENAME" \
  --checkpoint="$CHECKPOINT" \
  --agent="$SCRIPT_DIR/test_GREG.py" \
  --agent-config="${GREG_IL_CKPT}+${RUN_NAME}" \
  --debug=0 \
  --resume=False \
  --port="$PORT" \
  --traffic-manager-port="$TM_PORT" \
  --gpu-rank="$CUDA_VISIBLE_DEVICES"
