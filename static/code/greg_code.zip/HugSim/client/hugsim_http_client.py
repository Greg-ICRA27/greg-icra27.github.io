from __future__ import annotations

import json
import pickle
import uuid
from dataclasses import dataclass
from typing import Any, Dict

import numpy as np

try:
    import requests
except Exception as e:  # pragma: no cover
    raise ImportError(
        "Missing dependency 'requests'. Install it in your client environment "
        "(e.g. `pip install requests`)."
    ) from e


@dataclass
class _State:
    obs: Any
    info: Any
    meta: Any = None


@dataclass
class EnvState:
    done: bool
    cur_scene_done: bool
    state: _State


class HugSimHTTPClient:
    def __init__(self, base_url: str, timeout_s: float = 60.0):
        self.base_url = _normalize_base_url(base_url)
        self.timeout_s = timeout_s

    def reset_env(self, *, scene_index: int | None = None, random_scene: bool = False) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"random_scene": bool(random_scene)}
        if scene_index is not None:
            payload["scene_index"] = int(scene_index)
        url = f"{self.base_url}/reset"
        r = requests.post(url, json=payload, timeout=self.timeout_s)
        if not r.ok:
            raise RuntimeError(f"POST {url} -> {r.status_code}\n{r.text[:2000]}")
        return r.json()

    def get_current_state(self) -> EnvState:
        url = f"{self.base_url}/get_current_state"
        r = requests.get(url, timeout=self.timeout_s)
        if not r.ok:
            raise RuntimeError(f"GET {url} -> {r.status_code}\n{r.text[:2000]}")
        payload = pickle.loads(r.content)
        return EnvState(
            done=bool(payload["done"]),
            cur_scene_done=bool(payload["cur_scene_done"]),
            state=_State(
                obs=payload["state"]["obs"],
                info=payload["state"]["info"],
                meta=payload["state"].get("meta", None),
            ),
        )

    def execute_action(self, plan_traj: np.ndarray) -> EnvState:
        arr = np.asarray(plan_traj)
        plan_traj_str = json.dumps(
            {
                "data": arr.reshape(-1).tolist(),
                "dtype": str(arr.dtype),
                "shape": list(arr.shape),
            }
        )
        body = {
            "plan_traj": plan_traj_str,
            "transaction_id": str(uuid.uuid4()),
        }
        url = f"{self.base_url}/execute_action"
        r = requests.post(url, json=body, timeout=self.timeout_s)
        if not r.ok:
            raise RuntimeError(f"POST {url} -> {r.status_code}\n{r.text[:2000]}")
        payload = pickle.loads(r.content)
        return EnvState(
            done=bool(payload["done"]),
            cur_scene_done=bool(payload["cur_scene_done"]),
            state=_State(
                obs=payload["state"]["obs"],
                info=payload["state"]["info"],
                meta=payload["state"].get("meta", None),
            ),
        )


def _normalize_base_url(raw: str) -> str:
    url = raw.strip()
    if not url:
        raise ValueError("Empty server URL")
    if "://" not in url:
        url = f"http://{url}"
    return url.rstrip("/")
