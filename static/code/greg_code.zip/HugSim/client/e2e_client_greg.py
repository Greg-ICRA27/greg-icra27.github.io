"""HugSim closed-loop client for GREG model with RSSM belief and route adapter."""
import sys
import os
import time
import argparse
import warnings
import numpy as np
import torch
from PIL import Image
from collections import deque
import os.path as osp

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
# BlackOut lives at the repo root, a sibling of HugSim/ -- not on PYTHONPATH by default
# unless run_test.sh added it (it does). This bootstrap is the fallback for anyone launching this
# client by hand without that script.
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from hugsim_http_client import HugSimHTTPClient as HugsimClient
from run_standlone import GregHugSimWrapper, RSSM_BURNIN_L, TRAIN_DECISION_EVERY, \
    STOP_SPEED_THRESH, STOP_MEMORY_CAP
from BlackOut import BlackOut

warnings.filterwarnings("ignore")

# Discrete accel/brake primitives; must match team_agent/test_GREG.py
Discrete_Actions_DICT = {
    0: (0, 1, False),
    1: (0.0, 0, False),
    2: (0.3, 0, False),
    3: (0.7, 0.0, False),
    4: (1.0, 0, False),
    5: (0.5, 0, True),
}

# Post-warmup frames IL head drives alone before RL policy + RSSM burn-in
WARMUP_FRAMES = 51
# Stall escape: force throttle after many near-stationary frames (no RL/RSSM effect)
CREEP_STALL_FRAMES = 800
CREEP_FORCE_FRAMES = 20


def parse_args():
    parser = argparse.ArgumentParser(description='GREG model HugSim client')
    parser.add_argument('--output', type=str, required=True, help='Output directory')
    parser.add_argument('--server', type=str, default='http://127.0.0.1:8065', help='HugSim server URL')
    parser.add_argument('--il-checkpoint', type=str, required=True,
                         help='Path to the IL base checkpoint (Lightning "state_dict" format)')
    parser.add_argument('--rl-checkpoint', type=str, default=None,
                         help='Path to the RL sac_checkpoint_*.pth (policy_net_state_dict + rssm_state_dict)')
    parser.add_argument('--original-checkpoint', type=str, default='False',
                         help='If True, run IL-only (no RL/RSSM overlay)')
    return parser.parse_args()


@torch.no_grad()
def main():
    args = parse_args()
    original_format = args.original_checkpoint.strip().lower() == 'true'

    print(f"Loading GREG model from {args.il_checkpoint} "
          f"(original_format={original_format}, rl_checkpoint={args.rl_checkpoint})")
    model = GregHugSimWrapper(
        args.il_checkpoint,
        rl_checkpoint_path=args.rl_checkpoint,
        original_format=original_format,
    )
    model.net.cuda()
    model.net.eval()

    client = HugsimClient(args.server)
    client.reset_env()
    print('Ready to receive from HUGSIM')
    env_state = client.get_current_state()

    # Corruption level from GREG_BLACKOUT_LEVEL env var
    blackout = BlackOut.from_env()

    # Optional front-camera frame dump for batch evals
    save_front_frames = os.environ.get("HUGSIM_SAVE_FRONT_FRAMES", "") == "1"

    scenario_id = 1
    while True:
        try:
            blackout.new_episode(scenario_id)
            cnt = 0
            decimation_frame = 0
            time_since_full_stop = 0.0
            creeping_cnt = 0
            force_move = 0
            frame_hist = deque(maxlen=TRAIN_DECISION_EVERY * RSSM_BURNIN_L)

            def belief_for(obs):
                if model.rssm is None:
                    return None
                if RSSM_BURNIN_L > 0 and len(frame_hist) >= TRAIN_DECISION_EVERY:
                    hist = list(frame_hist)
                    available = min(RSSM_BURNIN_L, len(hist) // TRAIN_DECISION_EVERY)
                    frames = [hist[-k * TRAIN_DECISION_EVERY] for k in range(available, 0, -1)]
                    h = model.rssm.burn_in(torch.stack([f[0] for f in frames], dim=1),
                                            torch.stack([f[1] for f in frames], dim=1))
                else:
                    h = model.rssm.initial(obs.shape[0], obs.device)
                belief, _ = model.rssm.posterior_belief(h, obs, sample=False)
                return belief

            while not env_state.done and not env_state.cur_scene_done:
                raw_images = env_state.state.obs['rgb']
                raw_images = blackout.apply_views(raw_images)
                if blackout.enabled:
                    frame_img = raw_images.get('CAM_FRONT')
                    if frame_img is not None:
                        frame_dir = osp.join(args.output, 'blackout_frames', f'scenario_{scenario_id:06d}')
                        os.makedirs(frame_dir, exist_ok=True)
                        Image.fromarray(np.asarray(frame_img).astype(np.uint8)).save(
                            osp.join(frame_dir, f'{cnt:05d}.png'))
                if save_front_frames:
                    front_img = raw_images.get('CAM_FRONT')
                    if front_img is not None:
                        front_dir = osp.join(args.output, 'front_frames', f'scenario_{scenario_id:06d}')
                        os.makedirs(front_dir, exist_ok=True)
                        Image.fromarray(np.asarray(front_img).astype(np.uint8)).save(
                            osp.join(front_dir, f'{cnt:05d}.png'))
                info = env_state.state.info

                rgb_numpy = model.process_hugsim_images(raw_images)
                rgb_pil = Image.fromarray(rgb_numpy)
                rgb_input = model._im_transform(rgb_pil).unsqueeze(0).cuda()

                speed = float(info['ego_velo'])
                hugsim_cmd = info['command']
                if hugsim_cmd == 0:
                    command = 2 - 1
                    target_point = [5.0, 3.0]
                elif hugsim_cmd == 1:
                    command = 1 - 1
                    target_point = [5.0, -3.0]
                elif hugsim_cmd == 2:
                    command = 3 - 1
                    target_point = [5.0, 0.0]
                else:
                    command = 3 - 1
                    target_point = [5.0, 0.0]

                cmd_one_hot = [0] * 6
                cmd_one_hot[command] = 1
                cmd_one_hot = torch.tensor(cmd_one_hot).view(1, 6).cuda().float()
                speed_tensor = torch.tensor([speed]).view(1, 1).cuda().float() / 12.0
                target_t = torch.tensor(target_point).view(1, 2).cuda().float()
                state_input = torch.cat([speed_tensor, target_t, cmd_one_hot], 1)

                pred = model.net(rgb_input, state_input, target_t)

                if speed < STOP_SPEED_THRESH:
                    time_since_full_stop = 0.0
                else:
                    time_since_full_stop = min(time_since_full_stop + 0.05, STOP_MEMORY_CAP)
                stop_mem = torch.tensor([[time_since_full_stop / STOP_MEMORY_CAP]], device='cuda', dtype=torch.float32)
                route_full = torch.cat([state_input, stop_mem], dim=1)

                cnt += 1
                if cnt < WARMUP_FRAMES or model.rssm is None:
                    steer_ctrl, throttle_ctrl, brake_ctrl, reverse_ctrl, _ = model.net.process_action(
                        pred, command, speed_tensor, target_t)
                    steer_ctrl = float(steer_ctrl)
                    throttle_ctrl = float(throttle_ctrl)
                    brake_ctrl = float(brake_ctrl)
                else:
                    rssm_obs = torch.cat([pred['join_ctrl_inp'], route_full], dim=1)
                    belief_t = belief_for(rssm_obs)
                    action, log_prob, entropy = model.net.get_actionrl(
                        pred['join_ctrl_inp'], deterministic=True, route=route_full, belief=belief_t)
                    frame_hist.append((rssm_obs, action[:, :-1].detach().float()))

                    action_2col = torch.cat([action[:, 0].unsqueeze(-1), action[:, -1].unsqueeze(-1)], dim=1)
                    act_numpy = action_2col.detach().cpu().numpy().squeeze()
                    steer_traj, throttle_idx = act_numpy.tolist()
                    throttle_ctrl, brake_ctrl, reverse_ctrl = Discrete_Actions_DICT[int(throttle_idx)]
                    steer_ctrl = steer_traj * 2 - 1

                acc = float(throttle_ctrl) - float(brake_ctrl)
                steer = float(np.clip(steer_ctrl, -1, 1))

                if speed < 0.1:
                    creeping_cnt += 1
                else:
                    creeping_cnt = 0
                if creeping_cnt > CREEP_STALL_FRAMES:
                    force_move = CREEP_FORCE_FRAMES
                if force_move > 0:
                    force_move -= 1
                    acc = 0.4

                actions = np.array([[acc, steer]])
                print(f"[Step {cnt}] Speed: {speed:.2f} | Action: Acc={acc:.2f}, Steer={steer:.2f}")

                env_state = client.execute_action(actions)

            print(f'Scenario {scenario_id:06d} done')
            scenario_id += 1
            env_state = client.get_current_state()

        except Exception as e:
            print(f"[ERROR] Exception in scene loop: {str(e)}")
            import traceback
            traceback.print_exc()
            scenario_id += 1
            env_state = client.get_current_state()


if __name__ == '__main__':
    main()
