"""HugSim RL rollout worker for GREG_RL_Trainer (simpler reward formula; no BEV/boxes/reverse)."""
import os
import sys
import io
import time
import zlib
import socket
import argparse
import warnings
from collections import deque

import numpy as np
import torch
import requests
from PIL import Image

sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'client'))

from hugsim_http_client import HugSimHTTPClient as HugsimClient
from run_standlone import GregHugSimWrapper, RSSM_BURNIN_L, TRAIN_DECISION_EVERY, \
    STOP_SPEED_THRESH, STOP_MEMORY_CAP

warnings.filterwarnings("ignore")

MASTER_IP = os.environ["MASTER_IP"]
MASTER_PORT = int(os.environ.get("DATA_SERVER_PORT", 34543))
MASTER_BATCH_URL = f"http://{MASTER_IP}:{MASTER_PORT}/add_batch/"
MASTER_WEIGHT_URL = f"http://{MASTER_IP}:{MASTER_PORT}/get_latest_weights/"
RETRY_DELAY = 5.0

# Collision-avoidance: unique worker ID per machine/process
UNIQUE_WORKER_ID = (zlib.crc32(socket.gethostname().encode()) % 20000) * 100000 + os.getpid() % 100000

# Reward accumulation step
DECISION_EVERY = TRAIN_DECISION_EVERY
# Post-warmup IL-only frames before RL policy + RSSM burn-in
WARMUP_FRAMES = 51
# Decisions per batch push/weight pull
SEND_EVERY_DECISIONS = int(os.environ.get("SEND_EVERY_DECISIONS", 50))

Discrete_Actions_DICT = {
    0: (0, 1, False),
    1: (0.0, 0, False),
    2: (0.3, 0, False),
    3: (0.7, 0.0, False),
    4: (1.0, 0, False),
    5: (0.5, 0, True),
}


def parse_args():
    p = argparse.ArgumentParser(description='GREG HugSim RL rollout worker')
    p.add_argument('--il-checkpoint', type=str, required=True)
    p.add_argument('--server', type=str, default='http://127.0.0.1:8065')
    return p.parse_args()


class RewardState:
    """Per-scenario reward bookkeeping."""

    def __init__(self):
        self.rc_prev = None
        self.last_steer = 0.0
        self.last_reverse = 0.0
        self.macro_r6 = None

    def step(self, rc_now, speed_norm, collision):
        rc_delta = 0.0 if (rc_now is None or self.rc_prev is None) else (rc_now - self.rc_prev)
        if rc_now is not None:
            self.rc_prev = rc_now
        Rdis = float(torch.sigmoid(torch.tensor(2.0 * rc_delta)))
        Rspeed = float(torch.abs(torch.tanh(torch.tensor(5.0 * speed_norm))))
        Rsteer = max(0.0, 1.0 - abs(self.last_steer))
        Rds = 1.0 - 0.9 * float(collision)
        Rreverse = 0.01 * self.last_reverse
        eps = 1e-6
        r = ((max(Rdis, eps) ** 4) * max(Rspeed, eps) * max(Rsteer, eps) * max(Rds, eps)) ** (1 / 7) + Rreverse
        frame6 = np.array([r, Rdis, Rspeed, Rsteer, Rds, Rreverse], dtype=np.float32)
        self.macro_r6 = frame6 if self.macro_r6 is None else self.macro_r6 + frame6
        return frame6

    def pop_macro(self, speed_norm, collision, term_cause):
        """Return 11-term reward vector and reset macro-block accumulator."""
        macro6 = self.macro_r6 if self.macro_r6 is not None else np.zeros(6, dtype=np.float32)
        self.macro_r6 = None
        ttc_placeholder = 999.0
        desired_speed_placeholder = 8.33 / 12.0
        tail = np.array([speed_norm, float(collision), ttc_placeholder,
                          desired_speed_placeholder, float(term_cause)], dtype=np.float32)
        return np.concatenate([macro6, tail])


@torch.no_grad()
def run_scenario(model, client, scenario_id, replay_buffer, worker_state):
    cnt = 0
    decimation_frame = 0
    time_since_full_stop = 0.0
    reward_state = RewardState()
    frame_hist = deque(maxlen=DECISION_EVERY * RSSM_BURNIN_L)
    action_queue = deque(maxlen=10)
    for _ in range(10):
        action_queue.append(torch.tensor([0.5, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0]))

    prev_prev_state = prev_state = prev_action = prev_route = None
    prev_prev_action_queue = prev_action_queue = None
    held_control = None

    def belief_for(obs):
        if model.rssm is None:
            return None
        if RSSM_BURNIN_L > 0 and len(frame_hist) >= DECISION_EVERY:
            hist = list(frame_hist)
            available = min(RSSM_BURNIN_L, len(hist) // DECISION_EVERY)
            frames = [hist[-k * DECISION_EVERY] for k in range(available, 0, -1)]
            h = model.rssm.burn_in(torch.stack([f[0] for f in frames], dim=1),
                                    torch.stack([f[1] for f in frames], dim=1))
        else:
            h = model.rssm.initial(obs.shape[0], obs.device)
        belief, _ = model.rssm.posterior_belief(h, obs, sample=False)
        return belief

    env_state = client.get_current_state()
    while not env_state.done and not env_state.cur_scene_done:
        raw_images = env_state.state.obs['rgb']
        info = env_state.state.info

        rgb_numpy = model.process_hugsim_images(raw_images)
        rgb_input = model._im_transform(Image.fromarray(rgb_numpy)).unsqueeze(0).cuda()

        speed = float(info['ego_velo'])
        speed_norm = speed / 12.0
        hugsim_cmd = info['command']
        if hugsim_cmd == 0:
            command, target_point = 1, [5.0, 3.0]
        elif hugsim_cmd == 1:
            command, target_point = 0, [5.0, -3.0]
        else:
            command, target_point = 2, [5.0, 0.0]

        cmd_one_hot = torch.zeros(1, 6).cuda()
        cmd_one_hot[0, command] = 1
        speed_tensor = torch.tensor([[speed_norm]]).cuda().float()
        target_t = torch.tensor([target_point]).cuda().float()
        state_input = torch.cat([speed_tensor, target_t, cmd_one_hot], 1)

        pred = model.net(rgb_input, state_input, target_t)

        collision = bool(info.get('collision', False))
        cnt += 1
        is_decision = (decimation_frame % DECISION_EVERY == 0)
        decimation_frame += 1

        done_now = collision or env_state.cur_scene_done
        term_cause = 1.0 if collision else 0.0

        if cnt >= WARMUP_FRAMES:
            reward_state.step(info.get('rc'), speed_norm, collision)

        if cnt < WARMUP_FRAMES:
            steer_ctrl, throttle_ctrl, brake_ctrl, reverse_ctrl, _ = model.net.process_action(
                pred, command, speed_tensor, target_t)
            steer_ctrl, throttle_ctrl, brake_ctrl = float(steer_ctrl), float(throttle_ctrl), float(brake_ctrl)
        elif is_decision or done_now:
            if speed < STOP_SPEED_THRESH:
                time_since_full_stop = 0.0
            else:
                time_since_full_stop = min(time_since_full_stop + 0.05, STOP_MEMORY_CAP)
            stop_mem = torch.tensor([[time_since_full_stop / STOP_MEMORY_CAP]], device='cuda')
            route_full = torch.cat([state_input, stop_mem], dim=1)

            embedding = pred['join_ctrl_inp']
            rssm_obs = torch.cat([embedding, route_full], dim=1)
            belief_t = belief_for(rssm_obs)
            action, log_prob, entropy = model.net.get_actionrl(
                embedding, route=route_full, belief=belief_t)
            action_buffer = action[:, :-1]
            frame_hist.append((rssm_obs, action_buffer.detach().float()))
            action_queue.append(action_buffer[0].detach().cpu())
            action_queue_tensor = torch.vstack(list(action_queue)).flatten().unsqueeze(0)

            action_2col = torch.cat([action[:, 0].unsqueeze(-1), action[:, -1].unsqueeze(-1)], dim=1)
            steer_traj, throttle_idx = action_2col.detach().cpu().numpy().squeeze().tolist()
            throttle_ctrl, brake_ctrl, reverse_ctrl = Discrete_Actions_DICT[int(throttle_idx)]
            steer_ctrl = steer_traj * 2 - 1
            reward_state.last_reverse = 1.0 if reverse_ctrl else 0.0

            if prev_prev_state is not None:
                reward_vec = reward_state.pop_macro(speed_norm, collision, term_cause)
                replay_buffer.append({
                    "state_bev": None, "next_state_bev": None,
                    "pre_state": prev_prev_state.squeeze().cpu().numpy().tolist(),
                    "state": prev_state.squeeze().cpu().numpy().tolist(),
                    "action": prev_action.numpy().tolist(),
                    "reward": reward_vec.tolist(),
                    "next_state": embedding.squeeze().detach().cpu().numpy().tolist(),
                    "done": bool(done_now),
                    "action_queue": prev_prev_action_queue.squeeze().numpy().tolist(),
                    "action_queue_next": prev_action_queue.squeeze().numpy().tolist(),
                    "env_metadata": f"hugsim_{scenario_id:06d}",
                    "worker_id": UNIQUE_WORKER_ID,
                    "boxes": None, "next_boxes": None,
                    "route_scalars": prev_route.squeeze().cpu().numpy().tolist(),
                    "next_route_scalars": route_full.squeeze().cpu().numpy().tolist(),
                    "h": [], "h_next": [],
                })
            else:
                reward_state.pop_macro(speed_norm, collision, term_cause)  # discard, resets accumulator

            prev_prev_state = prev_state
            prev_state = embedding.detach()
            prev_prev_action_queue = prev_action_queue
            prev_action_queue = action_queue_tensor.detach().cpu()
            prev_action = action_buffer[0].detach().cpu()
            prev_route = route_full.detach()

            held_control = (steer_ctrl, throttle_ctrl, brake_ctrl)
        elif held_control is not None:
            steer_ctrl, throttle_ctrl, brake_ctrl = held_control
        else:
            steer_ctrl, throttle_ctrl, brake_ctrl = 0.0, 0.0, 1.0

        reward_state.last_steer = steer_ctrl
        acc = float(throttle_ctrl) - float(brake_ctrl)
        steer = float(np.clip(steer_ctrl, -1, 1))
        actions = np.array([[acc, steer]])
        env_state = client.execute_action(actions)

        if len(replay_buffer) >= SEND_EVERY_DECISIONS:
            worker_state.flush(replay_buffer)

        if done_now and not env_state.cur_scene_done:
            break  # collision-terminated mid-scenario; let the outer loop advance to the next one


class WorkerState:
    def __init__(self, model):
        self.model = model

    def update_policy_from_master(self):
        while True:
            try:
                resp = requests.get(MASTER_WEIGHT_URL, timeout=30)
                resp.raise_for_status()
                state_dict = torch.load(io.BytesIO(resp.content), map_location='cuda')
                self.model.load_rl_weights(state_dict)
                return
            except requests.exceptions.RequestException as e:
                print(f"[Worker {UNIQUE_WORKER_ID}] Could not pull weights ({e}). Retrying in {RETRY_DELAY}s...")
                time.sleep(RETRY_DELAY)

    def flush(self, replay_buffer):
        if not replay_buffer:
            return
        batch, replay_buffer[:] = list(replay_buffer), []
        while True:
            try:
                requests.post(MASTER_BATCH_URL, json=batch, timeout=30).raise_for_status()
                break
            except requests.exceptions.RequestException as e:
                print(f"[Worker {UNIQUE_WORKER_ID}] Could not send batch ({e}). Retrying in {RETRY_DELAY}s...")
                time.sleep(RETRY_DELAY)
        print(f"[Worker {UNIQUE_WORKER_ID}] sent {len(batch)} transitions, pulling fresh weights...")
        self.update_policy_from_master()


def main():
    args = parse_args()
    print(f"[Worker {UNIQUE_WORKER_ID}] Loading GREG model (IL-only) from {args.il_checkpoint}")
    model = GregHugSimWrapper(args.il_checkpoint, original_format=True)
    model.net.cuda()
    model.net.eval()

    worker_state = WorkerState(model)
    print(f"[Worker {UNIQUE_WORKER_ID}] Pulling initial weights from trainer at {MASTER_IP}:{MASTER_PORT}...")
    worker_state.update_policy_from_master()

    client = HugsimClient(args.server)
    client.reset_env()
    print(f"[Worker {UNIQUE_WORKER_ID}] Ready, rolling out against {args.server}")

    replay_buffer = []
    scenario_id = 1
    while True:
        try:
            run_scenario(model, client, scenario_id, replay_buffer, worker_state)
            print(f"[Worker {UNIQUE_WORKER_ID}] Scenario {scenario_id:06d} done "
                  f"({len(replay_buffer)} transitions buffered)")
            scenario_id += 1
        except Exception as e:
            print(f"[Worker {UNIQUE_WORKER_ID}] [ERROR] Exception in scenario loop: {e}")
            import traceback
            traceback.print_exc()
            scenario_id += 1
        client.reset_env()


if __name__ == '__main__':
    main()
