import argparse
import os
from collections import OrderedDict
import torch
import torch.optim as optim
from torch.utils.data import DataLoader
import torch.nn.functional as F
import pytorch_lightning as pl
from pytorch_lightning.callbacks import ModelCheckpoint
from pytorch_lightning.strategies import DDPStrategy
from model import Greg
from data import CARLA_Data
from config import GlobalConfig

torch.set_float32_matmul_precision('high')

class Greg_planner(pl.LightningModule):
    def __init__(self, config, lr, vit_base_model): 
        super().__init__()
        self.lr = lr
        self.config = config
        self.model = Greg(config, vit_base_model)
        
        self.action_dict = {0:  (0, 1, False),
                            1:  (0.0, 0, False),
                            2: (0.3, 0, False),
                            3: (0.7, 0.0, False),
                            4: (1.0, 0, False),
                            5: (0.5, 0, True),}

    def setup(self, stage=None):
        self.model = torch.compile(self.model)
        if self.trainer.global_rank == 0:
            print("Model successfully compiled for DDP!")

    def get_action_category_vectorized(self, throttle, brake, reverse):
        reverse_float = reverse.float()
        distances = []
        
        for cat in range(len(self.action_dict)):
            t, b, r = self.action_dict[cat]
            r_float = 1.0 if r else 0.0
            dist = (throttle - t)**2 + (brake - b)**2 + (reverse_float - r_float)**2
            distances.append(dist)
            
        distances = torch.stack(distances, dim=1) 
        best_cats = torch.argmin(distances, dim=1) 
        return best_cats

    def _load_state_dict(self, il_net, rl_state_dict, key_word):
        rl_keys = [k for k in rl_state_dict.keys() if key_word in k]
        il_keys = il_net.state_dict().keys()
        assert len(rl_keys) == len(il_net.state_dict().keys()), f'mismatch number of layers loading {key_word}'
        new_state_dict = OrderedDict()
        for k_il, k_rl in zip(il_keys, rl_keys):
            new_state_dict[k_il] = rl_state_dict[k_rl]
        il_net.load_state_dict(new_state_dict)
    
    def forward(self, batch):
        pass

    def training_step(self, batch, batch_idx):
        front_img = batch['front_img']
        speed = batch['speed'].to(dtype=torch.float32).view(-1,1) / 12.
        target_point = batch['target_point'].to(dtype=torch.float32)
        command = batch['target_command']
        state = torch.cat([speed, target_point, command], 1)
        value = batch['value'].view(-1,1)
        feature = batch['feature']
        gt_waypoints = batch['waypoints']

        pred = self.model(front_img, state, target_point)

        # 1. STEERING LOSS (Beta Distribution)
        steer_mu = pred['steer_mu']
        steer_sigma = pred['steer_sigma']
        steer_dist = torch.distributions.Beta(steer_mu, steer_sigma)
        
        gt_steer = batch['action'][:,1]
        gt_steer_normalized = (gt_steer + 1.0) / 2.0
        gt_steer_normalized = torch.clamp(gt_steer_normalized, 0.001, 0.999).unsqueeze(-1)
        
        steer_loss = -steer_dist.log_prob(gt_steer_normalized).mean()

        # 2. ACCELERATION/BRAKE LOSS (Categorical)
        accel_logits = pred['accel_logits']
        gt_throttle = batch['action'][:, 0]
        gt_brake = batch['action'][:, 2]
        gt_reverse = batch['action'][:, 3]

        gt_accel_cats = self.get_action_category_vectorized(gt_throttle, gt_brake, gt_reverse)
        accel_loss = F.cross_entropy(accel_logits, gt_accel_cats)

        action_loss = 1.0 * steer_loss + 1.0 * accel_loss

        # Other losses
        speed_loss = F.l1_loss(pred['pred_speed'], speed) * self.config.speed_weight
        value_loss = (F.mse_loss(pred['pred_value_traj'], value) + F.mse_loss(pred['pred_value_ctrl'], value)) * self.config.value_weight
        feature_loss = (F.mse_loss(pred['pred_features_traj'], feature) + F.mse_loss(pred['pred_features_ctrl'], feature)) * self.config.features_weight
        wp_loss = F.l1_loss(pred['pred_wp'], gt_waypoints, reduction='none').mean()

        # FUTURE PREDICTION LOSSES 
        future_steer_loss = 0
        future_accel_loss = 0
        future_feature_loss = 0

        for i in range(self.config.pred_len):
            future_steer_dist = torch.distributions.Beta(pred['future_steer_mu'][i], pred['future_steer_sigma'][i])
            future_gt_steer = batch['future_action'][:, i, 1]
            future_gt_steer_normalized = (future_gt_steer + 1.0) / 2.0
            future_gt_steer_normalized = torch.clamp(future_gt_steer_normalized, 0.001, 0.999).unsqueeze(-1)
            future_steer_loss += -future_steer_dist.log_prob(future_gt_steer_normalized).mean()

            future_gt_throttle = batch['future_action'][:, i, 0]
            future_gt_brake = batch['future_action'][:, i, 2]
            future_gt_reverse = batch['future_action'][:, i, 3]
            
            future_gt_accel_cats = self.get_action_category_vectorized(
                future_gt_throttle, future_gt_brake, future_gt_reverse
            )
            
            future_accel_loss += F.cross_entropy(pred['future_accel_logits'][i], future_gt_accel_cats)
            future_feature_loss += F.mse_loss(pred['future_feature'][i], batch['future_feature'][i])

        future_steer_loss /= self.config.pred_len
        future_accel_loss /= self.config.pred_len
        future_action_loss = 1.0 * future_steer_loss + 1.0 * future_accel_loss
        future_feature_loss = (future_feature_loss / self.config.pred_len) * self.config.features_weight
        
        loss = action_loss + speed_loss + value_loss + feature_loss + wp_loss + future_feature_loss + future_action_loss
        
        with torch.no_grad():
            fb_error_mean = torch.abs(pred['pred_wp'][:,:,0] - gt_waypoints[:,:,0]).mean()
            lr_error_mean = torch.abs(pred['pred_wp'][:,:,1] - gt_waypoints[:,:,1]).mean()

        self.log('train_steer_loss', steer_loss.item())
        self.log('train_accel_loss', accel_loss.item())
        self.log('train_wp_loss', wp_loss.item())
        self.log('train_speed_loss', speed_loss.item())
        self.log('train_value_loss', value_loss.item())
        self.log('train_feature_loss', feature_loss.item())
        self.log('train_future_feature_loss', future_feature_loss.item())
        self.log('train_future_action_loss', future_action_loss.item())
        self.log('left_right_error_mean', lr_error_mean.item())
        self.log('front_back_error_mean', fb_error_mean.item())
        return loss

    def configure_optimizers(self):
        # exclude LayerNorm and biases from weight decay
        decay_params = []
        no_decay_params = []

        for name, param in self.named_parameters():
            if not param.requires_grad:
                continue
            if param.ndim <= 1 or "norm" in name.lower():
                no_decay_params.append(param)
            else:
                decay_params.append(param)

        optim_groups = [
            {"params": decay_params, "weight_decay": 0.05},
            {"params": no_decay_params, "weight_decay": 0.0},
        ]

        optimizer = optim.AdamW(optim_groups, lr=self.lr, betas=(0.9, 0.999))

        total_steps = self.trainer.estimated_stepping_batches
        
        lr_scheduler = optim.lr_scheduler.OneCycleLR(
            optimizer,
            max_lr=self.lr,
            total_steps=total_steps,
            pct_start=0.05, # 5% of training steps dedicated to warmup
            anneal_strategy='cos',
            div_factor=25.0,
            final_div_factor=1000.0
        )

        # 'interval': 'step' so this updates per batch, not per epoch
        return {
            "optimizer": optimizer,
            "lr_scheduler": {
                "scheduler": lr_scheduler,
                "interval": "step",
                "frequency": 1
            },
        }
    def validation_step(self, batch, batch_idx):
        front_img = batch['front_img']
        speed = batch['speed'].to(dtype=torch.float32).view(-1,1) / 12.
        target_point = batch['target_point'].to(dtype=torch.float32)
        command = batch['target_command']
        state = torch.cat([speed, target_point, command], 1)
        value = batch['value'].view(-1,1)
        feature = batch['feature']
        gt_waypoints = batch['waypoints']

        pred = self.model(front_img, state, target_point)
        
        # 1. STEERING LOSS 
        steer_mu = pred['steer_mu']
        steer_sigma = pred['steer_sigma']
        steer_dist = torch.distributions.Beta(steer_mu, steer_sigma)
        gt_steer = batch['action'][:,1]
        gt_steer_normalized = (gt_steer + 1.0) / 2.0
        gt_steer_normalized = torch.clamp(gt_steer_normalized, 0.001, 0.999).unsqueeze(-1)
        steer_loss = -steer_dist.log_prob(gt_steer_normalized).mean()

        # 2. ACCELERATION/BRAKE LOSS 
        accel_logits = pred['accel_logits']
        gt_throttle = batch['action'][:, 0]
        gt_brake = batch['action'][:, 2]
        gt_reverse = batch['action'][:, 3]

        gt_accel_cats = self.get_action_category_vectorized(gt_throttle, gt_brake, gt_reverse)
        accel_loss = F.cross_entropy(accel_logits, gt_accel_cats)

        action_loss = 1.0 * steer_loss + 1.0 * accel_loss

        # Other losses
        speed_loss = F.l1_loss(pred['pred_speed'], speed) * self.config.speed_weight
        value_loss = (F.mse_loss(pred['pred_value_traj'], value) + F.mse_loss(pred['pred_value_ctrl'], value)) * self.config.value_weight
        feature_loss = (F.mse_loss(pred['pred_features_traj'], feature) + F.mse_loss(pred['pred_features_ctrl'], feature)) * self.config.features_weight
        wp_loss = F.l1_loss(pred['pred_wp'], gt_waypoints, reduction='none').mean()
        
        val_loss = action_loss + speed_loss + value_loss + feature_loss + wp_loss
        
        # Calculate Metrics
        with torch.no_grad():
            fb_error_mean = torch.abs(pred['pred_wp'][:,:,0] - gt_waypoints[:,:,0]).mean()
            lr_error_mean = torch.abs(pred['pred_wp'][:,:,1] - gt_waypoints[:,:,1]).mean()

            pred_accel_cats = torch.argmax(accel_logits, dim=1)
            accel_accuracy = (pred_accel_cats == gt_accel_cats).float().mean()

            pred_steer_mode = self.model._get_action_beta(steer_mu, steer_sigma) 
            pred_steer_unnormalized = pred_steer_mode * 2.0 - 1.0
            steer_l1_error = torch.abs(pred_steer_unnormalized.squeeze(-1) - gt_steer).mean()

        self.log("val_steer_loss", steer_loss.item(), sync_dist=True)
        self.log("val_accel_loss", accel_loss.item(), sync_dist=True)
        self.log('val_wp_loss', wp_loss.item(), sync_dist=True)
        self.log('val_loss', val_loss.item(), sync_dist=True)
        self.log('val_accel_accuracy', accel_accuracy.item(), sync_dist=True)
        self.log('val_steer_l1_error', steer_l1_error.item(), sync_dist=True)
        self.log('val_lr_error_mean', lr_error_mean.item(), sync_dist=True)
        self.log('val_fb_error_mean', fb_error_mean.item(), sync_dist=True)
        
if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    parser.add_argument('--id', type=str, default='Greg', help='Unique experiment identifier.')
    parser.add_argument('--epochs', type=int, default=100, help='Number of train epochs.')
    parser.add_argument('--lr', type=float, default=0.0003, help='Learning rate.') # Kept at 3e-4
    parser.add_argument('--val_every', type=int, default=1, help='Validation frequency (epochs).')
    parser.add_argument('--batch_size', type=int, default=16, help='Batch size')
    parser.add_argument('--logdir', type=str, default='loglargedino', help='Directory to log data to.')
    parser.add_argument('--gpus', type=int, default=1, help='number of gpus')

    args = parser.parse_args()
    args.logdir = os.path.join(args.logdir, args.id)

    config = GlobalConfig()

    train_set = CARLA_Data(root=config.root_dir_all, data_path=config.train_data, img_aug = config.img_aug)
    print(len(train_set))
    val_set = CARLA_Data(root=config.root_dir_all, data_path=config.val_data,)
    print(len(val_set))

    dataloader_train = DataLoader(
        train_set, 
        batch_size=args.batch_size, 
        shuffle=True,
        num_workers=8, 
        persistent_workers=True, 
        pin_memory=True          
    )

    dataloader_val = DataLoader(
        val_set, 
        batch_size=args.batch_size, 
        shuffle=False,
        num_workers=8, 
        persistent_workers=True, 
        pin_memory=True          
    )

    from transformers import AutoModel
    from dotenv import load_dotenv

    load_dotenv()
    my_hf_token = os.environ["HF_TOKEN"]

    pretrained_model_name = "facebook/dinov3-vitl16-pretrain-lvd1689m"
                            
    custom_cache_path = "./dinov3_large_cache"
    vit_base = AutoModel.from_pretrained(
        pretrained_model_name,
        token=my_hf_token, 
        cache_dir=custom_cache_path
    )
    
    Greg_model = Greg_planner(config, args.lr, vit_base_model=vit_base)
    
    checkpoint_callback = ModelCheckpoint(save_weights_only=False, mode="min", monitor="val_loss", save_top_k=10, save_last=True,
                                          dirpath=args.logdir, filename="best_{epoch:02d}-{val_loss:.3f}")

    trainer = pl.Trainer(
                        default_root_dir=args.logdir,
                        devices = args.gpus,
                        accelerator='gpu',
                        strategy=DDPStrategy(find_unused_parameters=True),
                        sync_batchnorm=True,
                        profiler='simple',
                        benchmark=True,
                        log_every_n_steps=1,
                        callbacks=[checkpoint_callback],
                        precision="16-mixed",
                        check_val_every_n_epoch = args.val_every,
                        max_epochs = args.epochs,
                        accumulate_grad_batches=1,
                        gradient_clip_val=1.0,           # Prevents exploding gradients from attention spikes
                        gradient_clip_algorithm="norm"   # Clips by L2 norm
                        )
    
    trainable_params = sum(p.numel() for p in Greg_model.parameters() if p.requires_grad)
    total_params = sum(p.numel() for p in Greg_model.parameters())
    print(f"Trainable Parameters: {trainable_params:,} / Total: {total_params:,}")
    print(f"Percentage Trainable: {100 * trainable_params / total_params:.2f}%")
    trainer.fit(Greg_model, dataloader_train, dataloader_val)