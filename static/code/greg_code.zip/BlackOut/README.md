# BlackOut

Camera-image corruption ("BlackOut") wrapper shared by the CARLA/Bench2Drive eval
(`team_agent/test_GREG.py`) and the HugSim eval (`HugSim/client/e2e_client_greg.py`).

## What it does

Six corruption families, each with two severities:

| Family | Look |
|---|---|
| `rain` | falling rain streaks + wet hazy atmosphere |
| `droplets` | rain droplets clinging to the lens (ROLE fisheye model) |
| `dirt_dust` | dried dusty film + water spots |
| `dirt_mud` | flung brown mud, opaque cores |
| `dirt_smudge` | greasy wipe smears, very blurry |
| `dirt_extreme` | caked filth, view almost fully obstructed |

- **Level** (`none`/`low`/`high`) is one setting for the whole run, `none` = off by default.
- **Family** is picked automatically, once per route (CARLA) / scenario (HugSim), deterministically
  from the route/scenario id. To force one family everywhere (e.g. to run a single family), set
  `GREG_BLACKOUT_FAMILY`.

## Enabling it

**Bench2Drive** (`team_agent/eval/queue_eval.py`):
```bash
python3 team_agent/eval/queue_eval.py --blackout low   # or high; default none
```

**HugSim** (`HugSim/run_test.sh`):
```bash
BLACKOUT=low ./HugSim/run_test.sh
```

Both are no-ops when left at the default `none`.

## Config surface (env vars)

| Var | Values | Default | Meaning |
|---|---|---|---|
| `GREG_BLACKOUT_LEVEL` | `none`\|`low`\|`high` | `none` | severity for this run |
| `GREG_BLACKOUT_SEED` | int | `20260827` | seed for the route/scenario -> family assignment |
| `GREG_BLACKOUT_FAMILY` | one of `FAMILIES` | unset | force one family everywhere instead of the per-route pick |

## Call-site pattern

```python
from BlackOut import BlackOut

blackout = BlackOut.from_env()          # once, at agent/client init
...
blackout.new_episode(route_or_scenario_id)   # once, at the start of each route/scenario
...
input_data = blackout.apply_carla(input_data)   # CARLA: dict cam_id -> (frame, BGRA arr)
raw_images = blackout.apply_views(raw_images)   # HugSim: dict cam_id -> RGB arr
```

Only the six `CAM_*` mosaic-tile keys are touched (`CAM_FRONT`, `CAM_FRONT_LEFT`,
`CAM_FRONT_RIGHT`, `CAM_BACK`, `CAM_BACK_LEFT`, `CAM_BACK_RIGHT`) — never `bev` — and any camera
that's missing/all-black is skipped.

## Color order

The corruption functions expect **BGR** uint8. `apply_carla` gets CARLA's native BGRA arrays and
slices `[:3]` directly. `apply_views` gets HugSim's RGB arrays and converts RGB->BGR before
corrupting, then back BGR->RGB after.
