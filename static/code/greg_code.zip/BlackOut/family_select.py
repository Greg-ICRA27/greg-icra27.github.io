"""Deterministic corruption family selection per route/scenario.

Pure function: same seed+key always picks same family. Uses hashlib for cross-process stability.
"""
import hashlib

from .presets import FAMILIES

DEFAULT_SEED = 20260827  # fixed seed; change it deliberately to reshuffle the assignment


def pick_family(key, seed=DEFAULT_SEED):
    """Deterministically pick one of FAMILIES for `key` (a route id / scenario id, any str/int)."""
    digest = hashlib.sha256(f"{seed}:{key}".encode("utf-8")).digest()
    idx = int.from_bytes(digest[:8], "big") % len(FAMILIES)
    return FAMILIES[idx]
