"""BlackOut -- camera-image corruption for CARLA/HugSim eval.

Usage: BlackOut.from_env() -> .new_episode(id) -> .apply_carla() or .apply_views()
"""
from .wrapper import BlackOut, CAM_KEYS
from .family_select import DEFAULT_SEED, pick_family
from .presets import FAMILIES

__all__ = ["BlackOut", "CAM_KEYS", "DEFAULT_SEED", "pick_family", "FAMILIES"]
