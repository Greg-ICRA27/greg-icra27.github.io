"""Six corruption families (rain, droplets, dirt_dust, dirt_mud, dirt_smudge, dirt_extreme).

Each with base and high intensity levels.
"""
from .corruptions.augment_rain_dirt import (
    add_rain, add_dirt, add_lens_droplets,
    RAIN_LEVELS, DROPLET_LEVELS, DIRT_STYLES,
)

# "low" is the user/CLI-facing name for what the corruption code calls "base".
LEVEL_ALIASES = {"low": "base", "high": "high"}

FAMILIES = ("rain", "droplets", "dirt_dust", "dirt_mud", "dirt_smudge", "dirt_extreme")

# family -> {"func": callable(img_bgr, rng, **kwargs) -> img_bgr, "base": kwargs, "high": kwargs}
FAMILY_PRESETS = {
    "rain": {"func": add_rain, **RAIN_LEVELS},
    "droplets": {"func": add_lens_droplets, **DROPLET_LEVELS},
    "dirt_dust": {"func": add_dirt, **DIRT_STYLES["dust"]},
    "dirt_mud": {"func": add_dirt, **DIRT_STYLES["mud"]},
    "dirt_smudge": {"func": add_dirt, **DIRT_STYLES["smudge"]},
    "dirt_extreme": {"func": add_dirt, **DIRT_STYLES["extreme"]},
}


def apply_preset(img_bgr, rng, family, level):
    """Apply (family, level) corruption to BGR uint8 frame."""
    if family not in FAMILY_PRESETS:
        raise ValueError(f"Unknown blackout family {family!r}; choose from {FAMILIES}")
    preset = FAMILY_PRESETS[family]
    level_key = LEVEL_ALIASES.get(level, level)
    if level_key not in ("base", "high"):
        raise ValueError(f"Unknown blackout level {level!r}; choose from 'low', 'high'")
    return preset["func"](img_bgr, rng, **preset[level_key])
