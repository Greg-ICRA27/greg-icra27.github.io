"""Aggressive cut-in with a brake-check.

A car in the adjacent lane pulls up alongside the ego, then makes a committed
lane change into the ego's lane directly IN FRONT of it (a real, forward cut-in
— not a rear-quarter side-swipe) and immediately brake-checks, slowing hard.
The ego must brake / ease off to keep its distance. After the scene resolves,
the cutter accelerates away and despawns out of sight, keeping the route
completable.

Design rules:
  * The cut-in happens IN FRONT of the ego (user: "the type is a cut in ... it
    cuts in front of it"), never a rear collision.
  * ALL motion is apply_control physics — no set_transform teleports, no floating
    actors; the cutter steers and brakes with its own dynamics, wheels on road.
  * The trigger is geometry-driven (cutter pulls a fixed distance ahead of the
    ego before merging), so it looks the same for every agent regardless of speed.
  * No ego brake clamp / no forced ego speed — fair to both models. Speed-cap only.
"""

import os

import carla
import py_trees

from srunner.scenariomanager.carla_data_provider import CarlaDataProvider
from srunner.scenariomanager.scenarioatomics.atomic_criteria import CollisionTest
from srunner.scenariomanager.scenarioatomics.atomic_trigger_conditions import (
    InTriggerDistanceToLocation,
)
from srunner.scenariomanager.scenarioatomics.custom_atomics import (
    EgoSpeedGovernor,
    LaneCleaner,
    PeriodicStatusLogger,
    actor_speed,
    chase_control,
    lane_follow_control,
    planar_distance,
)
from srunner.scenariomanager.timer import GameTime
from srunner.scenarios.basic_scenario import BasicScenario


class _RunNaturalCutIn(py_trees.behaviour.Behaviour):
    """Deterministic physics state machine driving the cut-in car."""

    def __init__(self, scenario, name="RunNaturalCutIn"):
        super().__init__(name)
        self._s = scenario
        self._state = "pace"
        self._t0 = None
        self._ego_settled_since = None
        self._last_log = -99.0

    def initialise(self):
        self._t0 = GameTime.get_time()

    def _enter(self, state):
        print(f"[CutIn] state -> {state}  t={GameTime.get_time():.1f}", flush=True)
        self._state = state
        self._t0 = GameTime.get_time()

    def _ahead_of_ego(self, actor):
        """Signed forward distance of actor relative to the ego's heading (+ = ahead)."""
        ego_t = self._s._ego.get_transform()
        fwd = ego_t.get_forward_vector()
        d = actor.get_location() - ego_t.location
        return d.x * fwd.x + d.y * fwd.y

    def _target_in_ego_lane(self, ahead_m):
        """A world point ahead_m in front of the ego, snapped to the ego's lane centre."""
        world_map = CarlaDataProvider.get_map()
        ego_wp = world_map.get_waypoint(
            self._s._ego.get_location(), project_to_road=True,
            lane_type=carla.LaneType.Driving)
        if ego_wp is None:
            return None
        cursor, remaining = ego_wp, max(0.0, ahead_m)
        while remaining > 0.2 and cursor is not None:
            step = min(6.0, remaining)
            nxt = cursor.next(step)
            if not nxt:
                break
            cursor = nxt[0]
            remaining -= step
        return cursor.transform.location if cursor is not None else None

    def update(self):
        s = self._s
        cutter, ego = s._cutter, s._ego
        if cutter is None:
            return py_trees.common.Status.FAILURE
        now = GameTime.get_time()
        elapsed = now - self._t0 if self._t0 else 0.0
        world_map = CarlaDataProvider.get_map()
        alive = cutter.is_alive
        ahead = self._ahead_of_ego(cutter) if alive else 0.0

        if now - self._last_log > 1.5:
            self._last_log = now
            print(f"[CutIn] st={self._state} ego={actor_speed(ego)*3.6:.0f}km/h "
                  f"cutter_ahead={ahead:.1f}m", flush=True)

        if self._state == "pace":
            # Cutter accelerates in the adjacent lane to pull a set distance AHEAD
            # of the ego, matching+beating its speed so the merge is in front.
            if alive:
                target = max(actor_speed(ego) + s._pace_overspeed, s._min_pace_speed)
                cutter.apply_control(lane_follow_control(
                    world_map, cutter, target, max_throttle=1.0))
            if ahead >= s._cutin_ahead_m and actor_speed(ego) > 3.0:
                self._enter("cutin")

        elif self._state == "cutin":
            # Committed merge: steer toward a point in the ego's lane just ahead of
            # the ego, at speed, so the cutter crosses in FRONT of the ego.
            if alive:
                tgt = self._target_in_ego_lane(max(4.0, ahead + 2.0))
                if tgt is not None:
                    cutter.apply_control(chase_control(
                        cutter, tgt, throttle=0.55, steer_gain=1.1))
                try:
                    cutter.set_light_state(carla.VehicleLightState.LeftBlinker)
                except Exception:
                    pass
            # Once the cutter is in the ego's lane (same lane id) and still ahead, brake-check.
            in_ego_lane = False
            if alive:
                c_wp = world_map.get_waypoint(cutter.get_location(),
                                              project_to_road=True, lane_type=carla.LaneType.Driving)
                e_wp = world_map.get_waypoint(ego.get_location(),
                                              project_to_road=True, lane_type=carla.LaneType.Driving)
                in_ego_lane = (c_wp is not None and e_wp is not None
                               and c_wp.lane_id == e_wp.lane_id and c_wp.road_id == e_wp.road_id)
            if (in_ego_lane and ahead < s._brake_check_gap) or elapsed > s._cutin_max_s:
                self._enter("brake_check")

        elif self._state == "brake_check":
            # Cutter slams a moderate brake in front of the ego (the brake-check).
            if alive:
                cutter.apply_control(carla.VehicleControl(brake=s._brake_check_force, steer=0.0))
                try:
                    cutter.set_light_state(carla.VehicleLightState.Brake)
                except Exception:
                    pass
            if elapsed > s._brake_check_s:
                self._enter("hold")

        elif self._state == "hold":
            # Cutter sits slowed/stopped in front until the ego has reacted (slowed
            # behind it or passed), then recovers. A hard cap guarantees the route ends.
            if alive:
                cutter.apply_control(carla.VehicleControl(brake=1.0))
            gap = ahead
            ego_reacted = gap < s._ego_react_gap and actor_speed(ego) < s._ego_react_speed
            ego_passed = alive and ahead < -3.0
            if ego_reacted:
                if self._ego_settled_since is None:
                    self._ego_settled_since = now
            else:
                self._ego_settled_since = None
            settled = (self._ego_settled_since is not None
                       and now - self._ego_settled_since > s._hold_after_react_s)
            if settled or ego_passed or elapsed > s._hold_max_s:
                self._enter("clear")

        elif self._state == "clear":
            if not alive:
                return py_trees.common.Status.SUCCESS
            cutter.apply_control(lane_follow_control(world_map, cutter, s._clear_speed))
            far = planar_distance(cutter.get_location(), ego.get_location()) > s._vanish_distance
            if far or elapsed > s._clear_max_s:
                try:
                    cutter.destroy()
                except RuntimeError:
                    pass
                return py_trees.common.Status.SUCCESS

        return py_trees.common.Status.RUNNING


class FollowingPileupTrigger(BasicScenario):
    """Natural aggressive cut-in + brake-check directly in front of the ego."""

    timeout = 180

    @staticmethod
    def _get_param(op, name, default, cast=float):
        if not op or name not in op:
            return default
        raw = op[name]
        try:
            if isinstance(raw, dict):
                return cast(raw.get("value", default))
            return cast(raw)
        except (TypeError, ValueError):
            return default

    @staticmethod
    def _walk_waypoint(waypoint, distance, forward=True):
        remaining = abs(float(distance))
        cursor = waypoint
        while remaining > 0.2 and cursor is not None:
            step = min(8.0, remaining)
            candidates = cursor.next(step) if forward else cursor.previous(step)
            if not candidates:
                break
            cursor = candidates[0]
            remaining -= step
        return cursor

    def __init__(self, world, ego_vehicles, config,
                 randomize=False, debug_mode=False, criteria_enable=True,
                 timeout=180):
        self._world = world
        self._map = CarlaDataProvider.get_map()
        self._ego = ego_vehicles[0]

        op = dict(config.other_parameters) if hasattr(config, "other_parameters") else {}
        if hasattr(config, "scenario") and hasattr(config.scenario, "other_parameters"):
            op.update(config.scenario.other_parameters)

        self._activation_distance = self._get_param(op, "activation_distance_m", 140.0)
        self._cutter_spawn_behind = self._get_param(op, "cutter_spawn_behind_m", 8.0)
        self._pace_overspeed = self._get_param(op, "pace_overspeed_mps", 4.5)
        self._min_pace_speed = self._get_param(op, "min_pace_speed_kmh", 55.0) / 3.6
        self._cutin_ahead_m = self._get_param(op, "cutin_ahead_m", 7.0)
        self._cutin_max_s = self._get_param(op, "cutin_max_s", 4.0)
        self._brake_check_gap = self._get_param(op, "brake_check_gap_m", 12.0)
        self._brake_check_force = self._get_param(op, "brake_check_force", 0.7)
        self._brake_check_s = self._get_param(op, "brake_check_s", 1.6)
        self._ego_react_gap = self._get_param(op, "ego_react_gap_m", 14.0)
        self._ego_react_speed = self._get_param(op, "ego_react_speed_mps", 3.0)
        self._hold_after_react_s = self._get_param(op, "hold_after_react_s", 3.5)
        self._hold_max_s = self._get_param(op, "hold_max_s", 22.0)
        self._clear_speed = self._get_param(op, "clear_speed_kmh", 55.0) / 3.6
        self._clear_max_s = self._get_param(op, "clear_max_s", 16.0)
        self._vanish_distance = self._get_param(op, "vanish_distance_m", 70.0)
        self._ego_speed_cap_kmh = self._get_param(op, "ego_speed_cap_kmh", 90.0)
        self._road_friction_scale = self._get_param(op, "road_friction_scale", 0.78)

        self._trigger_wp = self._map.get_waypoint(config.trigger_points[0].location)
        self._cutter = None
        self._cutter_side = "left"

        super().__init__(
            name="FollowingPileupTrigger",
            ego_vehicles=ego_vehicles,
            config=config,
            world=world,
            debug_mode=debug_mode,
            terminate_on_failure=True,
            criteria_enable=criteria_enable,
        )

    def _initialize_environment(self, world):
        super()._initialize_environment(world)
        if os.environ.get("ICY_ROAD_FRICTION"):
            return
        friction = max(0.1, float(self._road_friction_scale))
        if abs(friction - 1.0) < 1e-6:
            return
        bp = world.get_blueprint_library().find("static.trigger.friction")
        bp.set_attribute("friction", str(friction))
        bp.set_attribute("extent_x", "1000000.0")
        bp.set_attribute("extent_y", "1000000.0")
        bp.set_attribute("extent_z", "1000000.0")
        try:
            world.spawn_actor(bp, carla.Transform(carla.Location(-10000.0, -10000.0, 0.0)))
        except RuntimeError:
            pass

    def _initialize_actors(self, config):
        ego_wp = self._map.get_waypoint(
            self._ego.get_location(), project_to_road=True,
            lane_type=carla.LaneType.Driving)
        left_wp = ego_wp.get_left_lane()
        right_wp = ego_wp.get_right_lane()
        if left_wp is not None and left_wp.lane_type == carla.LaneType.Driving:
            adjacent_wp = left_wp
            self._cutter_side = "left"
        elif right_wp is not None and right_wp.lane_type == carla.LaneType.Driving:
            adjacent_wp = right_wp
            self._cutter_side = "right"
        else:
            adjacent_wp = ego_wp
            self._cutter_side = "left"

        spawn_wp = self._walk_waypoint(adjacent_wp, self._cutter_spawn_behind, forward=False) or adjacent_wp
        transform = carla.Transform(
            carla.Location(
                spawn_wp.transform.location.x,
                spawn_wp.transform.location.y,
                spawn_wp.transform.location.z + 0.3,
            ),
            spawn_wp.transform.rotation,
        )
        for model in ("vehicle.tesla.model3", "vehicle.audi.tt", "vehicle.dodge.charger_2020"):
            self._cutter = CarlaDataProvider.request_new_actor(
                model, transform, rolename="cutin_vehicle", color="220,40,40")
            if self._cutter is not None:
                break
        if self._cutter is None:
            raise RuntimeError("[CutIn] cutter spawn failed")
        self._cutter.set_simulate_physics(True)
        self._cutter.set_target_velocity(carla.Vector3D(0.0, 0.0, 0.0))
        self.other_actors.append(self._cutter)

        print(
            f"\n[CutIn/NATURAL] Spawn\n"
            f"  Ego road={ego_wp.road_id} lane={ego_wp.lane_id}\n"
            f"  Cutter side={self._cutter_side} spawn_behind={self._cutter_spawn_behind:.0f}m "
            f"cutin_ahead={self._cutin_ahead_m:.0f}m brake_check_gap={self._brake_check_gap:.0f}m\n",
            flush=True,
        )

    def _setup_scenario_trigger(self, config):
        return InTriggerDistanceToLocation(
            self._ego,
            self._trigger_wp.transform.location,
            self._activation_distance,
            name="ActivateCutIn",
        )

    def _create_behavior(self):
        root = py_trees.composites.Sequence("CutInNatural_Root")
        root.add_child(_RunNaturalCutIn(self))

        lanes = [self._trigger_wp]
        for lane in (self._trigger_wp.get_left_lane(), self._trigger_wp.get_right_lane()):
            if lane is not None and lane.lane_type == carla.LaneType.Driving:
                lanes.append(lane)

        outer = py_trees.composites.Parallel(
            "CutInNatural_Outer", policy=py_trees.common.ParallelPolicy.SUCCESS_ON_ONE)
        outer.add_child(root)
        outer.add_child(LaneCleaner(
            protected_actors=[a for a in (self._ego, self._cutter) if a is not None],
            lane_waypoints=lanes,
            center_location=self._trigger_wp.transform.location,
            radius=450.0, interval=1.0, name="ScenarioLaneCleaner"))
        outer.add_child(PeriodicStatusLogger(
            self._ego, self._cutter, None, interval=2.0, name="StatusLogger"))
        outer.add_child(EgoSpeedGovernor(
            self._ego, speed_cap_kmh=self._ego_speed_cap_kmh, brake_force=0.3,
            name="EgoSpeedGovernor"))
        return outer

    def _create_test_criteria(self):
        return [CollisionTest(self._ego)]

    def __del__(self):
        self.remove_all_actors()
