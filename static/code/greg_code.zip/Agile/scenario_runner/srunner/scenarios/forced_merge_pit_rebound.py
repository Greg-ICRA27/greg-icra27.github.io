"""Forced merge / PIT rebound.

A speeding striker in the adjacent lane rams the rear-quarter of a slower victim
car ahead (real collision physics). The startled victim swerves across into the
ego's lane and stops, partially blocking it; the striker stops in the adjacent
lane. After the scene holds (and the ego has caught up / reacted), both drivers
pull away down the road and despawn only once far from the ego.

Design rules:
  * ALL actor motion is apply_control physics — no set_transform teleports, no
    hovering, wheels always on the road.
  * The accident fires when the STRIKER catches the VICTIM (ego-independent),
    so a cautious ego can never deadlock the scene.
  * No ego brake-clamping (fair for both models). A top-speed governor only.
  * The blockage clears (drivers leave) so the route stays completable.
"""

import math
import os

import carla
import py_trees

from srunner.scenariomanager.carla_data_provider import CarlaDataProvider
from srunner.scenariomanager.scenarioatomics.atomic_criteria import CollisionTest
from srunner.scenariomanager.scenarioatomics.atomic_trigger_conditions import (
    InTriggerDistanceToLocation,
)
from srunner.scenariomanager.scenarioatomics.custom_atomics import (
    EgoSpeedGovernor,
    LaneCleaner,
    PeriodicStatusLogger,
    actor_speed,
    chase_control,
    lane_follow_control,
    planar_distance,
)
from srunner.scenariomanager.timer import GameTime
from srunner.scenarios.basic_scenario import BasicScenario


class _RunNaturalForcedMerge(py_trees.behaviour.Behaviour):
    """Single deterministic state machine driving victim + striker with physics."""

    def __init__(self, scenario, name="RunNaturalForcedMerge"):
        super().__init__(name)
        self._s = scenario
        self._state = "cruise"
        self._t0 = None
        self._impact = False
        self._sensor = None
        self._ego_settled_since = None

    def initialise(self):
        self._t0 = GameTime.get_time()
        if self._sensor is None and self._s._striker is not None:
            world = CarlaDataProvider.get_world()
            bp = world.get_blueprint_library().find("sensor.other.collision")
            self._sensor = world.spawn_actor(
                bp, carla.Transform(), attach_to=self._s._striker)
            self._sensor.listen(self._on_collision)

    def _on_collision(self, event):
        other = getattr(event, "other_actor", None)
        if other is not None and self._s._victim is not None and other.id == self._s._victim.id:
            self._impact = True

    def _enter(self, state):
        print(f"[ForcedMerge] state -> {state}  t={GameTime.get_time():.1f}", flush=True)
        self._state = state
        self._t0 = GameTime.get_time()

    def update(self):
        s = self._s
        victim, striker, ego = s._victim, s._striker, s._ego
        if victim is None or striker is None:
            return py_trees.common.Status.FAILURE
        now = GameTime.get_time()
        elapsed = now - self._t0 if self._t0 else 0.0
        world_map = CarlaDataProvider.get_map()

        alive_v = victim.is_alive
        alive_s = striker.is_alive

        if self._state == "cruise":
            # Normal traffic ahead of the ego: victim cruises; the striker holds a
            # gap BEHIND the victim (pacing at the victim's speed) until the EGO has
            # closed to within ego_trigger_gap — so the crash happens right as the
            # ego comes upon it (like a real accident unfolding ahead), giving a
            # reaction-limited but reliable margin rather than an ego-independent
            # event far up the road that both agents calmly brake for.
            ego_to_victim = planar_distance(ego.get_location(), victim.get_location()) if alive_v else 999.0
            if alive_v:
                victim.apply_control(lane_follow_control(world_map, victim, s._victim_speed))
            if alive_s:
                if ego_to_victim > s._ego_trigger_gap:
                    striker.apply_control(lane_follow_control(
                        world_map, striker, s._victim_speed))  # pace, hold the gap
                else:
                    striker.apply_control(lane_follow_control(
                        world_map, striker, s._striker_speed, max_throttle=1.0))  # charge
            charging = alive_v and ego_to_victim <= s._ego_trigger_gap
            if charging and alive_s and planar_distance(
                    striker.get_location(), victim.get_location()) < s._ram_gap:
                self._enter("ram")

        elif self._state == "ram":
            # Striker aims for the victim's left-rear quarter — a real PIT hit.
            if alive_v:
                victim.apply_control(lane_follow_control(world_map, victim, s._victim_speed))
            if alive_s and alive_v:
                tr = victim.get_transform()
                fwd = tr.get_forward_vector()
                rgt = tr.get_right_vector()
                aim = carla.Location(
                    tr.location.x - fwd.x * 1.8 + rgt.x * s._ram_side * 0.7,
                    tr.location.y - fwd.y * 1.8 + rgt.y * s._ram_side * 0.7,
                    tr.location.z)
                striker.apply_control(chase_control(striker, aim, throttle=1.0))
            if self._impact or elapsed > 6.0:
                self._enter("panic")

        elif self._state == "panic":
            # Victim, just hit, careens toward the EGO'S OWN LANE: steer via pursuit
            # of a point ahead in the ego's lane, so the wreck always ends up in the
            # ego's path no matter how many lanes separate them.
            in_ego_lane = False
            if alive_v:
                ego_wp = world_map.get_waypoint(
                    ego.get_location(), project_to_road=True,
                    lane_type=carla.LaneType.Driving)
                victim_wp = world_map.get_waypoint(
                    victim.get_location(), project_to_road=True,
                    lane_type=carla.LaneType.Driving)
                target = None
                if ego_wp is not None:
                    ahead = planar_distance(ego.get_location(), victim.get_location()) + 10.0
                    cursor, remaining = ego_wp, ahead
                    while remaining > 0.2 and cursor is not None:
                        step = min(8.0, remaining)
                        nxt = cursor.next(step)
                        if not nxt:
                            break
                        cursor = nxt[0]
                        remaining -= step
                    target = cursor.transform.location if cursor is not None else None
                    in_ego_lane = (victim_wp is not None
                                   and victim_wp.lane_id == ego_wp.lane_id
                                   and victim_wp.road_id == ego_wp.road_id)
                if target is not None:
                    victim.apply_control(chase_control(victim, target, throttle=0.35, steer_gain=1.0))
                else:
                    victim.apply_control(carla.VehicleControl(
                        steer=s._toward_ego_steer, throttle=0.30))
                try:
                    victim.set_light_state(carla.VehicleLightState(
                        carla.VehicleLightState.RightBlinker | carla.VehicleLightState.LeftBlinker))
                except Exception:
                    pass
            if alive_s:
                striker.apply_control(carla.VehicleControl(brake=0.75))
            if in_ego_lane or elapsed > s._panic_max_s:
                self._enter("settle")

        elif self._state == "settle":
            if alive_v:
                victim.apply_control(carla.VehicleControl(brake=1.0))
            if alive_s:
                striker.apply_control(carla.VehicleControl(brake=1.0))
            if elapsed > 1.6:
                self._enter("block")

        elif self._state == "block":
            # Wreck holds. Ends when the ego has arrived and settled behind it
            # (or passed it), or after a hard cap so the route can always finish.
            for actor, alive in ((victim, alive_v), (striker, alive_s)):
                if alive:
                    actor.apply_control(carla.VehicleControl(brake=1.0, hand_brake=True))
            ego_gap = planar_distance(ego.get_location(), victim.get_location()) if alive_v else 99.0
            ego_arrived = ego_gap < s._ego_arrive_gap and actor_speed(ego) < 1.0
            ego_passed = False
            if alive_v:
                fwd = victim.get_transform().get_forward_vector()
                delta = ego.get_location() - victim.get_location()
                ego_passed = (delta.x * fwd.x + delta.y * fwd.y) > 4.0
            if ego_arrived:
                if self._ego_settled_since is None:
                    self._ego_settled_since = now
            else:
                self._ego_settled_since = None
            settled_long_enough = (
                self._ego_settled_since is not None
                and now - self._ego_settled_since > s._block_hold_after_stop)
            if settled_long_enough or ego_passed or elapsed > s._block_max_s:
                self._enter("clear")

        elif self._state == "clear":
            # Drivers recover and leave; despawn handled outside camera range.
            done_v = self._drive_off(victim, world_map, elapsed)
            done_s = self._drive_off(striker, world_map, elapsed)
            if done_v and done_s:
                return py_trees.common.Status.SUCCESS

        return py_trees.common.Status.RUNNING

    def _drive_off(self, actor, world_map, elapsed):
        if actor is None or not actor.is_alive:
            return True
        actor.apply_control(lane_follow_control(world_map, actor, self._s._clear_speed))
        far = planar_distance(actor.get_location(), self._s._ego.get_location()) > self._s._vanish_distance
        if far or elapsed > self._s._clear_max_s:
            try:
                actor.destroy()
            except RuntimeError:
                pass
            return True
        return False

    def terminate(self, new_status):
        if self._sensor is not None and self._sensor.is_alive:
            try:
                self._sensor.stop()
                self._sensor.destroy()
            except RuntimeError:
                pass
            self._sensor = None
        super().terminate(new_status)


class ForcedMergePitRebound(BasicScenario):
    """Natural-physics striker-rams-victim merge accident ahead of the ego."""

    timeout = 180

    @staticmethod
    def _get_param(op, name, default, cast=float):
        if not op or name not in op:
            return default
        raw = op[name]
        try:
            if isinstance(raw, dict):
                return cast(raw.get("value", default))
            return cast(raw)
        except (TypeError, ValueError):
            return default

    @staticmethod
    def _walk_waypoint(waypoint, distance, forward=True):
        remaining = abs(float(distance))
        cursor = waypoint
        while remaining > 0.2 and cursor is not None:
            step = min(8.0, remaining)
            candidates = cursor.next(step) if forward else cursor.previous(step)
            if not candidates:
                break
            cursor = candidates[0]
            remaining -= step
        return cursor

    def __init__(self, world, ego_vehicles, config,
                 randomize=False, debug_mode=False,
                 criteria_enable=True, timeout=180):
        self._world = world
        self._map = CarlaDataProvider.get_map()
        self._ego = ego_vehicles[0]

        op = config.other_parameters if hasattr(config, "other_parameters") else {}
        self._activation_distance = self._get_param(op, "activation_distance_m", 95.0)
        self._victim_spawn_ahead = self._get_param(op, "victim_spawn_ahead_m", 34.0)
        self._striker_spawn_ahead = self._get_param(op, "striker_spawn_ahead_m", 8.0)
        self._victim_speed = self._get_param(op, "victim_speed_kmh", 42.0) / 3.6
        self._striker_speed = self._get_param(op, "striker_speed_kmh", 85.0) / 3.6
        self._ram_gap = self._get_param(op, "ram_trigger_gap_m", 11.0)
        self._ego_trigger_gap = self._get_param(op, "ego_trigger_gap_m", 999.0)
        self._panic_duration = self._get_param(op, "panic_duration_s", 0.75)
        self._panic_max_s = self._get_param(op, "panic_max_s", 3.5)
        self._block_hold_after_stop = self._get_param(op, "block_hold_after_stop_s", 4.0)
        self._block_max_s = self._get_param(op, "block_max_s", 30.0)
        self._ego_arrive_gap = self._get_param(op, "ego_arrive_gap_m", 24.0)
        self._clear_speed = self._get_param(op, "clear_speed_kmh", 45.0) / 3.6
        self._clear_max_s = self._get_param(op, "clear_max_s", 18.0)
        self._vanish_distance = self._get_param(op, "vanish_distance_m", 70.0)
        self._ego_speed_cap_kmh = self._get_param(op, "ego_speed_cap_kmh", 80.0)

        self._trigger_wp = self._map.get_waypoint(config.trigger_points[0].location)
        self._victim = None
        self._striker = None
        self._merge_side_wp = None
        self._toward_ego_steer = -0.35
        self._ram_side = -1.0

        super().__init__(
            name="ForcedMergePitRebound",
            ego_vehicles=ego_vehicles,
            config=config,
            world=world,
            debug_mode=debug_mode,
            terminate_on_failure=True,
            criteria_enable=criteria_enable,
        )

    def _choose_merge_lane(self, ego_wp):
        right_lane = ego_wp.get_right_lane()
        if right_lane is not None and right_lane.lane_type == carla.LaneType.Driving:
            return right_lane, "right"
        left_lane = ego_wp.get_left_lane()
        if left_lane is not None and left_lane.lane_type == carla.LaneType.Driving:
            return left_lane, "left"
        return None, None

    def _spawn(self, models, waypoint, rolename, color=None):
        transform = carla.Transform(
            carla.Location(
                waypoint.transform.location.x,
                waypoint.transform.location.y,
                waypoint.transform.location.z + 0.3,
            ),
            waypoint.transform.rotation,
        )
        for model in models:
            actor = CarlaDataProvider.request_new_actor(
                model, transform, rolename=rolename, color=color)
            if actor is not None:
                actor.set_simulate_physics(True)
                actor.set_target_velocity(carla.Vector3D(0.0, 0.0, 0.0))
                self.other_actors.append(actor)
                return actor
        return None

    def _initialize_actors(self, config):
        ego_wp = self._map.get_waypoint(
            self._ego.get_location(), project_to_road=True,
            lane_type=carla.LaneType.Driving)
        self._merge_side_wp, side = self._choose_merge_lane(ego_wp)
        if self._merge_side_wp is None:
            raise RuntimeError("[ForcedMerge] No adjacent lane for the accident")

        # Steering sign that takes the victim from the merge lane toward the ego lane.
        self._toward_ego_steer = -0.38 if side == "right" else 0.38
        # Striker aims at the victim's rear quarter on the side AWAY from the ego
        # lane, so the spin sends the victim's nose toward the ego lane.
        self._ram_side = 1.0 if side == "right" else -1.0

        victim_wp = self._walk_waypoint(self._merge_side_wp, self._victim_spawn_ahead, True) or self._merge_side_wp
        striker_wp = self._walk_waypoint(self._merge_side_wp, self._striker_spawn_ahead, True) or self._merge_side_wp

        self._victim = self._spawn(
            ["vehicle.nissan.patrol", "vehicle.audi.etron", "vehicle.tesla.model3"],
            victim_wp, "merge_victim", color="200,200,205")
        if self._victim is None:
            raise RuntimeError("[ForcedMerge] victim spawn failed")
        self._striker = self._spawn(
            ["vehicle.dodge.charger_2020", "vehicle.audi.tt", "vehicle.tesla.model3"],
            striker_wp, "merge_striker", color="25,25,30")
        if self._striker is None:
            raise RuntimeError("[ForcedMerge] striker spawn failed")

        print(
            f"\n[ForcedMerge/NATURAL] Spawn\n"
            f"  Ego road={ego_wp.road_id} lane={ego_wp.lane_id}\n"
            f"  Victim lane={victim_wp.lane_id} ahead={self._victim_spawn_ahead:.0f}m @ {self._victim_speed*3.6:.0f}km/h\n"
            f"  Striker lane={striker_wp.lane_id} ahead={self._striker_spawn_ahead:.0f}m @ {self._striker_speed*3.6:.0f}km/h\n"
            f"  side={side} ram_gap={self._ram_gap:.0f}m\n",
            flush=True,
        )

    def _setup_scenario_trigger(self, config):
        return InTriggerDistanceToLocation(
            self._ego,
            self._trigger_wp.transform.location,
            self._activation_distance,
            name="ActivateForcedMergePitRebound",
        )

    def _create_behavior(self):
        root = py_trees.composites.Sequence("ForcedMergeNatural_Root")
        root.add_child(_RunNaturalForcedMerge(self))

        protected = [self._ego, self._victim, self._striker]
        lanes = [self._trigger_wp]
        if self._merge_side_wp is not None:
            lanes.append(self._merge_side_wp)

        outer = py_trees.composites.Parallel(
            "ForcedMergeNatural_Outer",
            policy=py_trees.common.ParallelPolicy.SUCCESS_ON_ONE,
        )
        outer.add_child(root)
        outer.add_child(LaneCleaner(
            protected_actors=protected,
            lane_waypoints=lanes,
            center_location=self._trigger_wp.transform.location,
            radius=450.0,
            interval=1.0,
            name="ScenarioLaneCleaner",
        ))
        outer.add_child(PeriodicStatusLogger(
            self._ego, self._striker, self._victim,
            interval=1.0, name="StatusLogger",
        ))
        # Top-speed cap only — NO brake clamping (models keep full brake authority).
        outer.add_child(EgoSpeedGovernor(
            self._ego,
            speed_cap_kmh=self._ego_speed_cap_kmh,
            brake_force=0.3,
            name="EgoSpeedGovernor",
        ))
        return outer

    def _create_test_criteria(self):
        return [CollisionTest(self._ego)]

    def __del__(self):
        self.remove_all_actors()
