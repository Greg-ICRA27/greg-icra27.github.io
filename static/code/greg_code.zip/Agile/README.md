# Agile -- adversarial scenario benchmark harness

CARLA / Bench2Drive-style benchmark harness: custom scenario implementation code
+ route data, plus the leaderboard evaluator + scenario_runner framework they run on. It does
**not** contain any model code or checkpoints — run routes with `team_agent/test_GREG.py` (the
GREG agent, model from `Greg_RL/GREG_RL_worker/Greg`).

## Directory layout

| Dir | Contents |
|---|---|
| `leaderboard/leaderboard/`, `leaderboard/scripts/` | CARLA leaderboard evaluator package + `run_evaluation.sh` — needed to run a route |
| `leaderboard/data/weather.xml` | Required by the evaluator regardless of which route runs |
| `leaderboard/data/main/Agile.xml` | The active route set — 7 scenarios x 4 weather variants (28 routes) |
| `scenario_runner/` | Custom `scenario_runner` — `srunner/scenarios/`, `srunner/scenariomanager/scenarioatomics/custom_atomics.py`. Required: the active routes reference scenario classes (`FollowingPileupTrigger`, etc.) that only exist here, not in upstream Bench2Drive's `scenario_runner`. |

## Running a route

There is no Agile-specific eval script — `team_agent/run_test_route.sh` and
`team_agent/eval/queue_eval.py` are framework-agnostic and take the framework root + routes file
as placeholders, so point them at this package instead of Bench2Drive's:

```bash
FRAMEWORK_ROOT=$FRAMEWORK_ROOT \
ROUTES=$FRAMEWORK_ROOT/leaderboard/data/main/Agile.xml \
$GREG_ROOT/team_agent/run_test_route.sh 31   # route id from the routes xml, e.g. 31
```

For parallel/queued runs across multiple routes and GPUs, set the same framework root via
`EVAL_FRAMEWORK_ROOT` and use `queue_eval.py`:

```bash
EVAL_FRAMEWORK_ROOT=$FRAMEWORK_ROOT \
python3 team_agent/eval/queue_eval.py \
  --routes-file=$FRAMEWORK_ROOT/leaderboard/data/main/Agile.xml \
  --route-ids=31,32,41,42 --gpus=0,1 --slots-per-gpu=2
```

Route ids come from the `id` attribute in the routes xml; `--route-ids`/the positional arg to
`run_test_route.sh` accept a single id, a comma-separated list, or a dash range (e.g. `31-34`).

`GREG_IL_CKPT`/`RL_CKPT`/`CARLA_ROOT`/`B2D_ROOT` still come from `team_agent/.env` (`B2D_ROOT` is
also the default `FRAMEWORK_ROOT`/routes file when the overrides above aren't set). Set
`GREG_BLACKOUT_LEVEL` (none/low/high) to run the same route with camera corruption — see
`BlackOut/README.md`.
