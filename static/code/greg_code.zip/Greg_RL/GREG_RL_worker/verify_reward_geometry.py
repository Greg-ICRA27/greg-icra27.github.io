#!/usr/bin/env python
"""Verify reward-geometry functions (lane centering, emergency detection, desired speed) against CARLA."""
import argparse, math, random, sys, time
import carla

def offset_axis(ego_loc, wp):
    """Lateral offset approximated by the global Y-axis difference only."""
    return abs(ego_loc.y - wp.transform.location.y)

def offset_perp(ego_loc, wp):
    """Perpendicular distance, via projection onto the lane right (unit) vector."""
    r = wp.transform.get_right_vector()
    dx = ego_loc.x - wp.transform.location.x
    dy = ego_loc.y - wp.transform.location.y
    return abs(dx * r.x + dy * r.y)

def emergency_same_lane(ego_vehicle, world, max_distance=50.0):
    """Reproduction of scenario_manager.is_in_same_lane_as_any_emergency_vehicle."""
    ego_location = ego_vehicle.get_location()
    carla_map = world.get_map()
    ego_wp = carla_map.get_waypoint(ego_location, project_to_road=True, lane_type=carla.LaneType.Driving)
    if ego_wp is None or ego_wp.is_junction:
        return False, False
    emerg = [a for a in world.get_actors()
             if 'vehicle' in a.type_id and a.attributes.get('special_type') == 'emergency']
    if not emerg:
        return False, False
    for ev in emerg:
        try:
            eloc = ev.get_location()
            if ego_location.distance(eloc) > max_distance:
                continue
            ewp = carla_map.get_waypoint(eloc, project_to_road=True, lane_type=carla.LaneType.Driving)
            if ewp is None or ewp.is_junction:
                continue
            if ego_wp.road_id == ewp.road_id and ego_wp.lane_id == ewp.lane_id:
                return True, True
        except RuntimeError:
            continue
    return False, True

def desired_speed(ego_vehicle, world, max_distance=30.0, max_lateral=4.0):
    """Reproduction of the current agent _get_desired_speed core (ACC + limit + red light).
    Stop-sign branch omitted (needs the reward stop criterion)."""
    try:
        v_lim = ego_vehicle.get_speed_limit() / 3.6
    except Exception:
        v_lim = 8.33
    if v_lim <= 0.1:
        v_lim = 8.33
    # red light hard override
    try:
        if ego_vehicle.is_at_traffic_light() and ego_vehicle.get_traffic_light_state() == carla.TrafficLightState.Red:
            return 0.0, v_lim
    except Exception:
        pass
    tf = ego_vehicle.get_transform()
    loc = tf.location
    fwd = tf.get_forward_vector()
    v_star = v_lim
    lead_speed = None
    nearest = max_distance
    for v in world.get_actors().filter('*vehicle*'):
        if v.id == ego_vehicle.id:
            continue
        l = v.get_location()
        dx, dy = l.x - loc.x, l.y - loc.y
        lon = dx * fwd.x + dy * fwd.y
        lat = abs(-dx * fwd.y + dy * fwd.x)
        if lon <= 0 or lon > nearest or lat > max_lateral:
            continue
        vel = v.get_velocity()
        if (vel.x * fwd.x + vel.y * fwd.y) < 0:
            continue
        nearest = lon
        lead_speed = (vel.x ** 2 + vel.y ** 2 + vel.z ** 2) ** 0.5
    if lead_speed is not None:
        v_star = min(v_lim, lead_speed)
    return float(v_star), v_lim

def yaw_bin(yaw):
    y = yaw % 180.0
    if y < 22.5 or y >= 157.5:  return "E-W (yaw~0/180)"
    if 67.5 <= y < 112.5:       return "N-S (yaw~90)"
    return "diagonal"

def teleport(world, ego, transform):
    ego.set_transform(transform)
    world.tick()
    return ego.get_transform().location

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=3000)
    ap.add_argument("--town", default="Town05")
    ap.add_argument("--n", type=int, default=90, help="waypoints for centering test")
    args = ap.parse_args()

    client = carla.Client("localhost", args.port)
    client.set_timeout(60.0)
    print("CARLA server:", client.get_server_version(), flush=True)
    world = client.load_world(args.town)
    time.sleep(2.0)
    amap = world.get_map()

    settings = world.get_settings()
    settings.synchronous_mode = True
    settings.fixed_delta_seconds = 0.05
    world.apply_settings(settings)
    tm = None

    bp = world.get_blueprint_library()
    ego_bp = bp.filter("vehicle.tesla.model3")[0]

    # spawn ego somewhere valid
    sps = amap.get_spawn_points()
    ego = None
    for sp in sps:
        ego = world.try_spawn_actor(ego_bp, sp)
        if ego is not None:
            break
    if ego is None:
        print("FAILED to spawn ego"); return
    ego.set_simulate_physics(False)
    world.tick()

    print("\n" + "=" * 78)
    print("TEST 1  LANE CENTERING  (impose a known lateral offset; axis vs perpendicular)")
    print("=" * 78)
    wps = [w for w in amap.generate_waypoints(6.0)
           if w.lane_type == carla.LaneType.Driving and not w.is_junction and w.lane_width > 2.0]
    random.seed(0); random.shuffle(wps)
    wps = wps[:args.n]
    offsets = [0.0, 0.4, 0.8, -0.6]     # meters lateral (right vector), within a ~3.5 m lane
    from collections import defaultdict
    agg = defaultdict(lambda: {"axis_err": [], "perp_err": [], "n": 0})
    for w in wps:
        b = yaw_bin(w.transform.rotation.yaw)
        r = w.transform.get_right_vector()
        for k in offsets:
            loc = carla.Location(x=w.transform.location.x + k * r.x,
                                 y=w.transform.location.y + k * r.y,
                                 z=w.transform.location.z + 0.3)
            real = teleport(world, ego, carla.Transform(loc, w.transform.rotation))
            pj = amap.get_waypoint(real, project_to_road=True, lane_type=carla.LaneType.Driving)
            if pj is None:
                continue
            gt = abs(k)
            agg[b]["axis_err"].append(abs(offset_axis(real, pj) - gt))
            agg[b]["perp_err"].append(abs(offset_perp(real, pj) - gt))
            agg[b]["n"] += 1
    print(f"{'orientation':<20}{'n':>5}{'axis mean|err| (m)':>20}{'perp mean|err| (m)':>20}")
    print("-" * 65)
    ok = True
    for b in ["E-W (yaw~0/180)", "N-S (yaw~90)", "diagonal"]:
        d = agg[b]
        if d["n"] == 0:
            continue
        oe = sum(d["axis_err"]) / d["n"]; ne = sum(d["perp_err"]) / d["n"]
        print(f"{b:<20}{d['n']:>5}{oe:>20.3f}{ne:>20.3f}")
        if ne > 0.15:
            ok = False
    print(f"\n  => perpendicular must be small (<0.15 m) on ALL rows; axis-only blows up on N-S. "
          f"{'PASS' if ok else 'FAIL'}")

    print("\n" + "=" * 78)
    print("TEST 2  EMERGENCY VEHICLE  (same-lane / adjacent-lane / none)")
    print("=" * 78)
    emerg_bps = [b for b in bp.filter("vehicle.*") if b.has_attribute("special_type") and
                 b.get_attribute("special_type").as_str() == "emergency"]
    print("  emergency blueprints available:", [b.id for b in emerg_bps][:5])
    # place ego on a straight driving lane
    base = None
    for w in amap.generate_waypoints(6.0):
        if w.lane_type == carla.LaneType.Driving and not w.is_junction:
            nxt = w.next(15.0)
            if nxt:
                base = w; break
    teleport(world, ego, base.transform)
    def spawn_emerg(wp):
        for eb in emerg_bps:
            a = world.try_spawn_actor(eb, carla.Transform(
                carla.Location(wp.transform.location.x, wp.transform.location.y, wp.transform.location.z + 0.3),
                wp.transform.rotation))
            if a:
                a.set_simulate_physics(False); world.tick(); return a
        return None
    r0 = emergency_same_lane(ego, world)
    print(f"  no emergency present            -> {r0}   (expect (False, False))")
    ahead = base.next(12.0)[0]
    ev1 = spawn_emerg(ahead)
    r1 = emergency_same_lane(ego, world) if ev1 else None
    print(f"  emergency SAME lane, 12 m ahead -> {r1}   (expect (True, True))")
    if ev1: ev1.destroy(); world.tick()
    left = base.get_left_lane()
    ev2 = None
    if left and left.lane_type == carla.LaneType.Driving:
        la = left.next(12.0)[0] if left.next(12.0) else left
        ev2 = spawn_emerg(la)
        r2 = emergency_same_lane(ego, world) if ev2 else None
        print(f"  emergency ADJACENT lane         -> {r2}   (expect (False, True))")
        if ev2: ev2.destroy(); world.tick()
    else:
        print("  (no adjacent driving lane here; skipped adjacent case)")

    print("\n" + "=" * 78)
    print("TEST 3  DESIRED SPEED  (ACC target)")
    print("=" * 78)
    teleport(world, ego, base.transform)
    world.tick()
    v0, lim = desired_speed(ego, world)
    print(f"  no lead vehicle                 -> desired={v0:.2f} m/s  (expect ~= speed limit {lim:.2f})")
    lead_bp = bp.filter("vehicle.tesla.model3")[0]
    lead_wp = base.next(10.0)[0]
    lead = world.try_spawn_actor(lead_bp, carla.Transform(
        carla.Location(lead_wp.transform.location.x, lead_wp.transform.location.y, lead_wp.transform.location.z + 0.3),
        lead_wp.transform.rotation))
    if lead:
        lead.set_simulate_physics(False); world.tick()
        v1, lim = desired_speed(ego, world)
        print(f"  stopped lead 10 m ahead         -> desired={v1:.2f} m/s  (expect ~0, capped by lead)")
        fwd = base.transform.get_forward_vector()
        lead.set_target_velocity(carla.Vector3D(4.0 * fwd.x, 4.0 * fwd.y, 0)); world.tick(); world.tick()
        v2, lim = desired_speed(ego, world)
        print(f"  lead moving ~4 m/s ahead        -> desired={v2:.2f} m/s  (expect ~=min(limit, 4))")
        lead.destroy(); world.tick()

    # red light: find a light the ego is at, force red
    tls = world.get_actors().filter("traffic.traffic_light")
    done_rl = False
    for tl in tls:
        wp_stop = amap.get_waypoint(tl.get_location(), project_to_road=True, lane_type=carla.LaneType.Driving)
        for aw in tl.get_affected_lane_waypoints() if hasattr(tl, "get_affected_lane_waypoints") else []:
            teleport(world, ego, aw.transform)
            world.tick(); world.tick()
            tl.set_state(carla.TrafficLightState.Red); tl.freeze(True); world.tick()
            if ego.is_at_traffic_light():
                vr, lim = desired_speed(ego, world)
                print(f"  ego at RED light                -> desired={vr:.2f} m/s  (expect 0.00)")
                done_rl = True
                break
        if done_rl:
            break
    if not done_rl:
        print("  (could not position ego at a red light in this town; red-light path not exercised)")

    # cleanup
    ego.destroy()
    settings.synchronous_mode = False
    world.apply_settings(settings)
    print("\nDONE.")

if __name__ == "__main__":
    main()
