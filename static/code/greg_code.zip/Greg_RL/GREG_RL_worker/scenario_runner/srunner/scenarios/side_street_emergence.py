"""Side-street vehicle emerges through occlusion into ego's path — Town03."""

import math

import carla
import py_trees

from srunner.scenariomanager.carla_data_provider import CarlaDataProvider
from srunner.scenariomanager.scenarioatomics.atomic_behaviors import ActorDestroy
from srunner.scenariomanager.scenarioatomics.atomic_criteria import CollisionTest
from srunner.scenariomanager.scenarioatomics.atomic_trigger_conditions import (
    InTriggerDistanceToLocation,
)
from srunner.scenariomanager.scenarioatomics.custom_atomics import (
    EgoSpeedGovernor,
    HoldUntilEgoMoves,
    LaneCleaner,
)
from srunner.scenariomanager.timer import GameTime, TimeOut
from srunner.scenarios.basic_scenario import BasicScenario


def _speed_mps(actor):
    if actor is None or not actor.is_alive:
        return 0.0
    v = actor.get_velocity()
    return math.sqrt(v.x ** 2 + v.y ** 2 + v.z ** 2)


def _planar_distance(loc_a, loc_b):
    return math.hypot(loc_a.x - loc_b.x, loc_a.y - loc_b.y)


class _RunSideStreetEmergence(py_trees.behaviour.Behaviour):
    """
    Wait for ego to approach the junction, then the side-street vehicle
    accelerates across into ego's lane.
    """

    def __init__(self, scenario, name="RunSideStreetEmergence"):
        super().__init__(name)
        self._scenario = scenario
        self._start_time = None
        self._emerge_started = False
        self._last_log = -999.0

    def initialise(self):
        self._start_time = GameTime.get_time()

    def update(self):
        scenario = self._scenario
        if scenario._impact_detected:
            print(f"[SideStreet] *** COLLISION ***", flush=True)
            return py_trees.common.Status.SUCCESS

        elapsed = GameTime.get_time() - self._start_time if self._start_time else 0.0

        ego_loc = scenario._ego.get_location()
        junction_loc = scenario._junction_point
        dist = _planar_distance(ego_loc, junction_loc)

        if not self._emerge_started and dist <= scenario._trigger_distance:
            self._emerge_started = True
            print(f"[SideStreet] Ego within {dist:.1f}m of junction — "
                  f"side vehicle GO!", flush=True)

        emerging = scenario._emerging_vehicle
        if emerging is not None and emerging.is_alive:
            if self._emerge_started:
                # Aim directly at ego using set_target_velocity
                em_loc = emerging.get_location()
                dx = ego_loc.x - em_loc.x
                dy = ego_loc.y - em_loc.y
                mag = math.sqrt(dx * dx + dy * dy)
                speed = scenario._emerge_speed
                if mag > 0.5:
                    emerging.set_target_velocity(carla.Vector3D(
                        speed * dx / mag, speed * dy / mag, 0.0))
            else:
                emerging.set_target_velocity(carla.Vector3D(0.0, 0.0, 0.0))
                emerging.apply_control(carla.VehicleControl(
                    throttle=0.0, brake=1.0, steer=0.0,
                ))

        if elapsed - self._last_log >= 1.0:
            self._last_log = elapsed
            ego_spd = _speed_mps(scenario._ego) * 3.6
            em_spd = _speed_mps(emerging) * 3.6 if emerging else 0
            print(f"[SideStreet] t={elapsed:.1f}s  ego={ego_spd:.0f}km/h  "
                  f"emerging={em_spd:.0f}km/h  dist_jct={dist:.1f}m  "
                  f"emerge={self._emerge_started}  impact={scenario._impact_detected}",
                  flush=True)

        if elapsed >= scenario._max_run_time:
            return py_trees.common.Status.FAILURE
        return py_trees.common.Status.RUNNING


class _PostImpactHold(py_trees.behaviour.Behaviour):
    def __init__(self, duration, name="PostImpactHold"):
        super().__init__(name)
        self._duration = float(duration)
        self._start_time = None

    def initialise(self):
        self._start_time = GameTime.get_time()

    def update(self):
        elapsed = GameTime.get_time() - self._start_time if self._start_time else 0.0
        if elapsed >= self._duration:
            return py_trees.common.Status.SUCCESS
        return py_trees.common.Status.RUNNING


class _EgoMinSpeedForcer(py_trees.behaviour.Behaviour):
    """Override autopilot braking — force ego to maintain minimum speed."""

    def __init__(self, ego, min_speed_kmh=40.0, throttle=0.8,
                 name="EgoMinSpeedForcer"):
        super().__init__(name)
        self._ego = ego
        self._min_mps = float(min_speed_kmh) / 3.6
        self._throttle = float(throttle)

    def update(self):
        if self._ego is None or not self._ego.is_alive:
            return py_trees.common.Status.RUNNING
        v = self._ego.get_velocity()
        speed = math.sqrt(v.x ** 2 + v.y ** 2 + v.z ** 2)
        if speed > 5.0 and speed < self._min_mps:
            ctrl = self._ego.get_control()
            ctrl.brake = 0.0
            ctrl.throttle = self._throttle
            self._ego.apply_control(ctrl)
        return py_trees.common.Status.RUNNING


class SideStreetEmergence(BasicScenario):
    """
    A vehicle pulls out from a side street or parking lot through an
    occlusion (wall, hedge, parked cars) into the ego vehicle's lane.

    XML other_parameters:
      activation_distance_m       - trigger proximity
      junction_point_x            - junction/crossing point X
      junction_point_y            - junction/crossing point Y
      junction_point_z            - junction/crossing point Z
      emerge_speed_kmh            - speed of emerging vehicle
      trigger_distance_m          - ego distance to junction triggering emergence
      ego_speed_cap_kmh           - ego speed governor cap
      ego_cap_brake               - brake force when above cap
      max_run_time                - scenario timeout
      post_impact_hold            - hold duration after collision
    """

    timeout = 120

    @staticmethod
    def _get_param(op, name, default, cast=float):
        if not op or name not in op:
            return default
        raw = op[name]
        try:
            if isinstance(raw, dict):
                return cast(raw.get("value", default))
            return cast(raw)
        except (TypeError, ValueError):
            return default

    def __init__(self, world, ego_vehicles, config,
                 randomize=False, debug_mode=False, criteria_enable=True,
                 timeout=120):
        self._world = world
        self._map = CarlaDataProvider.get_map()
        self._ego = ego_vehicles[0]

        op = config.other_parameters if hasattr(config, "other_parameters") else {}
        self._activation_distance = self._get_param(op, "activation_distance_m", 80.0)
        jx = self._get_param(op, "junction_point_x", 145.0)
        jy = self._get_param(op, "junction_point_y", 126.0)
        jz = self._get_param(op, "junction_point_z", 0.4)
        self._junction_point = carla.Location(x=jx, y=jy, z=jz)
        self._emerge_speed = self._get_param(op, "emerge_speed_kmh", 30.0) / 3.6
        self._trigger_distance = self._get_param(op, "trigger_distance_m", 30.0)
        self._ego_speed_cap_kmh = self._get_param(op, "ego_speed_cap_kmh", 35.0)
        self._ego_min_speed_kmh = self._get_param(op, "ego_min_speed_kmh", 30.0)
        self._ego_cap_brake = self._get_param(op, "ego_cap_brake", 0.12)
        self._max_run_time = self._get_param(op, "max_run_time", 20.0)
        self._post_impact_hold = self._get_param(op, "post_impact_hold", 4.0)

        self._trigger_wp = self._map.get_waypoint(config.trigger_points[0].location)
        self._emerging_vehicle = None
        self._collision_sensor = None
        self._impact_detected = False

        super().__init__(
            name="SideStreetEmergence",
            ego_vehicles=ego_vehicles,
            config=config,
            world=world,
            debug_mode=debug_mode,
            terminate_on_failure=True,
            criteria_enable=criteria_enable,
        )

    def _initialize_actors(self, config):
        # The emerging vehicle position comes from other_actor in the XML
        if config.other_actors and len(config.other_actors) > 0:
            actor_config = config.other_actors[0]
            em_transform = carla.Transform(
                carla.Location(
                    x=actor_config.transform.location.x,
                    y=actor_config.transform.location.y,
                    z=actor_config.transform.location.z + 0.5,
                ),
                actor_config.transform.rotation,
            )
        else:
            # Fallback: place vehicle in opposing lane near junction point
            junc_wp = self._map.get_waypoint(self._junction_point)
            opp_wp = junc_wp.get_left_lane()
            if opp_wp is None:
                opp_wp = junc_wp.get_right_lane()
            if opp_wp is None:
                opp_wp = junc_wp
            # Advance a bit
            for _ in range(3):
                nexts = opp_wp.next(5.0)
                if nexts:
                    opp_wp = nexts[0]
            em_loc = carla.Location(
                opp_wp.transform.location.x,
                opp_wp.transform.location.y,
                opp_wp.transform.location.z + 0.5,
            )
            yaw = math.degrees(math.atan2(
                self._junction_point.y - em_loc.y,
                self._junction_point.x - em_loc.x,
            ))
            em_transform = carla.Transform(em_loc, carla.Rotation(yaw=yaw))

        em_models = [
            "vehicle.audi.a2",
            "vehicle.nissan.micra",
            "vehicle.mini.cooper_s",
            "vehicle.tesla.model3",
        ]
        self._emerging_vehicle = None
        for model in em_models:
            self._emerging_vehicle = CarlaDataProvider.request_new_actor(
                model, em_transform, rolename="emerging_vehicle",
            )
            if self._emerging_vehicle is not None:
                break
        if self._emerging_vehicle is None:
            raise RuntimeError("[SideStreet] Emerging vehicle spawn failed")

        self._emerging_vehicle.set_simulate_physics(True)
        self._emerging_vehicle.set_target_velocity(carla.Vector3D(0.0, 0.0, 0.0))
        self.other_actors.append(self._emerging_vehicle)

        # Collision sensor
        collision_bp = self._world.get_blueprint_library().find("sensor.other.collision")
        self._collision_sensor = self._world.spawn_actor(
            collision_bp, carla.Transform(), attach_to=self._ego,
        )
        self._collision_sensor.listen(lambda event: self._on_collision(event))

        print(
            f"\n[SideStreet] Spawn\n"
            f"  Emerging vehicle at ({em_transform.location.x:.1f}, "
            f"{em_transform.location.y:.1f})\n"
            f"  Junction at ({self._junction_point.x:.1f}, {self._junction_point.y:.1f})\n"
            f"  emerge_speed={self._emerge_speed * 3.6:.0f}km/h  "
            f"trigger_dist={self._trigger_distance:.0f}m\n",
            flush=True,
        )

    def _on_collision(self, event):
        other = event.other_actor
        if self._emerging_vehicle is not None and other.id != self._emerging_vehicle.id:
            print(f"[SideStreet] Ignoring non-emerging collision: {other.type_id}", flush=True)
            return
        if not self._impact_detected:
            self._impact_detected = True
            print(f"[SideStreet] *** COLLISION: {event.other_actor.type_id} ***", flush=True)

    def _setup_scenario_trigger(self, config):
        return InTriggerDistanceToLocation(
            self._ego,
            self._trigger_wp.transform.location,
            self._activation_distance,
            name="ActivateSideStreetEmergence",
        )

    def _create_behavior(self):
        root = py_trees.composites.Sequence("SideStreetEmergenceSequence")

        sync = py_trees.composites.Parallel(
            "Phase0_Sync",
            policy=py_trees.common.ParallelPolicy.SUCCESS_ON_ALL,
        )
        sync.add_child(HoldUntilEgoMoves(self._emerging_vehicle, self._ego))
        root.add_child(sync)

        main_loop = py_trees.composites.Parallel(
            "Phase1_MainLoop",
            policy=py_trees.common.ParallelPolicy.SUCCESS_ON_ONE,
        )
        main_loop.add_child(_RunSideStreetEmergence(self))
        main_loop.add_child(EgoSpeedGovernor(
            self._ego,
            speed_cap_kmh=self._ego_speed_cap_kmh,
            brake_force=self._ego_cap_brake,
        ))
        main_loop.add_child(_EgoMinSpeedForcer(
            self._ego, min_speed_kmh=self._ego_min_speed_kmh))
        main_loop.add_child(TimeOut(self._max_run_time))
        root.add_child(main_loop)

        root.add_child(_PostImpactHold(self._post_impact_hold))
        root.add_child(ActorDestroy(self._emerging_vehicle, name="DestroyEmergingVehicle"))

        ego_wp = self._map.get_waypoint(
            self._trigger_wp.transform.location,
            project_to_road=True, lane_type=carla.LaneType.Driving,
        )
        lane_wps = [ego_wp]
        left = ego_wp.get_left_lane()
        if left and left.lane_type == carla.LaneType.Driving:
            lane_wps.append(left)
        right = ego_wp.get_right_lane()
        if right and right.lane_type == carla.LaneType.Driving:
            lane_wps.append(right)

        outer = py_trees.composites.Parallel(
            "SideStreet_Outer",
            policy=py_trees.common.ParallelPolicy.SUCCESS_ON_ONE,
        )
        outer.add_child(root)
        outer.add_child(LaneCleaner(
            protected_actors=[self._ego, self._emerging_vehicle],
            lane_waypoints=lane_wps,
            center_location=self._trigger_wp.transform.location,
            radius=220.0,
            interval=1.0,
            name="ScenarioLaneCleaner",
        ))
        return outer

    def _create_test_criteria(self):
        criteria = py_trees.composites.Parallel(
            "SideStreetEmergenceCriteria",
            policy=py_trees.common.ParallelPolicy.SUCCESS_ON_ONE,
        )
        criteria.add_child(CollisionTest(self._ego))
        return criteria

    def remove_all_actors(self):
        if self._collision_sensor is not None and self._collision_sensor.is_alive:
            self._collision_sensor.stop()
            self._collision_sensor.destroy()
            self._collision_sensor = None
        super().remove_all_actors()
