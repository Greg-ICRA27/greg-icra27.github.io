"""Animal suddenly crosses road from roadside vegetation — Town04 highway."""

import math

import carla
import py_trees

from srunner.scenariomanager.carla_data_provider import CarlaDataProvider
from srunner.scenariomanager.scenarioatomics.atomic_behaviors import ActorDestroy
from srunner.scenariomanager.scenarioatomics.atomic_criteria import CollisionTest
from srunner.scenariomanager.scenarioatomics.atomic_trigger_conditions import (
    InTriggerDistanceToLocation,
)
from srunner.scenariomanager.scenarioatomics.custom_atomics import (
    EgoSpeedGovernor,
    HoldUntilEgoMoves,
)
from srunner.scenariomanager.timer import GameTime, TimeOut
from srunner.scenarios.basic_scenario import BasicScenario


def _speed_mps(actor):
    if actor is None or not actor.is_alive:
        return 0.0
    v = actor.get_velocity()
    return math.sqrt(v.x ** 2 + v.y ** 2 + v.z ** 2)


def _planar_distance(loc_a, loc_b):
    return math.hypot(loc_a.x - loc_b.x, loc_a.y - loc_b.y)


class _RunAnimalCrossing(py_trees.behaviour.Behaviour):
    """
    Wait for ego to be near the animal spawn point, then command the
    walker (animal proxy) to dash across the road.  Optionally includes
    hesitation (stop-start) behavior for realism.
    """

    def __init__(self, scenario, name="RunAnimalCrossing"):
        super().__init__(name)
        self._scenario = scenario
        self._start_time = None
        self._dash_started = False
        self._dash_start_time = None
        self._last_move_time = None
        self._crossing_target = None
        self._hesitation_applied = False
        self._last_log = -999.0

    def initialise(self):
        self._start_time = GameTime.get_time()

    def update(self):
        scenario = self._scenario
        if scenario._impact_detected:
            print(f"[AnimalCross] *** ANIMAL HIT ***", flush=True)
            return py_trees.common.Status.SUCCESS

        elapsed = GameTime.get_time() - self._start_time if self._start_time else 0.0

        ego_loc = scenario._ego.get_location()
        animal = scenario._animal
        animal_loc = animal.get_location() if animal else ego_loc
        dist_to_animal = _planar_distance(ego_loc, animal_loc)

        # Trigger dash when ego is close. The animal stays at its roadside
        # spawn and runs in from there, so it is visible before the conflict.
        if not self._dash_started and dist_to_animal <= scenario._trigger_distance:
            self._dash_started = True
            self._dash_start_time = elapsed
            self._last_move_time = elapsed
            ego_t = scenario._ego.get_transform()
            fwd = ego_t.get_forward_vector()
            self._crossing_target = carla.Location(
                ego_loc.x + fwd.x * scenario._animal_target_ahead_m,
                ego_loc.y + fwd.y * scenario._animal_target_ahead_m,
                ego_loc.z + 0.5,
            )
            print(f"[AnimalCross] Ego within {dist_to_animal:.1f}m — "
                  f"animal starts crossing!", flush=True)

        if animal is not None and animal.is_alive:
            if self._dash_started:
                dash_elapsed = elapsed - self._dash_start_time

                # Optional hesitation: animal stops briefly mid-crossing
                if (scenario._hesitation_enabled
                        and not self._hesitation_applied
                        and dash_elapsed > scenario._hesitation_delay):
                    # Brief stop
                    animal.apply_control(carla.WalkerControl(
                        direction=carla.Vector3D(0.0, 0.0, 0.0),
                        speed=0.0,
                    ))
                    if dash_elapsed > scenario._hesitation_delay + scenario._hesitation_duration:
                        self._hesitation_applied = True
                    return py_trees.common.Status.RUNNING

                animal_loc = animal.get_location()
                target = self._crossing_target or animal_loc
                dx = target.x - animal_loc.x
                dy = target.y - animal_loc.y
                mag = math.sqrt(dx * dx + dy * dy)
                dt = max(0.03, min(0.1, elapsed - self._last_move_time))
                self._last_move_time = elapsed
                if mag > 0.3:
                    step = min(mag, scenario._animal_dash_speed * dt)
                    animal.set_location(carla.Location(
                        animal_loc.x + dx / mag * step,
                        animal_loc.y + dy / mag * step,
                        animal_loc.z,
                    ))
                    animal.apply_control(carla.WalkerControl(
                        direction=carla.Vector3D(dx / mag, dy / mag, 0.0),
                        speed=scenario._animal_dash_speed,
                    ))
                else:
                    animal.apply_control(carla.WalkerControl(
                        direction=carla.Vector3D(0.0, 0.0, 0.0),
                        speed=0.0,
                    ))
            else:
                # Animal stands still at roadside
                animal.apply_control(carla.WalkerControl(
                    direction=carla.Vector3D(0.0, 0.0, 0.0),
                    speed=0.0,
                ))

        if elapsed - self._last_log >= 1.0:
            self._last_log = elapsed
            ego_spd = _speed_mps(scenario._ego) * 3.6
            print(f"[AnimalCross] t={elapsed:.1f}s  ego={ego_spd:.0f}km/h  "
                  f"dist={dist_to_animal:.1f}m  dash={self._dash_started}  "
                  f"impact={scenario._impact_detected}", flush=True)

        if elapsed >= scenario._max_run_time:
            return py_trees.common.Status.FAILURE
        return py_trees.common.Status.RUNNING


class _PostImpactHold(py_trees.behaviour.Behaviour):
    def __init__(self, duration, name="PostImpactHold"):
        super().__init__(name)
        self._duration = float(duration)
        self._start_time = None

    def initialise(self):
        self._start_time = GameTime.get_time()

    def update(self):
        elapsed = GameTime.get_time() - self._start_time if self._start_time else 0.0
        if elapsed >= self._duration:
            return py_trees.common.Status.SUCCESS
        return py_trees.common.Status.RUNNING


class _EgoMinSpeedForcer(py_trees.behaviour.Behaviour):
    """Override autopilot braking — force ego to maintain minimum speed."""

    def __init__(self, ego, min_speed_kmh=70.0, throttle=0.8,
                 name="EgoMinSpeedForcer"):
        super().__init__(name)
        self._ego = ego
        self._min_mps = float(min_speed_kmh) / 3.6
        self._throttle = float(throttle)

    def update(self):
        if self._ego is None or not self._ego.is_alive:
            return py_trees.common.Status.RUNNING
        v = self._ego.get_velocity()
        speed = math.sqrt(v.x ** 2 + v.y ** 2 + v.z ** 2)
        if speed > 5.0 and speed < self._min_mps:
            ctrl = self._ego.get_control()
            ctrl.brake = 0.0
            ctrl.throttle = self._throttle
            self._ego.apply_control(ctrl)
        return py_trees.common.Status.RUNNING


class AnimalRoadCrossing(BasicScenario):
    """
    An animal (simulated by a pedestrian walker) suddenly dashes across the
    road from roadside vegetation.  Optionally includes hesitation behavior
    where the animal briefly stops mid-crossing.

    Note: CARLA 0.9.15 does not have native animal actors.  A pedestrian
    walker is used as a proxy for a medium-sized animal (deer, dog, etc.).

    XML other_parameters:
      activation_distance_m         - trigger proximity
      animal_spawn_ahead_m          - animal position ahead of ego (along road)
      animal_lateral_offset_m       - animal offset from road edge (into vegetation)
      animal_dash_speed_mps         - sprint speed (m/s); deer ~12, dog ~8
      trigger_distance_m            - ego distance to animal that triggers dash
      dash_direction_sign           - +1.0 or -1.0 for dash direction
      hesitation_enabled            - enable stop-start behavior (true/false)
      hesitation_delay_s            - seconds after dash start before hesitation
      hesitation_duration_s         - how long the animal pauses mid-road
      ego_speed_cap_kmh             - ego speed governor cap
      ego_cap_brake                 - brake force when above cap
      max_run_time                  - scenario timeout
      post_impact_hold              - hold duration after collision
    """

    timeout = 120

    @staticmethod
    def _get_param(op, name, default, cast=float):
        if not op or name not in op:
            return default
        raw = op[name]
        try:
            if isinstance(raw, dict):
                return cast(raw.get("value", default))
            return cast(raw)
        except (TypeError, ValueError):
            return default

    @staticmethod
    def _get_bool_param(op, name, default):
        if not op or name not in op:
            return default
        raw = op[name]
        if isinstance(raw, dict):
            raw = raw.get("value", default)
        return str(raw).strip().lower() in ("1", "true", "yes", "y", "on")

    def __init__(self, world, ego_vehicles, config,
                 randomize=False, debug_mode=False, criteria_enable=True,
                 timeout=120):
        self._world = world
        self._map = CarlaDataProvider.get_map()
        self._ego = ego_vehicles[0]

        op = config.other_parameters if hasattr(config, "other_parameters") else {}
        self._activation_distance = self._get_param(op, "activation_distance_m", 100.0)
        self._animal_spawn_ahead = self._get_param(op, "animal_spawn_ahead_m", 55.0)
        self._animal_lateral_offset = self._get_param(op, "animal_lateral_offset_m", 5.5)
        self._animal_dash_speed = self._get_param(op, "animal_dash_speed_mps", 5.0)
        self._animal_target_ahead_m = self._get_param(op, "animal_target_ahead_m", 28.0)
        self._trigger_distance = self._get_param(op, "trigger_distance_m", 36.0)
        self._dash_direction_sign = self._get_param(op, "dash_direction_sign", 1.0)
        self._hesitation_enabled = self._get_bool_param(op, "hesitation_enabled", False)
        self._hesitation_delay = self._get_param(op, "hesitation_delay_s", 0.5)
        self._hesitation_duration = self._get_param(op, "hesitation_duration_s", 0.3)
        self._ego_speed_cap_kmh = self._get_param(op, "ego_speed_cap_kmh", 80.0)
        self._ego_min_speed_kmh = self._get_param(op, "ego_min_speed_kmh", 70.0)
        self._ego_cap_brake = self._get_param(op, "ego_cap_brake", 0.10)
        self._max_run_time = self._get_param(op, "max_run_time", 20.0)
        self._post_impact_hold = self._get_param(op, "post_impact_hold", 4.0)

        self._trigger_wp = self._map.get_waypoint(config.trigger_points[0].location)
        self._animal = None
        self._collision_sensor = None
        self._impact_detected = False

        super().__init__(
            name="AnimalRoadCrossing",
            ego_vehicles=ego_vehicles,
            config=config,
            world=world,
            debug_mode=debug_mode,
            terminate_on_failure=True,
            criteria_enable=criteria_enable,
        )

    @staticmethod
    def _walk_waypoint(waypoint, distance, forward=True):
        remaining = abs(float(distance))
        cursor = waypoint
        while remaining > 0.2 and cursor is not None:
            step = min(8.0, remaining)
            candidates = cursor.next(step) if forward else cursor.previous(step)
            if not candidates:
                break
            cursor = candidates[0]
            remaining -= step
        return cursor

    def _initialize_actors(self, config):
        ego_wp = self._map.get_waypoint(
            self._ego.get_location(), project_to_road=True,
            lane_type=carla.LaneType.Driving,
        )

        # Animal: ahead of ego, far to the right (off-road, in vegetation)
        animal_wp = self._walk_waypoint(
            ego_wp, self._animal_spawn_ahead, forward=True
        ) or ego_wp
        animal_t = animal_wp.transform
        right = animal_t.get_right_vector()
        animal_loc = carla.Location(
            x=animal_t.location.x + right.x * self._animal_lateral_offset,
            y=animal_t.location.y + right.y * self._animal_lateral_offset,
            z=animal_t.location.z + 0.5,
        )
        animal_transform = carla.Transform(animal_loc, animal_t.rotation)

        # Use a small pedestrian model as animal proxy
        walker_models = [
            "walker.pedestrian.0013",
            "walker.pedestrian.0014",
            "walker.pedestrian.0001",
            "walker.pedestrian.0005",
        ]
        self._animal = None
        for model in walker_models:
            self._animal = CarlaDataProvider.request_new_actor(
                model, animal_transform, rolename="animal_proxy",
            )
            if self._animal is not None:
                break
        if self._animal is None:
            raise RuntimeError("[AnimalCross] Walker spawn failed")
        self.other_actors.append(self._animal)

        # Collision sensor
        collision_bp = self._world.get_blueprint_library().find("sensor.other.collision")
        self._collision_sensor = self._world.spawn_actor(
            collision_bp, carla.Transform(), attach_to=self._ego,
        )
        self._collision_sensor.listen(lambda event: self._on_collision(event))

        print(
            f"\n[AnimalCross] Spawn\n"
            f"  Ego road={ego_wp.road_id} lane={ego_wp.lane_id}\n"
            f"  Animal at ({animal_loc.x:.1f}, {animal_loc.y:.1f}) "
            f"ahead={self._animal_spawn_ahead:.1f}m lat={self._animal_lateral_offset:.1f}m\n"
            f"  dash_speed={self._animal_dash_speed:.1f}m/s  "
            f"trigger_dist={self._trigger_distance:.0f}m  "
            f"hesitation={self._hesitation_enabled}\n",
            flush=True,
        )

    def _on_collision(self, event):
        other = event.other_actor
        if self._animal is not None and other.id != self._animal.id:
            print(f"[AnimalCross] Ignoring non-animal collision: {other.type_id}", flush=True)
            return
        if not self._impact_detected:
            self._impact_detected = True
            print(f"[AnimalCross] *** COLLISION: {event.other_actor.type_id} ***", flush=True)

    def _setup_scenario_trigger(self, config):
        return InTriggerDistanceToLocation(
            self._ego,
            self._trigger_wp.transform.location,
            self._activation_distance,
            name="ActivateAnimalRoadCrossing",
        )

    def _create_behavior(self):
        root = py_trees.composites.Sequence("AnimalRoadCrossingSequence")

        main_loop = py_trees.composites.Parallel(
            "Phase1_MainLoop",
            policy=py_trees.common.ParallelPolicy.SUCCESS_ON_ONE,
        )
        main_loop.add_child(_RunAnimalCrossing(self))
        main_loop.add_child(EgoSpeedGovernor(
            self._ego,
            speed_cap_kmh=self._ego_speed_cap_kmh,
            brake_force=self._ego_cap_brake,
        ))
        main_loop.add_child(_EgoMinSpeedForcer(
            self._ego, min_speed_kmh=self._ego_min_speed_kmh))
        main_loop.add_child(TimeOut(self._max_run_time))
        root.add_child(main_loop)

        root.add_child(_PostImpactHold(self._post_impact_hold))
        return root

    def _create_test_criteria(self):
        criteria = py_trees.composites.Parallel(
            "AnimalRoadCrossingCriteria",
            policy=py_trees.common.ParallelPolicy.SUCCESS_ON_ONE,
        )
        criteria.add_child(CollisionTest(self._ego))
        return criteria

    def remove_all_actors(self):
        if self._collision_sensor is not None and self._collision_sensor.is_alive:
            self._collision_sensor.stop()
            self._collision_sensor.destroy()
            self._collision_sensor = None
        super().remove_all_actors()
