"""Highway blind-spot overtake collision scenario for Town04."""

import os
import subprocess
import math
import threading
import queue
import py_trees
import carla

from srunner.scenariomanager.carla_data_provider import CarlaDataProvider
from srunner.scenariomanager.scenarioatomics.atomic_behaviors import ActorDestroy
from srunner.scenariomanager.scenarioatomics.atomic_trigger_conditions import (
    InTriggerDistanceToLocation,
)
from srunner.scenariomanager.scenarioatomics.atomic_criteria import CollisionTest
from srunner.scenariomanager.timer import TimeOut
from srunner.scenarios.basic_scenario import BasicScenario

from srunner.scenariomanager.scenarioatomics.custom_atomics import (
    HoldUntilEgoMoves,
    ApplyControlForDuration,
    PeriodicStatusLogger,
    LaneCleaner,
    EgoSpeedGovernor,
)


# ─────────────────────────────────────────────────────────────────────────────
# Tiny helper: fire-and-forget one-shot behavior
# ─────────────────────────────────────────────────────────────────────────────

class _OneShot(py_trees.behaviour.Behaviour):
    """Execute a callback once on first tick, then return SUCCESS forever."""

    def __init__(self, callback, name="OneShot"):
        super().__init__(name)
        self._callback = callback
        self._fired = False

    def update(self):
        if not self._fired:
            self._callback()
            self._fired = True
        return py_trees.common.Status.SUCCESS


# ─────────────────────────────────────────────────────────────────────────────
# Scenario
# ─────────────────────────────────────────────────────────────────────────────

class HighwayBlindSpotOvertake(BasicScenario):
    """
    Blind-spot lane-change collision on a multi-lane highway.

    Setup
    ─────
    • Ego drives in the right lane (lane 4) behind a slow truck.
    • A fast car (ADV) drives in the left / overtaking lane (lane 3),
      positioned in ego's blind spot (just behind and alongside).

    Collision mechanism
    ───────────────────
    After a configurable cruise phase the behavior tree forces the ego to
    steer left (simulating a driver who fails to check mirrors).  The ADV,
    travelling at a similar or slightly higher speed in lane 3, cannot avoid
    the side / rear-quarter collision.

    XML parameters (direct children of <scenario>)
    ────────────────────────────────────────────────
      activation_distance_m    — trigger proximity (m)
      truck_ahead_distance_m   — truck spawn offset ahead of ego (m)
      adv_spawn_behind_ego     — ADV spawn offset behind ego in lane 3 (m)
      truck_speed_kmh          — truck TM autopilot speed
      adv_speed_kmh            — ADV TM autopilot speed
      ego_speed_cap_kmh        — EgoSpeedGovernor cap
      ego_cap_brake            — brake force when above cap
      cruise_duration_s        — seconds before forcing lane change
      lane_change_steer        — steer value (negative = left)
      lane_change_throttle     — throttle during lane change
      lane_change_duration     — seconds of forced steering
      aftermath_duration_s     — hold time after lane change
    """

    timeout = 180

    # ── helpers ───────────────────────────────────────────────────────────

    @staticmethod
    def _get_param(op, name, default, cast=float):
        if not op or name not in op:
            return default
        raw = op[name]
        try:
            if isinstance(raw, dict):
                return cast(raw.get("value", default))
            return cast(raw)
        except (TypeError, ValueError):
            return default

    # ── init ──────────────────────────────────────────────────────────────

    def __init__(self, world, ego_vehicles, config,
                 randomize=False, debug_mode=False,
                 criteria_enable=True, timeout=180):

        self._world = world
        self._map = CarlaDataProvider.get_map()
        self._ego = ego_vehicles[0]

        op = config.other_parameters if hasattr(config, "other_parameters") else {}
        self._activation_distance   = self._get_param(op, "activation_distance_m", 80.0)
        self._truck_ahead_distance  = self._get_param(op, "truck_ahead_distance_m", 43.0)
        self._adv_spawn_behind      = self._get_param(op, "adv_spawn_behind_ego", 10.0)
        self._truck_speed_kmh       = self._get_param(op, "truck_speed_kmh", 60.0)
        self._adv_speed_kmh         = self._get_param(op, "adv_speed_kmh", 80.0)
        self._ego_speed_cap_kmh     = self._get_param(op, "ego_speed_cap_kmh", 75.0)
        self._ego_cap_brake         = self._get_param(op, "ego_cap_brake", 0.20)
        self._cruise_duration       = self._get_param(op, "cruise_duration_s", 5.0)
        self._lane_change_steer     = self._get_param(op, "lane_change_steer", -0.35)
        self._lane_change_throttle  = self._get_param(op, "lane_change_throttle", 0.6)
        self._lane_change_duration  = self._get_param(op, "lane_change_duration", 1.5)
        self._aftermath_duration    = self._get_param(op, "aftermath_duration_s", 5.0)

        self._trigger_wp = self._map.get_waypoint(config.trigger_points[0].location)

        self._truck = None
        self._adv = None
        self._adv_spawn_wp = None

        self._camera_sensor = None
        self._frame_dir = os.path.join(
            os.path.expanduser("~"),
            "ziang/corl2026/custom_scenario/run_output/blind_spot/frames",
        )
        self._frame_count = [0]

        super().__init__(
            name="HighwayBlindSpotOvertake",
            ego_vehicles=ego_vehicles,
            config=config,
            world=world,
            debug_mode=debug_mode,
            terminate_on_failure=True,
            criteria_enable=criteria_enable,
        )

    # ── actors ────────────────────────────────────────────────────────────

    def _initialize_actors(self, config):
        ego_wp = self._map.get_waypoint(self._ego.get_location())

        # ── Truck: same lane (lane 4), AHEAD of ego ──────────────────────
        truck_nexts = ego_wp.next(self._truck_ahead_distance)
        truck_wp = truck_nexts[0] if truck_nexts else ego_wp

        truck_t = carla.Transform(
            carla.Location(
                x=truck_wp.transform.location.x,
                y=truck_wp.transform.location.y,
                z=truck_wp.transform.location.z + 0.5,
            ),
            truck_wp.transform.rotation,
        )
        self._truck = CarlaDataProvider.request_new_actor(
            "vehicle.carlamotors.carlacola", truck_t, rolename="truck",
        )
        if self._truck is None:
            self._truck = CarlaDataProvider.request_new_actor(
                "vehicle.tesla.cybertruck", truck_t, rolename="truck",
            )
        if self._truck is None:
            raise RuntimeError("[BlindSpot] Truck spawn failed.")
        self._truck.set_simulate_physics(True)

        # Truck: TM autopilot — slow, blocks ego's lane
        tm_port = CarlaDataProvider.get_traffic_manager_port()
        tm = CarlaDataProvider.get_client().get_trafficmanager(tm_port)
        self._truck.set_autopilot(True, tm_port)
        tm.set_desired_speed(self._truck, self._truck_speed_kmh)
        tm.auto_lane_change(self._truck, False)
        tm.ignore_vehicles_percentage(self._truck, 100)
        tm.ignore_walkers_percentage(self._truck, 100)
        tm.ignore_lights_percentage(self._truck, 100)
        tm.ignore_signs_percentage(self._truck, 100)

        self.other_actors.append(self._truck)

        # ── ADV: left lane (lane 3), BEHIND ego ──────────────────────────
        ego_left = ego_wp.get_left_lane()
        if ego_left is None or ego_left.lane_type != carla.LaneType.Driving:
            raise RuntimeError(
                f"[BlindSpot] No drivable left lane at ego. "
                f"road={ego_wp.road_id} lane={ego_wp.lane_id}"
            )
        adv_prevs = ego_left.previous(self._adv_spawn_behind)
        self._adv_spawn_wp = adv_prevs[0] if adv_prevs else ego_left

        adv_t = carla.Transform(
            carla.Location(
                x=self._adv_spawn_wp.transform.location.x,
                y=self._adv_spawn_wp.transform.location.y,
                z=self._adv_spawn_wp.transform.location.z + 0.5,
            ),
            self._adv_spawn_wp.transform.rotation,
        )
        self._adv = CarlaDataProvider.request_new_actor(
            "vehicle.tesla.model3", adv_t, rolename="adversarial",
        )
        if self._adv is None:
            raise RuntimeError("[BlindSpot] ADV spawn failed.")
        self._adv.set_target_velocity(carla.Vector3D(0, 0, 0))
        self._adv.set_simulate_physics(True)

        self.other_actors.append(self._adv)
        self._attach_camera_sensor()

        print(
            f"\n[BlindSpot] ── Spawn ──────────────────────────────────────────\n"
            f"  Ego:   road={ego_wp.road_id}  lane={ego_wp.lane_id}\n"
            f"  Truck: road={truck_wp.road_id}  lane={truck_wp.lane_id}  "
            f"{self._truck_ahead_distance:.0f}m ahead  {self._truck_speed_kmh:.0f} km/h\n"
            f"  ADV:   road={self._adv_spawn_wp.road_id}  lane={self._adv_spawn_wp.lane_id}  "
            f"{self._adv_spawn_behind:.0f}m behind  {self._adv_speed_kmh:.0f} km/h\n"
            f"  ego cap={self._ego_speed_cap_kmh:.0f} km/h  "
            f"cruise={self._cruise_duration:.1f}s  "
            f"steer={self._lane_change_steer:.2f}  dur={self._lane_change_duration:.1f}s\n"
            f"────────────────────────────────────────────────────────────────\n",
            flush=True,
        )

    # ── trigger ───────────────────────────────────────────────────────────

    def _setup_scenario_trigger(self, config):
        return InTriggerDistanceToLocation(
            self._ego,
            self._trigger_wp.transform.location,
            self._activation_distance,
            name="ActivateBlindSpot",
        )

    # ── behavior tree ─────────────────────────────────────────────────────

    def _create_behavior(self):
        """
        outer = Parallel(SUCCESS_ON_ONE)
          root = Sequence
            Phase0  HoldADV braked | Timeout(8) — wait for ego to start
            Phase1  TimeOut(cruise_duration) — ego reaches cruising speed
            Phase2  _OneShot → teleport ADV into ego's blind spot + velocity
            Phase3  TimeOut(0.3) — let ADV physics settle
            Phase4  ApplyControlForDuration(ego, steer left) | Timeout
            Phase5  TimeOut(aftermath)
            Cleanup ActorDestroy × 2
          EgoSpeedGovernor        (background, always RUNNING)
          PeriodicStatusLogger    (background, always RUNNING)
          StopActorsOnEgoCollision (SUCCESS on collision → terminates outer)
          LaneCleaner             (background)
        """
        P = py_trees.common.ParallelPolicy

        root = py_trees.composites.Sequence("BlindSpot_Root")

        # ── Phase 0: hold ADV until ego starts ───────────────────────────
        phase0 = py_trees.composites.Parallel(
            "Phase0_Sync", policy=P.SUCCESS_ON_ONE,
        )
        phase0.add_child(TimeOut(8.0, name="Phase0_Timeout"))
        phase0.add_child(
            HoldUntilEgoMoves(self._adv, self._ego, name="HoldADV"),
        )
        root.add_child(phase0)

        # ── Phase 1: cruise — ego accelerates toward truck ───────────────
        root.add_child(TimeOut(self._cruise_duration, name="Phase1_Cruise"))

        # ── Phase 2: teleport ADV into ego's blind spot with velocity ────
        ego = self._ego
        adv = self._adv
        world_map = self._map
        adv_speed_kmh = self._adv_speed_kmh
        adv_behind_m = self._adv_spawn_behind  # reused as blind-spot offset

        def _place_adv_in_blind_spot():
            ego_loc = ego.get_location()
            ego_wp = world_map.get_waypoint(ego_loc)
            left_wp = ego_wp.get_left_lane()
            if left_wp is None:
                print("[BlindSpot] WARNING: no left lane at ego!", flush=True)
                return
            # Position ADV slightly behind ego in the left lane
            behind_wps = left_wp.previous(adv_behind_m)
            target_wp = behind_wps[0] if behind_wps else left_wp

            # Teleport
            new_t = carla.Transform(
                carla.Location(
                    x=target_wp.transform.location.x,
                    y=target_wp.transform.location.y,
                    z=target_wp.transform.location.z + 0.3,
                ),
                target_wp.transform.rotation,
            )
            adv.set_transform(new_t)

            # Instant velocity matching road direction
            fwd = target_wp.transform.get_forward_vector()
            speed_mps = adv_speed_kmh / 3.6
            adv.set_target_velocity(carla.Vector3D(
                x=fwd.x * speed_mps,
                y=fwd.y * speed_mps,
                z=0.0,
            ))

            # Enable TM autopilot to maintain speed & lane-keep
            tm_port = CarlaDataProvider.get_traffic_manager_port()
            tm = CarlaDataProvider.get_client().get_trafficmanager(tm_port)
            adv.set_autopilot(True, tm_port)
            tm.set_desired_speed(adv, adv_speed_kmh)
            tm.auto_lane_change(adv, False)
            tm.ignore_vehicles_percentage(adv, 100)
            tm.ignore_walkers_percentage(adv, 100)
            tm.ignore_lights_percentage(adv, 100)
            tm.ignore_signs_percentage(adv, 100)

            print(
                f"[BlindSpot] ADV teleported to blind spot: "
                f"({new_t.location.x:.1f}, {new_t.location.y:.1f})  "
                f"speed={adv_speed_kmh:.0f} km/h  "
                f"ego at ({ego_loc.x:.1f}, {ego_loc.y:.1f})",
                flush=True,
            )

        root.add_child(_OneShot(_place_adv_in_blind_spot, name="PlaceADV"))

        # ── Phase 3: tiny settle delay ───────────────────────────────────
        root.add_child(TimeOut(0.3, name="Phase3_Settle"))

        # ── Phase 4: force ego lane change (steer left into ADV) ─────────
        phase4 = py_trees.composites.Parallel(
            "Phase4_LaneChange", policy=P.SUCCESS_ON_ONE,
        )
        phase4.add_child(ApplyControlForDuration(
            self._ego,
            steer=self._lane_change_steer,
            throttle=self._lane_change_throttle,
            duration=self._lane_change_duration,
            name="ForceEgoLeft",
        ))
        phase4.add_child(TimeOut(
            self._lane_change_duration + 1.5, name="Phase4_Timeout",
        ))
        root.add_child(phase4)

        # ── Phase 5: aftermath hold ──────────────────────────────────────
        root.add_child(TimeOut(self._aftermath_duration, name="Phase5_Aftermath"))

        # ── Cleanup ──────────────────────────────────────────────────────
        cleanup = py_trees.composites.Sequence("Cleanup")
        cleanup.add_child(ActorDestroy(self._adv, name="DestroyADV"))
        cleanup.add_child(ActorDestroy(self._truck, name="DestroyTruck"))
        root.add_child(cleanup)

        # ── Outer: background helpers ────────────────────────────────────
        ego_lane_wp = self._trigger_wp
        left_lane_wp = self._trigger_wp.get_left_lane()
        lane_wps = [
            wp for wp in [ego_lane_wp, left_lane_wp]
            if wp and wp.lane_type == carla.LaneType.Driving
        ]
        protected = [self._ego, self._adv, self._truck]

        outer = py_trees.composites.Parallel(
            "BlindSpot_Outer", policy=P.SUCCESS_ON_ONE,
        )
        outer.add_child(root)
        outer.add_child(LaneCleaner(
            protected_actors=protected,
            lane_waypoints=lane_wps,
            center_location=self._trigger_wp.transform.location,
            radius=500.0,
            interval=1.0,
            name="ScenarioLaneCleaner",
        ))
        outer.add_child(PeriodicStatusLogger(
            self._ego, self._adv, self._truck,
            interval=1.0, name="StatusLogger",
        ))
        # NOTE: no StopActorsOnEgoCollision — let the scenario run through
        # all phases so the embedded camera captures the full buildup + aftermath.
        outer.add_child(EgoSpeedGovernor(
            self._ego,
            speed_cap_kmh=self._ego_speed_cap_kmh,
            brake_force=self._ego_cap_brake,
            name="EgoSpeedGovernor",
        ))
        return outer

    # ── embedded camera ──────────────────────────────────────────────────

    def _attach_camera_sensor(self):
        try:
            os.makedirs(self._frame_dir, exist_ok=True)
            bp = self._world.get_blueprint_library().find("sensor.camera.rgb")
            bp.set_attribute("image_size_x", "1280")
            bp.set_attribute("image_size_y", "720")
            bp.set_attribute("fov", "110")
            transform = carla.Transform(
                carla.Location(x=-6.0, z=15.0),
                carla.Rotation(pitch=-30.0),
            )
            self._camera_sensor = self._world.spawn_actor(
                bp, transform, attach_to=self._ego,
            )
            frame_dir = self._frame_dir
            frame_count = self._frame_count

            # Async writer: queue frames and write in background thread
            self._frame_queue = queue.Queue(maxsize=2000)
            self._writer_stop = threading.Event()

            def _writer():
                while not self._writer_stop.is_set():
                    try:
                        idx, raw, w, h = self._frame_queue.get(timeout=0.5)
                    except queue.Empty:
                        continue
                    import numpy as np
                    arr = np.frombuffer(raw, dtype=np.uint8).reshape((h, w, 4))
                    # BGRA -> BGR for cv2
                    bgr = arr[:, :, :3][:, :, ::-1].copy()
                    import cv2
                    cv2.imwrite(os.path.join(frame_dir, f"{idx:06d}.png"), bgr)

            self._writer_thread = threading.Thread(target=_writer, daemon=True)
            self._writer_thread.start()

            def _save(image):
                idx = frame_count[0]
                frame_count[0] += 1
                try:
                    self._frame_queue.put_nowait(
                        (idx, bytes(image.raw_data), image.width, image.height)
                    )
                except queue.Full:
                    pass  # drop frame if queue full
                if idx % 50 == 0 and idx > 0:
                    print(
                        f"[BlindSpotCam] frame {idx}",
                        flush=True,
                    )

            self._camera_sensor.listen(_save)
            print(
                f"[BlindSpotCam] camera attached (async writer), saving to {frame_dir}",
                flush=True,
            )
        except Exception as e:
            print(f"[BlindSpotCam] WARNING: {e}")
            self._camera_sensor = None

    # ── criteria & cleanup ───────────────────────────────────────────────

    def _create_test_criteria(self):
        return [CollisionTest(self._ego)]

    def __del__(self):
        try:
            if self._camera_sensor is not None:
                try:
                    self._camera_sensor.stop()
                    self._camera_sensor.destroy()
                except Exception:
                    pass
                self._camera_sensor = None

            # Wait for writer thread to drain remaining frames
            if hasattr(self, '_writer_stop') and self._writer_stop is not None:
                import time as _time
                _time.sleep(0.5)  # let last callbacks arrive
                self._writer_stop.set()
                if hasattr(self, '_writer_thread'):
                    self._writer_thread.join(timeout=30)
                # Drain any remaining items
                while not self._frame_queue.empty():
                    try:
                        idx, raw, w, h = self._frame_queue.get_nowait()
                        import numpy as np
                        arr = np.frombuffer(raw, dtype=np.uint8).reshape((h, w, 4))
                        bgr = arr[:, :, :3][:, :, ::-1].copy()
                        import cv2
                        cv2.imwrite(
                            os.path.join(self._frame_dir, f"{idx:06d}.png"), bgr
                        )
                    except Exception:
                        break
            _time.sleep(0.5)

            frames = self._frame_count[0] if self._frame_count else 0
            if frames > 5 and os.path.isdir(self._frame_dir):
                out_mp4 = os.path.join(
                    os.path.dirname(self._frame_dir), "recording.mp4",
                )
                subprocess.run(
                    [
                        "ffmpeg", "-y", "-framerate", "20",
                        "-i", os.path.join(self._frame_dir, "%06d.png"),
                        "-vcodec", "libx264", "-preset", "fast", "-crf", "23",
                        "-pix_fmt", "yuv420p", out_mp4,
                    ],
                    check=False,
                    capture_output=True,
                )
                print(f"[BlindSpotCam] Saved {frames} frames -> {out_mp4}")
        except Exception as e:
            print(f"[BlindSpotCam] WARNING encode: {e}")
        self.remove_all_actors()
