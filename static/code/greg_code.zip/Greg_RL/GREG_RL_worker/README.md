# GREG_RL_worker

The actor/rollout side of the RL stage: `run_SAC_worker_dino.sh` (launched via
`../GREG_RL_Trainer/launch_all_workers.sh` -> `run_worker.sh`) starts CARLA and runs
`leaderboard/leaderboard/leaderboard_trainer.py --agent=leaderboard/our_team/Greg_worker.py`.

## Configuration (`.env`)
`Greg_worker.py` needs `MASTER_IP` (the trainer's data-server address) and `HF_TOKEN` set in the
environment. When launched normally via `../GREG_RL_Trainer/run_SAC_worker_dino.sh`, that script
exports both from its own `.env`; this folder's `.env` is only a fallback for running the agent
standalone.
