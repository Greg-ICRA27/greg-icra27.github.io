import torch
import concurrent.futures

import json
import time
import os
from typing import Dict

import random
import numpy as np

import random
import numpy as np
import pickle  # For saving and loading the buffer to disk

import portalocker

class PrioritizedReplayBuffer:
    def __init__(self, capacity, alpha=0.6, prioritize=True):
        self.capacity = capacity
        self.buffer = deque(maxlen=capacity)
        self.priorities = deque(maxlen=capacity)  # Holds priority for each experience
        self.alpha = alpha  # Controls the degree of prioritization
        self.prioritize = prioritize
        self.max_size = capacity

    def add(self, experience, priority=1.0):
        # Ensure priority is a scalar float
        
        if len(self.buffer) >= self.max_size:
            if self.prioritize:
                # Replace based on lowest priority
                min_idx = self.priorities.index(min(self.priorities))
                self.buffer[min_idx] = experience
                self.priorities[min_idx] = priority
            else:
                self.buffer.pop(0)  # FIFO replacement
        else:
            self.buffer.append(experience)
            if self.prioritize:
                self.priorities.append(priority)
        
    
    def extend(self, experiences):
        for experience in experiences:
            self.add(experience)

    def get_last_num(self, num_last=50):
        (states, actions, rewards, next_states, values, log_probs, cnts, dones) = zip(*list(self.buffer)[-num_last:])
        return torch.vstack(rewards).detach().cpu().tolist(), cnts

    def sample(self, batch_size, beta=0.4):
        if len(self.buffer) == 0:
            raise ValueError("Cannot sample from an empty buffer")

        # Convert priorities to a NumPy array and apply alpha
        scaled_priorities = np.array(self.priorities, dtype=np.float32) ** self.alpha
        scaled_priorities = scaled_priorities.ravel()  # Ensure 1D array
        total_priority = np.sum(scaled_priorities).item()  # Use .item() to get scalar

        # Check if the total priority is zero to avoid division errors
        if total_priority == 0:
            sample_probs = np.ones_like(scaled_priorities) / len(scaled_priorities)
        else:
            sample_probs = scaled_priorities / total_priority  # Normalize to get probabilities

        # Sample indices based on probabilities
        indices = np.random.choice(len(self.buffer), batch_size, p=sample_probs)
        samples = [self.buffer[idx] for idx in indices]

        # Calculate importance-sampling weights
        total = len(self.buffer)
        weights = (total * sample_probs[indices]) ** (-beta)
        weights /= weights.max()  # Normalize weights

        return zip(*samples), indices, torch.tensor(weights, dtype=torch.float32)

    def update_priorities(self, indices, priorities):
        for idx, priority in zip(indices, priorities):
            self.priorities[idx] = float(priority)  # Ensure priorities are scalar

    def size(self):
        return len(self.buffer)

    def store(self, filepath):
        """Store buffer and priorities to disk."""
        with open(filepath, 'wb') as f:
            pickle.dump((self.buffer, self.priorities), f)
        print(f"Replay buffer successfully saved to {filepath}.")

    def load(self, filepath):
        """Load buffer and priorities from disk."""
        try:
            with open(filepath, 'rb') as f:
                self.buffer, self.priorities = pickle.load(f)
            print(f"Replay buffer successfully loaded from {filepath}.")
        except FileNotFoundError:
            print(f"File {filepath} not found. Cannot load replay buffer.")

'''
class PrioritizedReplayBuffer:
    def __init__(self, capacity, alpha=0.6):
        self.capacity = capacity
        self.buffer = []
        self.priorities = []
        self.alpha = alpha  # Controls the degree of prioritization (0: uniform, 1: full prioritization)

    def add(self, experience, priority=1.0):
        # If buffer is full, remove the oldest experience
        if len(self.buffer) >= self.capacity:
            self.buffer.pop(0)
            self.priorities.pop(0)
        
        # Add new experience and priority
        self.buffer.append(experience)
        self.priorities.append(priority)

    def extend(self, experiences):
        for experience in experiences:
            self.add(experience)

    def sample(self, batch_size, beta=0.4):
        # Convert priorities to probabilities
        scaled_priorities = np.array(self.priorities, dtype=np.float32) ** self.alpha
        print('0000000000000000000')
        print(scaled_priorities.shape)
        total_priority = np.sum(scaled_priorities, axis=0)
        print(total_priority.shape)
        print('0000000000000000000')
        # Check if the total priority is zero to avoid division errors
        if total_priority == 0:
            sampling_probs = np.ones_like(scaled_priorities) / len(scaled_priorities)
        else:
            sampling_probs = scaled_priorities / total_priority

        sampling_probs = np.array(sampling_probs, dtype=np.float32)/np.sum(sampling_probs)
        # Sample indices based on probabilities
        indices = np.random.choice(len(self.buffer), batch_size, p=sampling_probs)
        samples = [self.buffer[i] for i in indices]
        
        # Importance sampling weights to correct for prioritized sampling
        total = len(self.buffer)
        weights = (total * sampling_probs[indices]) ** -beta
        weights /= weights.max()  # Normalize for stability
        weights = np.array(weights, dtype=np.float32)
        
        return zip(*samples), indices, weights

    def update_priorities(self, indices, new_priorities):
        for i, priority in zip(indices, new_priorities):
            self.priorities[i] = priority

    def size(self):
        return len(self.buffer)

    def store(self, filepath):
        """Store buffer and priorities to disk."""
        with open(filepath, 'wb') as f:
            pickle.dump((self.buffer, self.priorities), f)
        print(f"Replay buffer successfully saved to {filepath}.")

    def load(self, filepath):
        """Load buffer and priorities from disk."""
        try:
            with open(filepath, 'rb') as f:
                self.buffer, self.priorities = pickle.load(f)
            print(f"Replay buffer successfully loaded from {filepath}.")
        except FileNotFoundError:
            print(f"File {filepath} not found. Cannot load replay buffer.")

'''
import random
import numpy as np
from collections import deque

class ReplayBuffer:
    def __init__(self, capacity):
        self.capacity = capacity
        self.buffer = []#deque(maxlen=capacity)

    def add(self, experience):
        self.buffer.append(experience)
    
    def extend(self, experiences):
        for experience in experiences:
            self.add(experience)

    def sample(self, batch_size):
        return zip(*self.buffer)

    def clear(self):
        self.buffer = []
    
    def size(self):
        return len(self.buffer)

    def store(self, filepath):
        """Store buffer and priorities to disk."""
        with open(filepath, 'wb') as f:
            pickle.dump(self.buffer, f)
        print(f"Replay buffer successfully saved to {filepath}.")

    def load(self, filepath):
        """Load buffer and priorities from disk."""
        try:
            with open(filepath, 'rb') as f:
                self.buffer = pickle.load(f)
            print(f"Replay buffer successfully loaded from {filepath}.")
        except FileNotFoundError:
            print(f"File {filepath} not found. Cannot load replay buffer.")


class RewardNormalizer:
    def __init__(self, epsilon=1e-8, max_len=10000):
        self.mean = 0.0
        self.var = 1.0
        self.epsilon = epsilon
        self.count = 0
        self.max_len = max_len

    def update(self, rewards):
        """
        Update running mean and variance with new rewards.

        Args:
            rewards (np.ndarray or torch.Tensor): Batch of rewards.
        """
        if isinstance(rewards, torch.Tensor):
            if(len(rewards.shape))>0:
                rewards = rewards.squeeze().cpu().numpy()
            else:
                rewards = rewards.unsqueeze(-1).cpu().numpy()

        batch_mean = np.mean(rewards)
        batch_var = np.var(rewards)
        batch_count = len(rewards)

        # Update running mean and variance
        total_count = min(self.count + batch_count, self.max_len)
        delta = batch_mean - self.mean

        self.mean += delta * batch_count / total_count
        self.var = ((self.count * self.var) + (batch_count * batch_var) +
                    (delta ** 2) * self.count * batch_count / total_count) / total_count
        self.count = total_count

        print('Variables', self.mean, self.var, self.count)

    def normalize(self, rewards):
        """
        Normalize rewards using running statistics.

        Args:
            rewards (np.ndarray or torch.Tensor): Batch of rewards.

        Returns:
            np.ndarray or torch.Tensor: Normalized rewards.
        """
        if isinstance(rewards, torch.Tensor):
            rewards = rewards.squeeze().cpu().numpy()

        normalized_rewards = (rewards - self.mean) / (np.sqrt(self.var) + self.epsilon)
        normalized_rewards = np.clip(normalized_rewards, -100, 100)
        return torch.tensor(normalized_rewards).cuda().unsqueeze(-1)*0.1

    def save(self, filepath):
        """
        Save the normalizer's parameters to a file.

        Args:
            filepath (str): Path to save the parameters.
        """
        params = {
            "mean": self.mean,
            "var": self.var,
            "count": self.count
        }
        np.savez(filepath, **params)

    def load(self, filepath):
        """
        Load the normalizer's parameters from a file.

        Args:
            filepath (str): Path to load the parameters from.
        """
        params = np.load(filepath)
        self.mean = params["mean"].item()
        self.var = params["var"].item()
        self.count = params["count"].item()




import json
import os
import time
from typing import Dict, Callable, Optional
import portalocker

# Directory where each program will store its JSON file.
SYNC_DIR = "../sync_states"
if not os.path.exists(SYNC_DIR):
    os.makedirs(SYNC_DIR)

# List of all program IDs (adjust as needed).
PROGRAM_IDS = []
for i in range(1, 25):
    PROGRAM_IDS.append(f'program_{i}')

POLL_INTERVAL = 0.5  # seconds

def get_state_file_path(program_id: str) -> str:
    """Return the path to the JSON file for a given program."""
    return os.path.join(SYNC_DIR, f"{program_id}.json")

def load_program_state(program_id: str) -> Dict:
    """Load the JSON state for the given program with a file lock."""
    file_path = get_state_file_path(program_id)
    if not os.path.exists(file_path):
        # Create an initial state if the file doesn't exist.
        initial_state = {"phase": 0, "released": False}
        save_program_state(program_id, initial_state)
        return initial_state
    with open(file_path, 'r+') as f:
        data_str = f.read()
        f.seek(0)
        if not data_str.strip():
            return {}
        return json.loads(data_str)

def mark_arrival(program_id: str, barrier_phase: int):
    """
    Mark this program as arrived at the given barrier phase.
    This function writes to the program's JSON file and verifies
    the update was successful.
    """
    while True:
        try:
            # Load the current state
            state = load_program_state(program_id)
            # Update the state with the new phase and set released to False
            state["phase"] = barrier_phase
            state["released"] = False
            # Save the updated state
            save_program_state(program_id, state)
            
            # Verify that the update was successfully written
            
            verify_state = load_program_state(program_id)
            if (verify_state.get("phase", 0) == barrier_phase and
                verify_state.get("released", True) is False):
                # Successfully updated and verified the state
                break
            else:
                print(f"{program_id}: Verification failed. Retrying...")
        except Exception as e:
            print(f"{program_id}: Error marking arrival: {e}")
        time.sleep(POLL_INTERVAL)



def save_program_state(program_id: str, state: Dict):
    """Write the state for the given program to its JSON file with a file lock."""
    file_path = get_state_file_path(program_id)
    with open(file_path, 'w+') as f:
        json.dump(state, f, indent=2)
        f.flush()
        time.sleep(POLL_INTERVAL)

def barrier(
    program_id: str,
    barrier_phase: int,
    coordinator: bool = False,
    coordinator_task: Optional[Callable[[], None]] = None,
):
    """
    A reusable barrier that uses a separate JSON file per program.
    
    Each program writes its own state (its current phase and whether the barrier is released)
    to a JSON file in SYNC_DIR. The coordinator reads each file individually.
    
    Steps:
      1. Mark arrival by updating your own JSON file with "phase" and setting "released" to False.
      2. If this process is the coordinator, continuously read every program’s JSON file until
         all have reached at least the required barrier_phase; then, optionally run a coordinator task,
         and update every file to set "released" to True.
      3. Each program (including the coordinator) waits until its own JSON file shows that "released" is True.
    """
    # -------------------------
    # Step 1: Mark arrival for this program.
    # -------------------------
    mark_arrival(program_id, barrier_phase)

    # -------------------------
    # Step 2: Coordinator logic.
    # -------------------------
    if coordinator:
        while True:
            all_arrived = True
            for pid in PROGRAM_IDS:
                try:
                    state = load_program_state(pid)
                    if state.get("phase", 0) < barrier_phase:
                        all_arrived = False 
                    if barrier_phase>state.get("phase", 0) and barrier_phase<10:
                        state["released"] = True
                        save_program_state(pid, state)
                    
                except Exception as e:
                    print(f"Coordinator: Error reading state for {pid}: {e}")
                    all_arrived = False
                    break
            if all_arrived:
                if coordinator_task is not None:
                    coordinator_task()
                # Update every program's file to mark the barrier as released.
                for pid in PROGRAM_IDS:
                    state = load_program_state(pid)
                    state["released"] = True
                    save_program_state(pid, state)
                break
            time.sleep(POLL_INTERVAL)

    # -------------------------
    # Step 3: Wait until this program's file shows the barrier is released.
    # -------------------------
    while True:
        state = load_program_state(program_id)
        if state.get("released", False):
            break
        time.sleep(POLL_INTERVAL)
    time.sleep(2)
    print(f"{program_id} has passed barrier phase {barrier_phase}.")


import glob
import os
import shutil

def copy_pth_files(source_directory: str, destination_directory: str, pattern: str) -> None:
    """
    Copies all *.pth files from source_directory to destination_directory.
    
    Args:
        source_directory (str): The directory to search for .pth files.
        destination_directory (str): The directory where .pth files will be copied.
    """
    # Ensure the destination directory exists
    os.makedirs(destination_directory, exist_ok=True)

    # Create a pattern to match .pth files in the source directory
    pattern = os.path.join(source_directory, pattern)

    # Iterate over all matching files
    for file_path in glob.glob(pattern):
        # Extract the filename from the full path
        filename = os.path.basename(file_path)
        destination_path = os.path.join(destination_directory, filename)
        
        # Copy the file, preserving metadata
        shutil.copy2(file_path, destination_path)
        print(f"Copied '{filename}' to '{destination_path}'")


    time.sleep(2)


class TreeNode:
		"""
		A node in the MCTS tree.
		
		Attributes:
			sequence (torch.Tensor): A tensor of shape (1, seq_length, state_dim) representing the state history.
			reward (float): The predicted reward obtained from the action that led to this node.
			action (torch.Tensor or None): The action taken to reach this node.
			parent (TreeNode or None): The parent node.
			children (list): List of child TreeNode instances.
		"""
		def __init__(self, sequence, reward=0.0, action=None, parent=None):
			self.sequence = sequence  # shape: (1, seq_length, state_dim)
			self.reward = reward      # predicted reward (from parent's action)
			self.action = action      # action taken from parent to this node
			self.parent = parent
			self.children = []
			
		def add_child(self, child_node):
			self.children.append(child_node)


# ----------------------------
# 7. Parallelized Best Trajectory Search Using Recursive Parallelism
# ----------------------------
def best_trajectory_parallel_recursive(node, cum_reward=0.0, path=None):
    """
    Recursively searches for the best trajectory from the given node.
    This function parallelizes the exploration of each branch using ThreadPoolExecutor.
    
    Args:
        node (TreeNode): Current node in the tree.
        cum_reward (float): Cumulative reward so far.
        path (list): List of actions taken so far.
    
    Returns:
        (best_path, best_total_reward): Tuple containing the best trajectory and its cumulative reward.
    """
    if path is None:
        path = []
    # If the node is a leaf, return the current path and cumulative reward.
    if not node.children:
        return path, cum_reward
    
    best_path, best_total_reward = None, float('-inf')
    with concurrent.futures.ThreadPoolExecutor() as executor:
        # Submit recursive search for each child.
        futures = [
            executor.submit(best_trajectory_parallel_recursive, child, cum_reward + child.reward, path + [child.action])
            for child in node.children
        ]
        for future in concurrent.futures.as_completed(futures):
            branch_path, branch_reward = future.result()
            if branch_reward > best_total_reward:
                best_total_reward = branch_reward
                best_path = branch_path
    return best_path, best_total_reward


# ----------------------------
# 6. Sequential BFS to Find the Best Trajectory
# ----------------------------
def best_trajectory(root):
    """
    Performs a breadth-first search (BFS) over the tree to find the path (a list of actions)
    from the root to a leaf that yields the highest cumulative reward.
    
    Returns:
        best_path (list): List of actions (torch.Tensors) from root to leaf.
        best_reward (float): Cumulative reward along that path.
    """
    best_reward = float('-inf')
    best_path = []
    # Each queue element is (node, cumulative_reward, path_so_far)
    queue = deque([(root, 0.0, [])])
    
    while queue:
        node, cum_reward, path = queue.popleft()
        if not node.children:  # leaf node
            if cum_reward > best_reward:
                best_reward = cum_reward
                best_path = path
        else:
            for child in node.children:
                new_cum_reward = cum_reward + child.reward
                new_path = path + [child.action]
                queue.append((child, new_cum_reward, new_path))
                
    return best_path, best_reward