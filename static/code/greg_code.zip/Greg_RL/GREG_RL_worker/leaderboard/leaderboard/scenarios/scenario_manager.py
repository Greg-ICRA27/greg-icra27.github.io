#!/usr/bin/env python

# Copyright (c) 2018-2020 Intel Corporation
#
# This work is licensed under the terms of the MIT license.
# For a copy, see <https://opensource.org/licenses/MIT>.

"""
This module provides the ScenarioManager implementations.
It must not be modified and is for reference only!
"""

from __future__ import print_function
import signal
import sys
import time

import py_trees
import carla
import threading

from srunner.scenariomanager.carla_data_provider import CarlaDataProvider
from srunner.scenariomanager.timer import GameTime
from srunner.scenariomanager.watchdog import Watchdog

from leaderboard.autoagents.agent_wrapper import AgentWrapperFactory, AgentError, TickRuntimeError
from leaderboard.envs.sensor_interface import SensorReceivedNoData
from leaderboard.utils.result_writer import ResultOutputProvider

#################################
import random
import math
import numpy as np
import collections
import threading

class UnifiedTTC(object):
    """
    A class to calculate a unified Time-to-Collision (TTC) in CARLA, considering
    dynamic actors (vehicles, pedestrians), static props, red lights, stop signs,
    and static map geometry (walls, buildings).
    """
    def __init__(self, world, ego_actor, max_distance=50.0):
        """
        Initializes the UnifiedTTC object.

        :param world: The CARLA world object.
        :param ego_actor: The ego vehicle actor.
        :param max_distance: The maximum distance to check for obstacles.
        """
        self.world = world
        self.ego_actor = ego_actor
        self.map = self.world.get_map()
        self._max_distance = max_distance
        
        # Cache static stop signs once.
        self._stop_signs = self.world.get_actors().filter('traffic.stop')
        
        # Initialize an empty list for dynamic/prop obstacles
        self._obstacle_actors = []
        # Add a timer to track when we last updated this list
        self._last_actor_update_time = 0.0

    def _update_obstacle_actors(self):
        """
        Refreshes the list of obstacle actors if it's more than 1 second old.
        This captures spawned vehicles, walkers, and props.
        """
        current_time = self.world.get_snapshot().timestamp.elapsed_seconds
        if current_time - self._last_actor_update_time < 1.0:
            # List is fresh enough, do nothing.
            return

        # Time to update the list
        self._last_actor_update_time = current_time
        vehicles = self.world.get_actors().filter('vehicle.*')
        walkers = self.world.get_actors().filter('walker.pedestrian.*')
        static_props = self.world.get_actors().filter('static.prop.*')
        
        # Re-create the list
        self._obstacle_actors = list(vehicles) + list(walkers) + list(static_props)

    def get_unified_ttc(self):
        """
        Calculates the unified TTC by taking the minimum of TTCs from all sources.
        The final value is clamped to a specified range [0.01, 100.0] to avoid 
        infinities and very small, unstable numbers.

        :return: The clamped TTC value in seconds, between 0.01 and 100.0.
        """
        
        # Ensure our dynamic actor list is up-to-date
        self._update_obstacle_actors()
        
        ttc_values = [
            self._calculate_ttc_actors(),
            self._calculate_time_to_red_light(),
            self._calculate_time_to_stop_sign(),
            self._calculate_ttc_map()  # <-- ADDED MAP CHECK
        ]
        #print(ttc_values)
        min_ttc = min(filter(lambda x: x is not None and x >= 0, ttc_values), default=float('inf'))
        
        # Clamp the result to the desired range.
        # If min_ttc is inf, min(100.0, inf) will be 100.0.
        # If min_ttc is 0.005, max(0.01, 0.005) will be 0.01.
        clamped_ttc = max(0.00001, min_ttc)
        clamped_ttc = min(100000.0, clamped_ttc)
        
        return clamped_ttc #clamped_ttc

    def _calculate_ttc_map(self):
        """
        Calculates the time to collision with static map geometry (walls, etc.)
        AND non-actor objects (like parked cars) using a forward-facing ray-cast.
        
        This version uses a "flat" (horizontal) ray to avoid hitting the
        ground on hills, and starts the ray in front of the car.
        
        :return: Time to hit a map obstacle, or float('inf').
        """
        
        OBSTACLE_LABELS = {
            carla.CityObjectLabel.Buildings,
            carla.CityObjectLabel.Fences,
            carla.CityObjectLabel.GuardRail,
            carla.CityObjectLabel.Other,
            carla.CityObjectLabel.Poles,
            carla.CityObjectLabel.RailTrack,
            carla.CityObjectLabel.Sidewalks,
            carla.CityObjectLabel.Static,
            carla.CityObjectLabel.TrafficLight,
            carla.CityObjectLabel.TrafficSigns,
            carla.CityObjectLabel.Vegetation,
            carla.CityObjectLabel.Walls,
            carla.CityObjectLabel.Car,
            carla.CityObjectLabel.Truck,
            carla.CityObjectLabel.Bus,
            carla.CityObjectLabel.Train,
            carla.CityObjectLabel.Motorcycle,
            carla.CityObjectLabel.Bicycle,
            carla.CityObjectLabel.Rider,
            carla.CityObjectLabel.Pedestrians,
        }
        
        ego_transform = self.ego_actor.get_transform()
        ego_location = ego_transform.location
        
        # --- FIX: Create a "flat" forward vector ---
        fwd_vec_original = ego_transform.get_forward_vector()
        # Project the vector onto the XY plane
        fwd_vec_flat = carla.Vector3D(x=fwd_vec_original.x, y=fwd_vec_original.y, z=0)
        # Normalize to get a unit vector
        fwd_vec_flat = fwd_vec_flat.make_unit_vector()
        # --- END FIX ---
        
        ego_extent_x = self.ego_actor.bounding_box.extent.x
        
        # Start the ray 1.0m high and 10cm in front of the bumper
        start_location_local = carla.Location(x=ego_extent_x + 0.1, z=1.0)
        ray_start = ego_transform.transform(start_location_local)
        
        # Use the new "flat" vector to calculate the end point
        ray_end = ray_start + fwd_vec_flat * self._max_distance

        hit_list = self.world.cast_ray(ray_start, ray_end)

        first_obstacle_hit = None
        
        for hit in hit_list:
            if hit.label in OBSTACLE_LABELS:
                first_obstacle_hit = hit
                break 

        if first_obstacle_hit:
            distance_to_hit = ego_location.distance(first_obstacle_hit.location)
            ego_speed = self._get_speed(self.ego_actor)
            
            if ego_speed > 0.1:
                safe_distance = distance_to_hit - self.ego_actor.bounding_box.extent.x
                return safe_distance / ego_speed if safe_distance > 0 else 0.0
            else:
                return 0.0 if distance_to_hit < 2.0 else float('inf') 

        return float('inf')     

    def _calculate_ttc_actors(self):
        """
        Calculates a generalized Time-to-Collision by finding the Time to Closest
        Approach (TCA) with other dynamic and static actors.
        
        This version fixes the false-positive overlap (e.g., side-by-side cars)
        by only flagging a 0.0 TTC if the actors are overlapping AND
        are actively moving closer together.

        :return: Minimum TTC/TCA with other actors, or float('inf').
        """
        min_ttc = float('inf')
        ego_location = self.ego_actor.get_location()
        ego_velocity = self.ego_actor.get_velocity()
        
        # Approximate the ego vehicle as a circle for collision prediction.
        ego_radius = min(self.ego_actor.bounding_box.extent.x, self.ego_actor.bounding_box.extent.y) #math.sqrt(self.ego_actor.bounding_box.extent.x**2 + self.ego_actor.bounding_box.extent.y**2)

        for actor in self._obstacle_actors:
            if actor.id == self.ego_actor.id:
                continue

            actor_location = actor.get_location()
            
            # Initial distance check to filter out distant actors
            if actor_location.distance(ego_location) > self._max_distance:
                continue

            actor_velocity = actor.get_velocity()
            
            relative_position = actor_location - ego_location
            relative_velocity = actor_velocity - ego_velocity

            try:
                actor_radius = min(actor.bounding_box.extent.x, actor.bounding_box.extent.y) #math.sqrt(actor.bounding_box.extent.x**2 + actor.bounding_box.extent.y**2)
            except AttributeError:
                continue
            
            collision_threshold = ego_radius + actor_radius

            # Coefficients for the quadratic equation:
            # a = relative_velocity_squared
            a = relative_velocity.dot(relative_velocity)
            # b = 2 * dot_product(relative_position, relative_velocity)
            b = 2 * relative_position.dot(relative_velocity)
            # c = relative_distance_squared - collision_threshold_squared
            c = relative_position.dot(relative_position) - collision_threshold**2

            # --- START NEW LOGIC ---

            # 'c < 0' means the circular radii are overlapping *right now*.
            # 'b < 0' means the actors are moving *closer* to each other.
            
            if c < 0:
                if b < 0:
                    # Overlapping AND getting closer: This is a definite 0.0 TTC event.
                    min_ttc = 0.0
                    continue # No need to calculate further for this actor
                else:
                    # Overlapping but moving apart (b > 0) or parallel/stationary (b = 0).
                    # This is NOT a collision. (e.g., car in next lane)
                    continue

            # 'a' is zero, so relative velocity is zero. They are moving in parallel or are stationary.
            if abs(a) < 1e-4:
                # Since we already checked 'c < 0', we know they are not overlapping.
                # Therefore, they will never collide.
                continue 

            discriminant = b**2 - 4*a*c
            if discriminant < 0:
                # No real solution, paths don't intersect
                continue
            
            # The two solutions for t (time)
            t1 = (-b - math.sqrt(discriminant)) / (2*a)
            t2 = (-b + math.sqrt(discriminant)) / (2*a)

            ttc = float('inf')
            
            # We only care about future collisions (t > 0)
            if t1 >= 0:
                ttc = t1
            if t2 >= 0:
                ttc = min(ttc, t2)
            
            if 0 <= ttc < min_ttc:
                min_ttc = ttc
            
            # --- END NEW LOGIC ---
                
        return min_ttc

    def _calculate_time_to_red_light(self):
        """
        Calculates the time to pass a red light if one is affecting the ego vehicle.

        :return: Time to pass a red light, or float('inf').
        """
        if self.ego_actor.is_at_traffic_light():
            traffic_light = self.ego_actor.get_traffic_light()
            if traffic_light and traffic_light.get_state() == carla.TrafficLightState.Red:
                ego_location = self.ego_actor.get_location()
                
                # Try to get stop line waypoints
                stop_line_waypoints = traffic_light.get_stop_waypoints()
                if stop_line_waypoints:
                    stop_line_location = stop_line_waypoints[0].transform.location
                    distance = ego_location.distance(stop_line_location)
                    ego_speed = self._get_speed(self.ego_actor)
                    return distance / ego_speed if ego_speed > 0.1 else float('inf')
                else:
                    # Fallback if no stop lines are defined: use light's location
                    distance = ego_location.distance(traffic_light.get_location())
                    ego_speed = self._get_speed(self.ego_actor)
                    return (distance - 2.0) / ego_speed if ego_speed > 0.1 and distance > 2.0 else 0.0

        return float('inf')

    def _calculate_time_to_stop_sign(self):
        """
        Calculates the time to reach an upcoming stop sign by checking for
        stop sign actors geometrically in front of the ego vehicle.
        This method is more robust to map errors.
        
        :return: Time to reach the stop sign, or float('inf').
        """
        min_fwd_dist_to_stop = float('inf')
        ego_location = self.ego_actor.get_location()
        ego_transform = self.ego_actor.get_transform()
        ego_fwd_vec = ego_transform.get_forward_vector()
        
        for stop_sign in self._stop_signs:
            
            # Use the center of the trigger volume for a more accurate position
            # (Actor's transform is its base, trigger_volume.location is the offset)
            stop_transform = stop_sign.get_transform()
            stop_location = stop_transform.location + stop_sign.trigger_volume.location
            
            to_stop_vec = stop_location - ego_location
            distance = to_stop_vec.length()

            # 1. Filter out distant signs
            if distance > self._max_distance:
                continue
                
            # 2. Check if the sign is in front of us (dot product > 0)
            if ego_fwd_vec.dot(to_stop_vec) > 0:
                
                # 3. Check if it's in our "lane" (low lateral distance)
                fwd_dist = ego_fwd_vec.dot(to_stop_vec)
                
                # Use pythagoras to find the perpendicular (lateral) distance squared
                lat_dist_sq = (distance * distance) - (fwd_dist * fwd_dist)
                
                # Only consider signs that are within ~3m laterally
                if lat_dist_sq < (3.0 * 3.0):
                    if fwd_dist < min_fwd_dist_to_stop:
                        min_fwd_dist_to_stop = fwd_dist

        if min_fwd_dist_to_stop < float('inf'):
            ego_speed = self._get_speed(self.ego_actor)
            if ego_speed > 0.1:
                # Subtract a buffer (e.g., 2m) for the stop line vs. sign post
                safe_distance = min_fwd_dist_to_stop - 2.0 
                return safe_distance / ego_speed if safe_distance > 0 else 0.0
            else:
                return float('inf')

        return float('inf')
        
    def _get_speed(self, actor):
        """
        Calculates the speed of an actor in m/s.

        :param actor: The actor for which to calculate the speed.
        :return: The speed of the actor.
        """
        velocity = actor.get_velocity()
        return math.sqrt(velocity.x**2 + velocity.y**2 + velocity.z**2)


#################################

class ScenarioManager(object):

    """
    Basic scenario manager class. This class holds all functionality
    required to start, run and stop a scenario.

    The user must not modify this class.

    To use the ScenarioManager:
    1. Create an object via manager = ScenarioManager()
    2. Load a scenario via manager.load_scenario()
    3. Trigger the execution of the scenario manager.run_scenario()
       This function is designed to explicitly control start and end of
       the scenario execution
    4. If needed, cleanup with manager.stop_scenario()
    """

    def __init__(self, timeout, statistics_manager, debug_mode=0):
        """
        Setups up the parameters, which will be filled at load_scenario()
        """
        self.route_index = None
        self.scenario = None
        self.scenario_tree = None
        self.ego_vehicles = None
        self.other_actors = None

        self._debug_mode = debug_mode
        self._agent_wrapper = None
        self._running = False
        self._timestamp_last_run = 0.0
        self._timeout = float(timeout)

        self.scenario_duration_system = 0.0
        self.scenario_duration_game = 0.0
        self.start_system_time = 0.0
        self.start_game_time = 0.0
        self.end_system_time = 0.0
        self.end_game_time = 0.0
        

        self._watchdog = None
        self._agent_watchdog = None
        self._scenario_thread = None

        self._statistics_manager = statistics_manager

        self.tick_count = 0

        ####################################
        self.statistics_manager = statistics_manager

        self.veh_wierdo = []
        self.first_veh_wierdo_update = True
        self.loop_seen = False
        self.collision_happened = False
        self.veh_wierdo = []
        self.cnt= 0
        self.aggr_check = True
        self.config = None

        self.collided = False
        self.delay_running = False

        self.lane_invasion = False
        self.wrong_way = False
        self.red_light = False
        self.stop_sign = False
        self.too_close = False
        self.bet2lane = 0.0
        self.ttc = 100000.0
        self.ttc_manager = None
        self.reward = {'lane_invasion': self.lane_invasion,
                        'wrong_way': self.wrong_way,
                        'red_light': self.red_light,
                        'stop_sign': self.stop_sign,
                        'too_close': self.too_close,
                        'between2lane': self.bet2lane}
        ####################################







        # Use the callback_id inside the signal handler to allow external interrupts
        signal.signal(signal.SIGINT, self.signal_handler)


    ################################




    def monitor1(self, update_rate=1):
        
        while self._running:
            #print('I am not baghali and I am checking', flush=True)
            temp = self.check_lane_invasion(self.ego_vehicles[0], CarlaDataProvider.get_world())
            time.sleep(update_rate)

    def monitor2(self, update_rate=1):
        while self._running:
            temp = self.check_wrong_way(self.ego_vehicles[0], CarlaDataProvider.get_world())
            time.sleep(update_rate)

    def monitor3(self, update_rate=1):
        while self._running:
            self.check_red_light_violation(self.ego_vehicles[0])
            time.sleep(update_rate)
    def monitor4(self, update_rate=1):
        self.speed_threshold = 0.1  # Threshold speed to be considered a stop
        self.stop_check_radius = 15  # Distance to detect stop sign zones
        self.stop_signs = self.ego_vehicles[0].get_world().get_actors().filter('traffic.stop')
        self.active_stop_sign = None  # Stop sign the vehicle is interacting with
        self.has_stopped = False
        self.speed_history = collections.deque(maxlen=500) 
        while self._running:
            self.check_stop_sign_violation()
            time.sleep(update_rate)
        
    def monitor5(self, update_rate=1):
        while self._running:
            self.check_distance(radius=10.0)
            time.sleep(update_rate)
    
    def monitor6(self, update_rate=0.025):
        # try/except: an unhandled exception (transient CARLA RPC error, None waypoint, ...) would
        # silently kill this thread and FREEZE bet2lane at its last value for the rest of the route,
        # corrupting the Rds reward. Keep the last good value and carry on.
        while self._running:
            try:
                self.bet2lane = self.lane_centering_score(self.ego_vehicles[0], CarlaDataProvider.get_world())
            except Exception as e:
                print(f"[monitor6] lane_centering_score error (keeping last value): {e}", flush=True)
            time.sleep(update_rate)

    def monitor7(self, update_rate=0.025):
        # Same hardening as monitor6: a dead thread would freeze self.ttc silently.
        while self._running:
            try:
                self.ttc = self.ttc_manager.get_unified_ttc()
            except Exception as e:
                print(f"[monitor7] ttc error (keeping last value): {e}", flush=True)
            time.sleep(update_rate)

    

    

    def get_collision(self):
        return self.collided
    

    def _get_distance(self, location1, location2):
        """Calculate the Euclidean distance between two locations."""
        return math.sqrt((location1.x - location2.x)**2 + 
                        (location1.y - location2.y)**2 + 
                        (location1.z - location2.z)**2)

    def is_in_same_lane_as_any_emergency_vehicle(self, ego_vehicle, world, max_distance=50.0):
        """
        Checks if the ego vehicle is in the same lane as any nearby emergency vehicle.

        This function filters for visible/relevant emergency vehicles by checking
        if they are within a specified 'max_distance'. It uses a try-except block 
        to handle 'zombie' actors that may have been destroyed on the server.

        Args:
            ego_vehicle (carla.Vehicle): The player's vehicle.
            world (carla.World): The CARLA world object.
            max_distance (float): The maximum distance (in meters) to check for vehicles.
                                  Actors beyond this distance are ignored.

        Returns:
            bool: True if a nearby emergency vehicle is in the same lane, False otherwise.
        """
        try:
            # Ensure the ego vehicle itself is not destroyed
            if not ego_vehicle.is_alive:
                return False, False
            ego_location = ego_vehicle.get_location()
        except RuntimeError:
            return False, False # The ego vehicle is a zombie actor

        carla_map = world.get_map()
        if not carla_map:
            print("Error: Failed to retrieve CARLA map.")
            return False, False

        ego_waypoint = carla_map.get_waypoint(ego_location, project_to_road=True, lane_type=carla.LaneType.Driving)
        if ego_waypoint is None or ego_waypoint.is_junction:
            return False, False

        actor_list = world.get_actors()
        emergency_vehicles = [
            actor for actor in actor_list 
            if 'vehicle' in actor.type_id and 
            actor.attributes.get('special_type') == 'emergency'
        ]

        if not emergency_vehicles:
            return False, False

        for emergency_vehicle in emergency_vehicles:
            try:
                if not emergency_vehicle.is_alive:
                    continue
                
                emergency_location = emergency_vehicle.get_location()

                # --- NEW: DISTANCE CHECK ---
                # Calculate distance from ego vehicle. If it's too far, ignore it.
                distance = ego_location.distance(emergency_location)
                if distance > max_distance:
                    continue
                # -------------------------

                emergency_waypoint = carla_map.get_waypoint(emergency_location, project_to_road=True, lane_type=carla.LaneType.Driving)
                if emergency_waypoint is None or emergency_waypoint.is_junction:
                    continue

                is_same_road = ego_waypoint.road_id == emergency_waypoint.road_id
                is_same_lane = ego_waypoint.lane_id == emergency_waypoint.lane_id

                if is_same_road and is_same_lane:
                    return True, True
            
            except RuntimeError:
                # This actor is a "zombie". It has been destroyed on the server.
                continue
        
        return False, True

    def honk_action(self, honk_radius = 15.0):
        honk_radius = 15.0  # 15 meters, adjust as needed

        # Get all vehicles in the world
        all_vehicles = CarlaDataProvider.get_world().get_actors().filter('vehicle.*')
        
        ego_location = self.ego_vehicles[0].get_transform().location

        # Check nearby vehicles and apply brake if within honk radius

        for vehicle in all_vehicles:
            if vehicle.id != self.ego_vehicles[0].id:  # Skip the ego vehicle itself
                distance = self._get_distance(ego_location, vehicle.get_transform().location)
                
                if distance <= honk_radius:
                    # Apply brake control to nearby vehicles
                    #print(f"Vehicle {vehicle.id} is braking due to honk.")
                    vehicle.apply_control(carla.VehicleControl(throttle=0.0, brake=1.0))

    def check_ego_in_route_lane(self, world, ego_vehicle, route_wps):
        def distance(loc1, loc2):
            """Calculate Euclidean distance between two CARLA locations."""
            return math.sqrt((loc1.x - loc2.x)**2 + (loc1.y - loc2.y)**2 + (loc1.z - loc2.z)**2)
        """
        Check if the ego vehicle is in the same lane as the route's waypoint closest to it.
        
        :param world: The CARLA world.
        :param ego_vehicle: The ego vehicle actor.
        :param route_wps: List of tuples. Each tuple's first element is a Transform (from which we get the location).
        :return: True if ego is in the same lane as the closest route waypoint, otherwise False.
        """
        # Get the CARLA map from the world.
        carla_map = world.get_map()

        # Convert the list of route waypoints (tuples) into actual waypoints using the transform's location.
        route_waypoints = [
            carla_map.get_waypoint(wp_tuple[0].location, project_to_road=True, lane_type=carla.LaneType.Driving)
            for wp_tuple in route_wps
        ]

        # Get the current waypoint of the ego vehicle.
        ego_transform = ego_vehicle.get_transform()
        ego_wp = carla_map.get_waypoint(
            ego_transform.location, 
            project_to_road=True, 
            lane_type=carla.LaneType.Driving
        )

        # Determine which route waypoint is closest to the ego vehicle.
        ego_location = ego_transform.location
        closest_route_wp = min(
            route_waypoints,
            key=lambda wp: distance(ego_location, wp.transform.location)
        )

        # Check if the ego vehicle's waypoint is in the same lane as the closest route waypoint.
        in_same_lane = (ego_wp.road_id == closest_route_wp.road_id) and (ego_wp.lane_id == closest_route_wp.lane_id)
        return in_same_lane

    def is_in_same_lane_as_any_emergency_vehicle(self, ego_vehicle, world, max_distance=50.0):
        """
        Checks if the ego vehicle is in the same lane as any nearby emergency vehicle.

        This function filters for visible/relevant emergency vehicles by checking
        if they are within a specified 'max_distance'. It uses a try-except block 
        to handle 'zombie' actors that may have been destroyed on the server.

        Args:
            ego_vehicle (carla.Vehicle): The player's vehicle.
            world (carla.World): The CARLA world object.
            max_distance (float): The maximum distance (in meters) to check for vehicles.
                                  Actors beyond this distance are ignored.

        Returns:
            bool: True if a nearby emergency vehicle is in the same lane, False otherwise.
        """
        try:
            # Ensure the ego vehicle itself is not destroyed
            if not ego_vehicle.is_alive:
                return False, False
            ego_location = ego_vehicle.get_location()
        except RuntimeError:
            return False, False # The ego vehicle is a zombie actor

        carla_map = world.get_map()
        if not carla_map:
            print("Error: Failed to retrieve CARLA map.")
            return False, False

        ego_waypoint = carla_map.get_waypoint(ego_location, project_to_road=True, lane_type=carla.LaneType.Driving)
        if ego_waypoint is None or ego_waypoint.is_junction:
            return False, False

        actor_list = world.get_actors()
        emergency_vehicles = [
            actor for actor in actor_list 
            if 'vehicle' in actor.type_id and 
            actor.attributes.get('special_type') == 'emergency'
        ]

        if not emergency_vehicles:
            return False, False

        for emergency_vehicle in emergency_vehicles:
            try:
                if not emergency_vehicle.is_alive:
                    continue
                
                emergency_location = emergency_vehicle.get_location()

                # --- NEW: DISTANCE CHECK ---
                # Calculate distance from ego vehicle. If it's too far, ignore it.
                distance = ego_location.distance(emergency_location)
                if distance > max_distance:
                    continue
                # -------------------------

                emergency_waypoint = carla_map.get_waypoint(emergency_location, project_to_road=True, lane_type=carla.LaneType.Driving)
                if emergency_waypoint is None or emergency_waypoint.is_junction:
                    continue

                is_same_road = ego_waypoint.road_id == emergency_waypoint.road_id
                is_same_lane = ego_waypoint.lane_id == emergency_waypoint.lane_id

                if is_same_road and is_same_lane:
                    return True, True
            
            except RuntimeError:
                # This actor is a "zombie". It has been destroyed on the server.
                continue
        
        return False, True

    def lane_centering_score(self, vehicle, world, max_offset=0.5):
        """
        Computes a lane centering score:
        - 1.0 if the vehicle is exactly centered.
        - 0.0 if the vehicle is over the lane markings.
        - Smooth transition between 1 and 0 based on lateral offset.

        Args:
            vehicle (carla.Vehicle): The ego vehicle.
            world (carla.World): The CARLA world object.
            max_offset (float): Maximum distance from center before score reaches 0.

        Returns:
            float: Lane centering score (0.0 - 1.0).
        """
        # Get vehicle position

        location = vehicle.get_transform().location

        # Get the nearest waypoint (checks the lane type)
        waypoint = world.get_map().get_waypoint(location, project_to_road=True, lane_type=carla.LaneType.Any)

        # None-check FIRST: dereferencing .is_junction on a None waypoint raised inside monitor6
        # and (pre-hardening) silently killed the reward thread. Neutral 0 — true off-road is
        # terminated by the statistics_manager anyway.
        if waypoint is None:
            return 0

        is_emersamewp, is_emer =  self.is_in_same_lane_as_any_emergency_vehicle(vehicle, world)
        if is_emersamewp:
            return 1
        if is_emer:
            return 0
        # Ignore intersections (no lane invasion logic needed)
        if waypoint.is_junction:
            return  0


        vehicle_yaw = vehicle.get_transform().rotation.yaw

        # Get lane heading
        lane_yaw = waypoint.transform.rotation.yaw

        # Calculate yaw difference (normalize between -180 to 180 degrees)
        yaw_diff = abs((vehicle_yaw - lane_yaw + 180) % 360 - 180)

        if yaw_diff > 90:
            #print("Warning: Vehicle is driving in the wrong direction!")
            # Wrong-way is owned solely by check_wrong_way (monitor2) via the 'wrong_way'
            # reward key. Don't set the flag here (avoids double-count + thread race) and
            # don't add a second penalty through between2lane -> return neutral 0.
            return 0

        # ✅ If it's explicitly marked as a sidewalk, return True
        if waypoint.lane_type == carla.LaneType.Sidewalk:
           # print('siiiide')
            return 1

        # ✅ Fallback: Check if it's a non-driving lane (sometimes sidewalks are mislabeled)
        if waypoint.lane_type not in [carla.LaneType.Driving]:
            #print('non driving')
            return 1  # Likely sidewalk or pedestrian area


        ego_location = vehicle.get_transform().location

        # Get the closest waypoint on the road (ANY lane type)
        ego_waypoint = world.get_map().get_waypoint(ego_location, project_to_road=True, lane_type=carla.LaneType.Any)

        if not ego_waypoint:
            return 1  # No valid lane detected (off-road)
        # Find the closest left and right lane waypoints
            # Find the closest left and right lane waypoints
        waypoint = world.get_map().get_waypoint(ego_location, project_to_road=True, lane_type=carla.LaneType.Any)
        if waypoint is None:
            return 1  # Vehicle is off the defined road or no waypoint found

        route_wps = self._agent_wrapper._agent.actual_plan  # for example, the next waypoint in your route list

        # Out of the ROUTE lane but still on a valid same-direction driving lane (sidewalk /
        # non-driving / wrong-way were already handled above): apply a moderate FLOOR on the
        # badness instead of the old flat `return 1`. The flat 1 made a legitimate overtake of a
        # static obstacle cost as much as driving on the sidewalk (Rds pinned at 0.1 for the whole
        # maneuver), which combined with the stopped-lead v*=0 and the VEHICLE_BLOCKED termination
        # into a three-way deadlock on obstacle scenarios. With the floor, the detour lane costs
        # something (Rds <= 1-0.9*0.4 = 0.64) but staying centered IN it is rewarded over weaving.
        out_of_route_floor = 0.0
        if not self.check_ego_in_route_lane(world, vehicle, route_wps):
            out_of_route_floor = 0.4

        # Some CARLA versions have 'waypoint.lane_width' giving lane boundary width
        lane_width = waypoint.lane_width  # Typically in meters
        if lane_width <= 0.0:
            return 1 # Invalid or zero lane width



        # Lateral offset = PERPENDICULAR distance from the vehicle to the lane centerline.
        # BUGFIX (verified in CARLA): the old code used abs(vehicle.y - center.y) -- the global Y
        # axis only -- which equals the true lateral offset ONLY on east-west roads. On north-south
        # roads the projected center has ~the same Y as the vehicle, so offset collapsed to ~0 and
        # reported "centered" no matter how far off-lane the car was => no centering penalty => free
        # weaving. Project the vehicle->center vector onto the lane's RIGHT (unit) vector to get the
        # real lateral offset, correct on every road orientation.
        wp_tf = waypoint.transform
        right = wp_tf.get_right_vector()
        dx = ego_location.x - wp_tf.location.x
        dy = ego_location.y - wp_tf.location.y
        offset = abs(dx * right.x + dy * right.y)

        # 'half_lane_width': distance from center to boundary line
        half_lane_width = lane_width * 0.5

        # If 'offset' >= half_lane_width, we're on or over the boundary → score = 0.0
        # If 'offset' = 0, we're perfectly centered → score = 1.0
        score = 1.0 - (offset / half_lane_width)
        score= max(0.0, min(1.0, score))
        # Returned value is BADNESS in [0,1] (0 = centered, 1 = on the boundary). The floor keeps
        # a non-route (detour) lane costing at least 0.4 while still grading centering within it.
        return max(1-score, out_of_route_floor)



    def check_lane_invasion(self, vehicle, world, tolerance=0.2):
        """Detects lane invasion while avoiding false positives on two-way roads and minor drifts."""
        location = vehicle.get_transform().location

        # Get the nearest waypoint (checks the lane type)
        waypoint = world.get_map().get_waypoint(location, project_to_road=True, lane_type=carla.LaneType.Any)

        # Ignore intersections (no lane invasion logic needed)
        if waypoint.is_junction:
            return  

        # **Get lane markings and ensure slight drifts don't trigger false positives**
        left_marking = waypoint.left_lane_marking.type
        right_marking = waypoint.right_lane_marking.type

        # Get lane change permission and drivable lane check
        is_lane_change_restricted = waypoint.lane_change == carla.LaneChange.NONE
        is_not_drivable = waypoint.lane_type not in [carla.LaneType.Driving]

        # **Allow minor drifts by checking if the vehicle is slightly off-center**
        ego_offset = abs(waypoint.transform.location.y - location.y)  # Distance from lane center

        # **Check if this is a two-way road**
        road_waypoints = world.get_map().generate_waypoints(2.0)
        road_lanes = {wp.lane_id for wp in road_waypoints if wp.road_id == waypoint.road_id}
        is_two_way = len(road_lanes) == 2  # If only two lanes exist, assume two-way road

        # **Only flag lane invasion if the vehicle is significantly out of lane**
        if (is_lane_change_restricted or is_not_drivable) and ego_offset > tolerance:
            # **Prevent false invasion detection for two-way roads unless solid center line**
            if is_two_way and left_marking != carla.LaneMarkingType.Solid:
                self.lane_invasion = False
                return

            # 🚨 Flag lane invasion only if all conditions are met
            self.lane_invasion = True
            return

        # ✅ No lane invasion detected
        self.lane_invasion = False
        
    def get_speed(self):
        """Returns the current speed of the ego vehicle."""
        velocity = self.ego_vehicles[0].get_velocity()
        speed = np.linalg.norm([velocity.x, velocity.y, velocity.z])  # Speed in m/s
        return speed

    def is_stop_sign_ahead(self, stop_sign): 
        """Checks if the stop sign is in front of the vehicle, in its lane, and at the start of an intersection."""
        ego_transform = self.ego_vehicles[0].get_transform()
        ego_location = ego_transform.location
        ego_forward_vector = np.array([ego_transform.get_forward_vector().x,
                                    ego_transform.get_forward_vector().y,
                                    ego_transform.get_forward_vector().z])

        stop_sign_transform = stop_sign.get_transform()
        stop_sign_location = stop_sign_transform.location

        relative_position = np.array([stop_sign_location.x - ego_location.x,
                                    stop_sign_location.y - ego_location.y,
                                    stop_sign_location.z - ego_location.z])

        dot_product = np.dot(relative_position, ego_forward_vector)

        # ✅ Check if the stop sign is leading into an intersection
        stop_sign_waypoint = self.ego_vehicles[0].get_world().get_map().get_waypoint(stop_sign_location)
        next_waypoints = stop_sign_waypoint.next(5.0)  # Look 5m ahead

        is_at_intersection_entry = any(wp.is_junction for wp in next_waypoints)  # Stop sign should lead to an intersection

        # ✅ Ensure the stop sign is in the vehicle's lane or a valid adjacent lane
        ego_waypoint = self.ego_vehicles[0].get_world().get_map().get_waypoint(ego_location)
        is_same_lane = (stop_sign_waypoint.road_id == ego_waypoint.road_id and
                        abs(stop_sign_waypoint.lane_id - ego_waypoint.lane_id) <= 1)  # Allow slight lane deviation

        return dot_product > 0 and is_at_intersection_entry and is_same_lane  # ✅ Stop sign is ahead, at an intersection, and in the correct lane

    def check_stop_sign_violation(self):
        """Detects if the vehicle passes a stop sign at the start of an intersection without stopping."""
        ego_transform = self.ego_vehicles[0].get_transform()
        ego_location = ego_transform.location

        self.speed_history.append(self.get_speed())  # Store latest speed sample

        # **Step 1: Detect Stop Signs in Front at Intersection Entry and Correct Lane**
        for stop_sign in self.stop_signs:
            trigger_box = stop_sign.trigger_volume
            stop_sign_transform = stop_sign.get_transform()
            trigger_location = stop_sign_transform.transform(trigger_box.location)

            distance = ego_location.distance(trigger_location)

            if distance < self.stop_check_radius and self.is_stop_sign_ahead(stop_sign):
                # Entering stop sign zone
                if self.active_stop_sign is None:
                    self.active_stop_sign = stop_sign
                    self.speed_history.clear()  # Reset stop history when entering stop zone

        # **Step 2: Check for Violation When Leaving the Stop Sign**
        if self.active_stop_sign is not None:
            stop_sign_location = self.active_stop_sign.get_transform().location
            if ego_location.distance(stop_sign_location) > self.stop_check_radius:  # Left the stop sign zone
                # ✅ Only flag a violation if all 10 speed samples were above threshold
                if all(speed >= self.speed_threshold for speed in self.speed_history):
                    self.stop_sign = True
                self.active_stop_sign = None 
                if all(speed >= self.speed_threshold for speed in self.speed_history):
                    return
        self.stop_sign = False

        


    def check_red_light_violation(self, vehicle):
        world = vehicle.get_world()
        traffic_lights = world.get_actors().filter('traffic.traffic_light')

        for traffic_light in traffic_lights:
            # Check if the traffic light is red
            if traffic_light.state == carla.TrafficLightState.Red:
                trigger_box = traffic_light.trigger_volume  # Get the trigger volume (bounding box)
                trigger_location = traffic_light.get_transform().transform(trigger_box.location)

                # Get vehicle location
                vehicle_location = vehicle.get_transform().location
                vehicle_velocity = vehicle.get_velocity()
                # Compute distance between vehicle and the traffic light trigger volume
                distance = vehicle_location.distance(trigger_location)

                # Define a threshold to check if the vehicle is inside the light's influence zone
                if distance < 3:  # Adjust threshold based on CARLA map
                    speed = (vehicle_velocity.x**2 + vehicle_velocity.y**2 + vehicle_velocity.z**2)**0.5
                    if speed > 0.05:
                        #print("Red light violation detected!")
                        self.red_light = True
                        return
        self.red_light = False

    def _get_nearby_vehicles(self, radius=10.0):
        """Quickly filter nearby vehicles based on distance before deeper checks."""
        world = self.ego_vehicles[0].get_world()
        all_vehicles = world.get_actors().filter('vehicle.*')

        ego_location = self.ego_vehicles[0].get_transform().location
        ego_pos = np.array([ego_location.x, ego_location.y, ego_location.z])

        nearby_vehicles = []
        for vehicle in all_vehicles:
            if vehicle.id == self.ego_vehicles[0].id:
                continue

            vehicle_location = vehicle.get_transform().location
            vehicle_pos = np.array([vehicle_location.x, vehicle_location.y, vehicle_location.z])

            # **Use NumPy for fast distance filtering**
            if np.linalg.norm(ego_pos - vehicle_pos) <= radius:
                nearby_vehicles.append((vehicle, vehicle_location))

        return nearby_vehicles

    def check_distance(self, radius=5.0):
        world = self.ego_vehicles[0].get_world()
        all_vehicles = world.get_actors().filter('vehicle.*')  # Get all vehicles

        ego_transform = self.ego_vehicles[0].get_transform()
        ego_location = ego_transform.location
        ego_waypoint = world.get_map().get_waypoint(ego_location)

        ego_pos = np.array([ego_location.x, ego_location.y, ego_location.z])
        ego_forward_vector = np.array([ego_transform.get_forward_vector().x,
                                        ego_transform.get_forward_vector().y,
                                        ego_transform.get_forward_vector().z])

        nearby_vehicles = []

        # **1️⃣ Fast pre-filtering: Check distance before deeper checks**
        for vehicle in all_vehicles:
            if vehicle.id == self.ego_vehicles[0].id:
                continue

            vehicle_location = vehicle.get_transform().location
            vehicle_pos = np.array([vehicle_location.x, vehicle_location.y, vehicle_location.z])

            # **Fast Euclidean distance check**
            if np.linalg.norm(ego_pos - vehicle_pos) <= radius * 1.5:
                nearby_vehicles.append((vehicle, vehicle_location, vehicle_pos))

        # **2️⃣ Process only filtered vehicles**
        for vehicle, vehicle_location, vehicle_pos in nearby_vehicles:
            vehicle_waypoint = world.get_map().get_waypoint(vehicle_location)

            # **Check if the vehicle is in the same lane**
            if vehicle_waypoint.road_id == ego_waypoint.road_id and vehicle_waypoint.lane_id == ego_waypoint.lane_id:
                relative_position = vehicle_pos - ego_pos  # Vector from ego to vehicle

                # **3️⃣ Fast front-check using dot product**
                if np.dot(relative_position, ego_forward_vector) > 0:  # ✅ Vehicle is ahead
                    distance = np.linalg.norm(relative_position)

                    if distance <= radius and self.get_speed()>0.1:
                        self.too_close = True
                        return
        self.too_close = False

                        
    def check_wrong_way(self, vehicle, world):
        location = vehicle.get_transform().location
        waypoint = world.get_map().get_waypoint(location)
        if waypoint.is_junction:
            return  # Do nothing
        # Get vehicle heading
        vehicle_yaw = vehicle.get_transform().rotation.yaw

        # Get lane heading
        lane_yaw = waypoint.transform.rotation.yaw

        # Calculate yaw difference (normalize between -180 to 180 degrees)
        yaw_diff = abs((vehicle_yaw - lane_yaw + 180) % 360 - 180)

        if yaw_diff > 90:
            #print("Warning: Vehicle is driving in the wrong direction!")
            self.wrong_way = True
            return
        self.wrong_way = False


    ################################

    def signal_handler(self, signum, frame):
        """
        Terminate scenario ticking when receiving a signal interrupt
        """
        if self._agent_watchdog and not self._agent_watchdog.get_status():
            raise RuntimeError("Agent took longer than {}s to send its command".format(self._timeout))
        elif self._watchdog and not self._watchdog.get_status():
            raise RuntimeError("The simulation took longer than {}s to update".format(self._timeout))
        self._running = False

    def cleanup(self):
        """
        Reset all parameters
        """
        self._timestamp_last_run = 0.0
        self.scenario_duration_system = 0.0
        self.scenario_duration_game = 0.0
        self.start_system_time = 0.0
        self.start_game_time = 0.0
        self.end_system_time = 0.0
        self.end_game_time = 0.0

        self._spectator = None
        self._watchdog = None
        self._agent_watchdog = None
    #######################################
    def load_scenario(self, scenario, agent, route_index, rep_number, config=None):
    #######################################
    #def load_scenario(self, scenario, agent, route_index, rep_number):
        """
        Load a new scenario
        """
        ##############################
        self.collided = False
        self.config=config
        ##############################
        GameTime.restart()
        self._agent_wrapper = AgentWrapperFactory.get_wrapper(agent)
        self.route_index = route_index
        self.scenario = scenario
        self.scenario_tree = scenario.scenario_tree
        self.ego_vehicles = scenario.ego_vehicles
        self.other_actors = scenario.other_actors
        self.repetition_number = rep_number

        self._spectator = CarlaDataProvider.get_world().get_spectator()

        # To print the scenario tree uncomment the next line
        # py_trees.display.render_dot_tree(self.scenario_tree)

        self._agent_wrapper.setup_sensors(self.ego_vehicles[0])

    def build_scenarios_loop(self, debug):
        """
        Keep periodically trying to start the scenarios that are close to the ego vehicle
        Additionally, do the same for the spawned vehicles
        """
        while self._running:
            self.scenario.build_scenarios(self.ego_vehicles[0], debug=debug)
            self.scenario.spawn_parked_vehicles(self.ego_vehicles[0])
            time.sleep(1)

    def run_scenario(self):
        """
        Trigger the start of the scenario and wait for it to finish/fail
        """
        self.start_system_time = time.time()
        self.start_game_time = GameTime.get_time()

        # Detects if the simulation is down
        self._watchdog = Watchdog(self._timeout)
        self._watchdog.start()

        # Stop the agent from freezing the simulation
        self._agent_watchdog = Watchdog(self._timeout)
        self._agent_watchdog.start()

        self._running = True







        ##################################
        self.delay_running = False
        self.collided = False
        self._agent_wrapper._agent.end_episode(False, False)

        self.veh_wierdo = []
        self.first_veh_wierdo_update = True
        self.loop_seen = False
        self.veh_wierdo = []
        self.cnt = 0
        self.aggr_check = random.random()>0.3

        self.ttc_manager = UnifiedTTC(CarlaDataProvider.get_world(), self.ego_vehicles[0])

        #self.thread1 = threading.Thread(target=self.monitor1, daemon=True) 
        #self.thread2 = threading.Thread(target=self.monitor2, daemon=True) 
        #self.thread3 = threading.Thread(target=self.monitor3, daemon=True) 
        #self.thread4 = threading.Thread(target=self.monitor4, daemon=True) 
        #self.thread5 = threading.Thread(target=self.monitor5, daemon=True) 
        self.thread6 = threading.Thread(target=self.monitor6, daemon=True) 
        self.thread7 = threading.Thread(target=self.monitor7, daemon=True)
        

        #self.thread1.start()
        #self.thread2.start()
        #self.thread3.start()
        #self.thread4.start()
        #self.thread5.start()
        self.thread6.start()
        self.thread7.start()
        ##################################


        # Thread for build_scenarios
        self._scenario_thread = threading.Thread(target=self.build_scenarios_loop, args=(self._debug_mode > 0, ))
        self._scenario_thread.start()

        while self._running:
            self._tick_scenario()

        
        #################################
        #self.thread1.join() 
        #self.thread2.join() 
        #self.thread3.join() 
        #self.thread4.join() 
        #self.thread5.join() 
        self.thread6.join()
        self.thread7.join()
        #################################

    def _tick_scenario(self):
        """
        Run next tick of scenario and the agent and tick the world.
        """
        if self._running and self.get_running_status():
            CarlaDataProvider.get_world().tick(self._timeout)

        timestamp = CarlaDataProvider.get_world().get_snapshot().timestamp

        if self._timestamp_last_run < timestamp.elapsed_seconds and self._running:
            self._timestamp_last_run = timestamp.elapsed_seconds

            self._watchdog.update()
            # Update game time and actor information
            GameTime.on_carla_tick(timestamp)
            CarlaDataProvider.on_carla_tick()
            self.tick_count += 1
            self._watchdog.pause()

            if self.tick_count > 4000:
                raise TickRuntimeError("RuntimeError, tick_count > 4000")

            try:
                self._agent_watchdog.resume()
                self._agent_watchdog.update()
                ego_action = self._agent_wrapper()
                self._agent_watchdog.pause()

            # Special exception inside the agent that isn't caused by the agent
            except SensorReceivedNoData as e:
                raise RuntimeError(e)

            except Exception as e:
                raise AgentError(e)

            ####################################
            if self.delay_running:
                self._running = False
            ####################################

            self._watchdog.resume()
            self.ego_vehicles[0].apply_control(ego_action)




            ####################################
            # Drive with variable throttle
            all_actors = CarlaDataProvider.get_world().get_actors()
            vehicles = all_actors.filter('vehicle.*')
            ego_location = self.ego_vehicles[0].get_transform().location
            
            radius = 50
            # Loop through vehicles and apply changes to those within the radius
            #print('ssssssssssssssss')
            #print('ssssssssssssssss')
            #print('ssssssssssssssss')
            #print('ssssssssssssssss')
            #print('ssssssssssssssss')
            if self.veh_wierdo is not None:
                self.cnt+=1
                #print('cnt ', self.cnt)
            #min_distance = self._get_distance(ego_location, vehicles[1].get_transform().location)
            #print(self.first_veh_wierdo_update)
            

            #temp = self.check_lane_invasion(self.ego_vehicles[0], CarlaDataProvider.get_world())
            #temp = self.check_wrong_way(self.ego_vehicles[0], CarlaDataProvider.get_world())
            #self.check_red_light_violation(self.ego_vehicles[0])
            #self.check_stop_sign_violation(self.ego_vehicles[0])
            #self.check_distance(radius=5.0)
            
            #time.sleep(0.05)
            
            if len(self.veh_wierdo) ==0:
                for vehicle in vehicles:
                    if vehicle.id != self.ego_vehicles[0].id:  # Skip the ego vehicle itself
                        # Calculate distance from the ego vehicle
                        #print(vehicle.attributes.get('color'))
                        
                        self.loop_seen = True
                        distance = self._get_distance(ego_location, vehicle.get_transform().location)
                        #print(vehicle.get_transform().location)
                        if vehicle.get_transform().location.x>15 and vehicle.get_transform().location.x<25:
                            #print(vehicle.id, vehicle.get_transform().location)
                            if vehicle.get_transform().location.y>80 and vehicle.get_transform().location.y<90:
                                self.veh_wierdo.append((vehicle.id, vehicle.get_transform().location.y))

                        if vehicle.get_transform().location.x>31 and vehicle.get_transform().location.x<41:
                            #print(vehicle.id, vehicle.get_transform().location)
                            if vehicle.get_transform().location.y>120 and vehicle.get_transform().location.y<145:
                                self.veh_wierdo.append((vehicle.id, vehicle.get_transform().location.y))
                                #print('yeeeeeeeeees')
   
                                #if vehicle.attributes.get('color') == "42,99,159":#61,86,143":#"255,0,255":
                                #    print('------------')
                                #    print(vehicle.attributes.get('color'))
                                #    print('------------')
                                # Apply random throttle and steering for nearby vehicles
                                #random_throttle = 0.5#random.uniform(0.2, 0.7)
                                #random_steer = -0.1 #random.uniform(-0.2, 0.2)
                                #vehicle.apply_control(carla.VehicleControl(throttle=random_throttle, steer=random_steer, brake=0))

            random_throttle = 0.6#random.uniform(0.2, 0.7)
            random_steer = -0.04 #random.uniform(-0.2, 0.2)
            random_brake = 0
            """
            for vehicle in vehicles:
                for (id, y) in self.veh_wierdo:
                    if vehicle.id == id and self.aggr_check:
                        
                        if y<125:
                        #print("I FOUND IT")
                            vehicle.apply_control(carla.VehicleControl(throttle=random.uniform(0.4,0.7), steer=random.uniform(-0.10,-0.06), brake=0))
                        elif y>80 and y<90:
                                vehicle.apply_control(carla.VehicleControl(throttle=random.uniform(0.0,0.4), steer=random.uniform(0.08,0.12), brake=0))
                        else:
                            vehicle.apply_control(carla.VehicleControl(throttle=random.uniform(0.5,0.9), steer=random.uniform(-0.10, -0.06), brake=0))
                        
                        '''
                        if y<125 and y>100:
                        #print("I FOUND IT")
                            
                            vehicle.apply_control(carla.VehicleControl(throttle=random.uniform(0.5,0.6), steer=random.uniform(-0.09,-0.07), brake=0))
                        elif y>80 and y<90 and False:
                            vehicle.apply_control(carla.VehicleControl(throttle=random.uniform(0.2,0.3), steer=random.uniform(0.09,0.11), brake=0))
                        #else:
                        #    vehicle.apply_control(carla.VehicleControl(throttle=random.uniform(0.6,0.8), steer=random.uniform(-0.09, -0.07), brake=0))
                        '''
            """

            if self.loop_seen:
                self.first_veh_wierdo_update = False
            
            #try:
            if self._agent_wrapper._agent.is_honk():
                self.honk_action()
                #print('HHHHHHHHHHHHHHOOOOOOOOOOOOOOOOOOOOOONNNNNNNNNNNNNKKKKKKKKKKKKK')
            #except:
            #    print('no honk implemented')
            #reward = self.statistics_manager.compute_reward(self.config, self.scenario_duration_system, self.scenario_duration_game)
            
            self.reward = {'lane_invasion': self.lane_invasion,
                        'wrong_way': self.wrong_way,
                        'red_light': self.red_light,
                        'stop_sign': self.stop_sign,
                        'too_close': self.too_close,
                        'between2lane': self.bet2lane}
            '''
            for key in self.reward.keys():
                if self.reward[key] == True:
                    print(key)
            '''
            #print(self.reward)
            #self.reward = 0
            self._agent_wrapper._agent.set_reward(self.reward, self.ttc)
            ####################################
            # Tick scenario. Add the ego control to the blackboard in case some behaviors want to change it
            py_trees.blackboard.Blackboard().set("AV_control", ego_action, overwrite=True)
            self.scenario_tree.tick_once()

            if self._debug_mode > 1:
                self.compute_duration_time()

                # Update live statistics
                self._statistics_manager.compute_route_statistics(
                    self.route_index,
                    self.scenario_duration_system,
                    self.scenario_duration_game,
                    failure_message=""
                )
                self._statistics_manager.write_live_results(
                    self.route_index,
                    self.ego_vehicles[0].get_velocity().length(),
                    ego_action,
                    self.ego_vehicles[0].get_location()
                )

            if self._debug_mode > 2:
                print("\n")
                py_trees.display.print_ascii_tree(self.scenario_tree, show_status=True)
                sys.stdout.flush()

            if self.scenario_tree.status != py_trees.common.Status.RUNNING:
                self._running = False
                ######################################
                self.delay_running = True
                self.collided = True
                self._agent_wrapper._agent.end_episode(True, False)

            if self.statistics_manager != None:
                if self.statistics_manager.collision_check(self.route_index, self.scenario_duration_system, self.scenario_duration_game):
                    print('coooooooooooooooooooooooooooooooooollllllllllllllllllllllllllliddddddddddddddddddddddddddddddddddddedd')
                    self.delay_running = True
                    self.collided = True
                    # Forward WHY it terminated (1 physical, 2 rule, 3 blocked/deviation) so the
                    # learner can split cost/penalties by cause; falls back to the legacy 2-arg
                    # call for agents that predate the cause split.
                    cause = getattr(self.statistics_manager, 'last_termination_cause', 1)
                    try:
                        self._agent_wrapper._agent.end_episode(True, True, cause)
                    except TypeError:
                        self._agent_wrapper._agent.end_episode(True, True)
            
            if self._agent_wrapper._agent.is_stall():
                self.delay_running = True
                self.collided = True
                self._agent_wrapper._agent.end_episode(True, False)

                ######################################

            ego_trans = self.ego_vehicles[0].get_transform()
            self._spectator.set_transform(carla.Transform(ego_trans.location + carla.Location(z=70),
                                                          carla.Rotation(pitch=-90)))

    def get_running_status(self):
        """
        returns:
           bool: False if watchdog exception occured, True otherwise
        """
        if self._watchdog:
            return self._watchdog.get_status()
        return True

    def stop_scenario(self):
        """
        This function triggers a proper termination of a scenario
        """
        if self._watchdog:
            self._watchdog.stop()

        if self._agent_watchdog:
            self._agent_watchdog.stop()

        self.compute_duration_time()

        if self.get_running_status():
            if self.scenario is not None:
                self.scenario.terminate()

            if self._agent_wrapper is not None:
                self._agent_wrapper.cleanup()
                self._agent_wrapper = None

            self.analyze_scenario()

        # Make sure the scenario thread finishes to avoid blocks
        self._running = False
        self._scenario_thread.join()
        self._scenario_thread = None

    def compute_duration_time(self):
        """
        Computes system and game duration times
        """
        self.end_system_time = time.time()
        self.end_game_time = GameTime.get_time()

        self.scenario_duration_system = self.end_system_time - self.start_system_time
        self.scenario_duration_game = self.end_game_time - self.start_game_time

    def analyze_scenario(self):
        """
        Analyzes and prints the results of the route
        """
        ResultOutputProvider(self)
