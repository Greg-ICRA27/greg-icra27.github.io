export PYTHONPATH=$PYTHONPATH:${GREG_ROOT:?set GREG_ROOT to this repo root}/Greg
CUDA_VISIBLE_DEVICES=0 python Greg/train.py --gpus 1