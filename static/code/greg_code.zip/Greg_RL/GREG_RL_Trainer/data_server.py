import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, Response
from pydantic import BaseModel
from typing import List, Optional, Any
import multiprocessing as mp
import multiprocessing.managers
import os
import time
import logging
import sys
import threading
from collections import deque, Counter
from dotenv import load_dotenv

load_dotenv()


root_logger = logging.getLogger()
root_logger.setLevel(logging.INFO)
if root_logger.hasHandlers():
    root_logger.handlers.clear()
handler = logging.StreamHandler(sys.stdout)
formatter = logging.Formatter("%(asctime)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
handler.setFormatter(formatter)
root_logger.addHandler(handler)

MODEL_DIR = "GREG_RL_Trainer/model_pth"
LATEST_MODEL_FILE = os.path.join(MODEL_DIR, "latest_actor.pth")
os.makedirs(MODEL_DIR, exist_ok=True)

class QueueManager(mp.managers.BaseManager):
    pass



class Experience(BaseModel):
    state_bev: Any 
    next_state_bev: Any 
    pre_state: List[float]
    state: List[float]
    action: List[float]
    reward: List[float]  
    next_state: List[float] 
    done: bool
    action_queue: List[float]
    action_queue_next: List[float]
    env_metadata: str
    worker_id: Optional[int] = -1
    boxes: Any = None           # privileged GT box/route tokens [MAX_BOX_TOKENS, BOX_COL_DIM] (nested list)
    next_boxes: Any = None      # same for s'; default None keeps old workers compatible
    route_scalars: Any = None       # [speed, target_point(2), command(6)] = 9-d; default None keeps old workers ok
    next_route_scalars: Any = None  # same for s'
    # Optional RSSM filter states (FULL_FILTER workers only). A worker that sends [] or nothing
    # yields None, and the learner substitutes zeros.
    h: Any = None                   # 256-d GRU state at t
    h_next: Any = None              # 256-d GRU state at t+1

class SummaryLogger:
    def __init__(self, window_seconds: int = 300):
        self.window_seconds = window_seconds
        self.records = deque()
        self._lock = threading.Lock()

    def add_record(self, ip_address: str, batch_size: int):
        """Adds a record of a received batch."""
        current_time = time.time()
        with self._lock:
            self.records.append({'time': current_time, 'ip': ip_address, 'size': batch_size})

    def _prune_records(self):
        # caller must already hold self._lock
        cutoff_time = time.time() - self.window_seconds
        while self.records and self.records[0]['time'] < cutoff_time:
            self.records.popleft()

    def get_summary(self):
        """Calculates and returns a summary of the records within the window."""
        with self._lock:
            self._prune_records()
            if not self.records:
                return 0, 0, {}

            total_batches = len(self.records)
            total_experiences = sum(r['size'] for r in self.records)
            ip_counts = Counter(r['ip'] for r in self.records)
            return total_batches, total_experiences, ip_counts

    def log_summary(self):
        """Formats and logs the summary."""
        total_batches, total_experiences, ip_counts = self.get_summary()
        
        summary_lines = [
            "\n",
            f"--- 📊 Data Server Summary (Last {self.window_seconds // 60} Minutes) ---",
            f"Total Batches Received: {total_batches}",
            f"Total Experiences Received: {total_experiences}",
            "Batch sources by IP:"
        ]
        if not ip_counts:
            summary_lines.append("  (No data received in this window)")
        else:
            for ip, count in sorted(ip_counts.items()):
                summary_lines.append(f"  - {ip}: {count} batches")
        summary_lines.append("--------------------------------------------------")
        
        logging.info("\n".join(summary_lines))

def run_summary_logger(logger: SummaryLogger, interval_seconds: int):
    while True:
        time.sleep(interval_seconds)
        logger.log_summary()

class QueueConnector:
    def __init__(self, host, port, authkey):
        self.manager = QueueManager(address=(host, port), authkey=authkey)
        self.queue = None

    def connect(self):
        logging.info("🤝 [Data Server] Attempting to connect to learner's queue...")
        while True:
            try:
                self.manager.connect()
                self.queue = self.manager.get_queue()
                logging.info("✅ [Data Server] Connection to learner's queue successful.")
                return
            except (ConnectionRefusedError, FileNotFoundError):
                logging.warning("⏳ [Data Server] Learner queue not ready. Retrying in 5 seconds...")
                time.sleep(5)
            except Exception as e:
                logging.error(f"❌ [Data Server] An unexpected error occurred during connection: {e}")
                time.sleep(5)

app = FastAPI()
connector = QueueConnector(
    host=os.environ.get('QUEUE_HOST', '127.0.0.1'),
    port=int(os.environ.get('QUEUE_PORT', 50000)),
    authkey=os.environ.get('QUEUE_AUTHKEY', 'sac-secret').encode(),
)
summary_logger = SummaryLogger(window_seconds=300)

@app.on_event("startup")
def startup_event():
    connector.connect()

    summary_thread = threading.Thread(
        target=run_summary_logger,
        args=(summary_logger, 300), # Log every 5 minutes
        daemon=True
    )
    summary_thread.start()
    logging.info("📊 [Data Server] Periodic summary logger started.")

@app.post("/add_batch/")
def add_batch(experiences: List[Experience], request: Request):
    if not experiences:
        return {"status": "received empty batch"}

    client_host = request.client.host
    batch_size = len(experiences)
    worker_id = experiences[0].worker_id

    summary_logger.add_record(client_host, batch_size)
    
    logging.info(f"📥 [Server] Received batch of {batch_size:<4} from Worker ID: {worker_id:<2} (IP: {client_host})")
    
    experience_dicts = [exp.dict() for exp in experiences]
    
    while True:
        try:
            connector.queue.put(experience_dicts)
            return {"status": f"batch of {len(experiences)} added to queue"}
        except (BrokenPipeError, EOFError, ConnectionResetError):
            logging.warning("⚠️ [Data Server] Broken pipe detected! Learner likely restarted.")
            logging.warning("⚠️ [Data Server] Attempting to reconnect to the new learner queue...")
            connector.connect()
        except Exception as e:
            logging.error(f"❌ [Data Server] An unexpected error occurred during queue.put: {e}")
            time.sleep(5)
            connector.connect()


@app.get("/get_latest_weights/")
def get_latest_model():
    if os.path.exists(LATEST_MODEL_FILE):
        with open(LATEST_MODEL_FILE, "rb") as f:
            content = f.read()
        return Response(content=content, media_type='application/octet-stream')
    else:
        return {"error": "Model not found yet. Please wait for the learner to save one."}, 404

def run_server(host=None, port=None):
    host = host or os.environ.get('DATA_SERVER_HOST', '0.0.0.0')
    port = int(port or os.environ.get('DATA_SERVER_PORT', 34543))
    logging.info(f"🚀 [Data Server] Starting at http://{host}:{port}")
    uvicorn.run(app, host=host, port=port, log_level="info")

if __name__ == '__main__':
    QueueManager.register('get_queue')
    run_server()
