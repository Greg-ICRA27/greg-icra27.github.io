#!/bin/bash
# `source .../activate` with no args inherits this script's own $1 (the WORKER_ID) as the target
# env name if positional params aren't cleared first -- conda then fails with
# "EnvironmentNameNotFound: Could not find conda environment: <worker id>".
_worker_id_arg="$1"
set --
source ~/miniconda3/bin/activate
set -- "$_worker_id_arg"

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# All machine-specific config (CARLA_ROOT, GREG_IL_CKPT, ROUTES_FILE, port bases, ...) lives in
# .env, not here. Copy .env.example to .env and fill it in.
set -a
[ -f "$SCRIPT_DIR/.env" ] && source "$SCRIPT_DIR/.env"
set +a
: "${CARLA_ROOT:?Set CARLA_ROOT in $SCRIPT_DIR/.env}"
: "${GREG_IL_CKPT:?Set GREG_IL_CKPT in $SCRIPT_DIR/.env}"
: "${ROUTES_FILE:?Set ROUTES_FILE in $SCRIPT_DIR/.env}"
CARLA_PORT_BASE="${CARLA_PORT_BASE:-30200}"
CARLA_RPC_PORT_BASE="${CARLA_RPC_PORT_BASE:-30000}"
TRAFFIC_PORT_BASE="${TRAFFIC_PORT_BASE:-50000}"

export WORK_DIR="$(cd "${SCRIPT_DIR}/../GREG_RL_worker" && pwd)"
export CARLA_ROOT
export PYTHONPATH=$PYTHONPATH:${CARLA_ROOT}/PythonAPI
export PYTHONPATH=$PYTHONPATH:${CARLA_ROOT}/PythonAPI/carla
export SCENARIO_RUNNER_ROOT=${WORK_DIR}/scenario_runner
export LEADERBOARD_ROOT=${WORK_DIR}/leaderboard
export PYTHONPATH="${CARLA_ROOT}/PythonAPI/carla/":"${SCENARIO_RUNNER_ROOT}":"${LEADERBOARD_ROOT}":${PYTHONPATH}

export PYTHONPATH=$PYTHONPATH:leaderboard
export PYTHONPATH=$PYTHONPATH:leaderboard/team_code
export PYTHONPATH=$PYTHONPATH:scenario_runner

export CHALLENGE_TRACK_CODENAME=SENSORS


conda activate greg_rl
rm -f results_TCP_test.json
WORKER_ID=$1
num=$((WORKER_ID+1))


raw=$(cat number.txt)
num_instance=$(echo "$raw" | sed 's/[^0-9]//g')
num_instance=$((num_instance))


if [ "$num" -le 24 ]; then
    carla_port=$((CARLA_PORT_BASE+10*(num-1)))
    carla_rpc_port=$((CARLA_RPC_PORT_BASE+10*(num-1)+1))
else
    carla_port=$((CARLA_PORT_BASE+10*(num-1)+3))
    carla_rpc_port=$((CARLA_RPC_PORT_BASE+10*(num-1)+4))
fi

trraffic_port=$((TRAFFIC_PORT_BASE+(num-1)+5))
remainder=$((((num+1)%7)+1))
town=$(printf "%02d" "$remainder")
temp=$(( (num_instance/2) > 0 ? (num_instance/2) : 1 )) # guard: num_instance/2 is 0 (div-by-zero below) for a single-worker run
cuda_num=$(((num-2)/temp))
echo "CUDA $cuda_num FOR TCP$num and $num_instance Instances which result in $temp per GPU"

echo "$num $carla_port $carla_rpc_port $trraffic_port $town $cuda_num"
export CUDA_VISIBLE_DEVICES=$cuda_num
export SAVE_PATH=./TCP${num}
export CHALLENGE_TRACK_CODENAME=SENSORS

kill -9 $(lsof -t -i:$carla_port)

# command1 is intentionally a no-op: leaderboard_trainer.py's _setup_simulation() launches its
# own CARLA server internally (find_free_port() + gpu_rank+2), so a separately-launched CARLA
# here would just be a redundant second instance competing for GPU/VRAM.
command1=""
command2="python leaderboard/leaderboard/leaderboard_trainer.py --routes=$ROUTES_FILE --repetitions=1 --agent=leaderboard/our_team/Greg_worker.py --checkpoint=results_TCP_test_$WORKER_ID.json --agent-config=$GREG_IL_CKPT --resume=True --port=$carla_port --traffic-manager-port=$trraffic_port --debug=0 --track=${CHALLENGE_TRACK_CODENAME} --gpu-rank=$CUDA_VISIBLE_DEVICES"

# Change directory and run command1 in the background (no-op; see above)
cd "$CARLA_ROOT"
eval "$command1" &

sleep 1

# Change directory and run command2 in the background
cd "$WORK_DIR"
eval "$command2" &

# Wait for the background jobs to complete.
wait

