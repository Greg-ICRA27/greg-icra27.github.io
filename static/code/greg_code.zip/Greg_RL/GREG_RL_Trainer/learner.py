import time
import numpy as np
from collections import deque
import random
import multiprocessing as mp
import multiprocessing.managers
import pickle
import os
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.distributions import Normal, kl
from typing import List

from torch.amp import autocast, GradScaler
import torch._functorch.config
import threading
from collections import Counter

from sklearn.metrics.pairwise import cosine_similarity

from Greg.model import Greg, Critic, ForwardModel, RNDModel, BoxContextEncoder, RSSMBelief, symlog, symexp
from Greg.config import GlobalConfig

from collections import OrderedDict
import copy

from itertools import chain

import wandb
from readds import FileSynchronizer, save_current_time, get_start_time, delete_generated_files




import threading
import queue
import time
torch.backends.cudnn.benchmark = True

import jsonpickle
from transformers import AutoModel, AutoConfig
from dotenv import load_dotenv
import json as _json

load_dotenv()

torch.set_float32_matmul_precision('high')

# W&B run to resume; set in .env. Leave unset to start a fresh run.
HARDCODED_RUN_ID = os.environ.get("WANDB_RUN_ID") or None
wandb.login(key=os.environ.get("WANDB_API_KEY"))
run_wandb = None
REPLAY_BUFFER_CAPACITY = 400_000  # sized for the 5 Hz decimated stream
TRAINING_BATCH_SIZE = 1024  # transitions per gradient step
SAVE_INTERVAL_SECONDS = 600
MODEL_SAVE_INTERVAL = 60
VERSIONED_SAVE_INTERVAL_SECONDS = 1200 # 10 minutes
QUEUE_PORT = int(os.environ.get('QUEUE_PORT', 50000))
AUTH_KEY = os.environ.get('QUEUE_AUTHKEY', 'sac-secret').encode()
MODEL_DIR = "GREG_RL_Trainer/model_pth"
LATEST_MODEL_FILE = os.path.join(MODEL_DIR, "latest_actor.pth")
SAC_CHECKPOINT_FILE = os.path.join(MODEL_DIR, "sac_checkpoint.pth")


ORGINAL_TCP_CONFIG = os.environ["GREG_IL_CKPT"]  # IL checkpoint to warm-start the RL policy from; set in .env
SAC_WARMUP_FILE = os.environ.get("SAC_WARMUP_FILE", "./warmup/sac_checkpoint.pth")  # set in .env
ORIGINAL = True

STATE_DIM = 512
ACTION_DIM = 7
NUM_DISCRETE_ACTIONS = 6
ACTION_QUEUE_SIZE = 10

TARGET_UTD_RATIO = 3.0 # Target one update for every one new experience
UTD_ADJUSTMENT_INTERVAL = 120 # Adjust sleep time every 30 seconds
UTD_KP = 0.1 # Proportional gain for the controller
UTD_KI = 0.01 # Integral gain for the controller
SLEEP_INIT = 0.005

UPER_CANDIDATE_SET_SIZE = 4*TRAINING_BATCH_SIZE # Size of the candidate pool for DPP/diversity sampling (k)
UPER_ALPHA = 0.6 # Priority exponent for uncertainty
UPER_BETA = 0.3  # Priority exponent for age
UPER_EPSILON = 1e-6 # Small constant to avoid zero priority
DIVERSITY_ANCHORS = 8 # Number of random anchors for vectorized diversity sampling

# never-sampled quota
NEW_ENTRY_BATCH_QUOTA = 32   # max batch slots per update reserved for never-yet-sampled transitions
PRIORITY_ELITE_BATCH_QUOTA = 128

NUM_REWARD_TERM = 11   # [r, Rdis, Rspeed, Rsteer, Rds, Rreverse, speed, collision, ttc, desired_speed, term_cause]

NUM_CRITICS = 10
NUM_TARGET_CRITICS = 2
ACCUMULATION_STEPS = 1
LOG_INTERVAL = 1
CRITIC_COMPILE_MODE = None   # torch.compile mode for the critics (None = default)

ACTOR_COMPILE = True


USE_AMP = False

GPU_REPLAY_BUFFER=True
SAMPLE_RATIO_REWARD_TO_COST = 0.75

# Rare unsafe transitions live in their own slot range so the safe flood can NEVER evict them
STRATIFIED_REPLAY_BUFFER = True   # use StratifiedGpuReplayBuffer instead of the shared-pool GpuReplayBuffer
UNSAFE_REPLAY_BOOST = 10          # unsafe-vs-safe per-sample replay-frequency ratio
UNSAFE_FRAC_MAX = 0.30            # cap on the unsafe (cost) share of the candidate pool;
                                  # cap the unsafe share of the candidate pool at 30%
UNSAFE_FRAC_MIN = 0.01            # floor (only applies once the unsafe partition is non-empty)
CAP_UNSAFE = 40_000               # protected (unsafe) partition slots; SAFE gets REPLAY_BUFFER_CAPACITY - CAP_UNSAFE.
UNSAFE_COST_THRESHOLD = 0.15      # route to the unsafe partition if cost_raw > this ...
COLLISION_REWARD_INDEX = 7        # ... OR the stored collision flag (this reward index) is set

USE_BOX_CRITIC = False           # feed privileged box tokens to the critics
ROUTE_DIM = 10                   # route scalars [speed(1), target_point(2), command(6), time_since_full_stop(1)]
USE_ROUTE = True

EMBED_DENOISE_ENABLED = True
DENOISER_LR = 3e-4               # dedicated AdamW LR for the denoiser

ACTOR_GRAD_CLIP = 3.0            # policy_net grad-norm clip
REWARD_CRITIC_GRAD_CLIP = 80.0  # reward critic ensemble; watch Gradients/critic_grad_norm stays below this
COST_CRITIC_GRAD_CLIP = 40.0    # cost critic ensemble grad-norm clip
DENOISER_GRAD_CLIP = 15.0       # grad-norm clip on the denoiser (accumulated reward+cost grads)
BOX_GRAD_CLIP = 20.0            # shared box encoder (inactive: USE_BOX_CRITIC=False)
MAX_OBJ = 30                      # max GT objects (carla_garage max_num_bbs)
MAX_ROUTE = 20                    # max route tokens (PlanT 2.0 path_len)
MAX_BOX_TOKENS = MAX_OBJ + MAX_ROUTE          # T = 50 stored tokens (the model prepends its own anchor)
BOX_ATTR_DIM = 6                 # PlanT 2.0 attrs: [x, y, yaw, speed, extent_x, extent_y]
BOX_COL_DIM = BOX_ATTR_DIM + 1   # +1 trailing object-class id column => 7 columns stored per token
BOX_OBJECT_TYPES = 7             # car, walker, static, stop_sign, traffic_light, emergency, + pad(0)
BOX_N_EMBD = 512                 # bert-medium hidden
BOX_N_LAYER = 2                  # auxiliary critic encoder over low-dim box/route geometry
BOX_N_HEAD = 8                   # bert-medium heads
BOX_DROPOUT = 0.1
BOX_GRAD_CKPT = False

GAMMA_COST = 0.98        # discount for the cost critic; rescaling this also rescales the terminal mass SPIKE*(1+1/(1-gamma_c))
COST_TERMINAL_MASS = 1.0 + 1.0 / (1.0 - GAMMA_COST)  # = 51.0 at gamma_c=0.98

COST_TERM_SPIKE = 0.6 * 4.605170185988091          # 2.763
# Dense proximity cost from inverse time-to-collision (Eq. 3). Zero beyond COST_TTC_HORIZON
# seconds and rising linearly in 1 - ttc/horizon as the gap closes, capped at COST_TTC_WEIGHT so a
# single dense step can never outweigh a terminal event.
# Random network distillation bonus (Eq. 2). r_int is the predictor error on the next-state
# embedding, normalised by its running std so the bonus stays O(1) as the predictor converges.
RND_ENABLED   = True
RND_LR        = 3e-4
OMEGA_INT     = 0.1                                # omega_int, the exploration weight in Eq. 2
RND_CLIP      = 5.0                                # clip the normalised bonus
# Per-step raw cost -> discounted cost return, for comparing c_max against a cost Q-value.
COST_BUDGET_TO_RETURN = COST_TERMINAL_MASS / (1.0 - GAMMA_COST)   # = 2550 at gamma_c=0.98
COST_TTC_HORIZON = 4.0                             # seconds; beyond this there is no proximity cost
COST_TTC_WEIGHT  = 0.25 * COST_TERM_SPIKE          # worst-case dense step = 1/4 of a terminal spike
COST_LABEL_MAX  = COST_TERM_SPIKE * COST_TERMINAL_MASS   # 140.9 at gamma_c=0.98

DIST_CREDIT_ENABLED = False  # distance leg of the CMDP surrogate
DIST_CRITIC_LOSS_WEIGHT = 1.0  # weight on the distance head's MSE inside cost_critic_loss
DIST_CREDIT_FRAC = 0.10    # inert while DIST_CREDIT_ENABLED=False; caps the credit as a fraction of cost
KAPPA_C = 0.26 * COST_LABEL_MAX
UCB_BETA = 1.0             # cost-critic pessimism: actor minimizes mean + UCB_BETA*std (UCB)
# label-keyed danger gate
COST_GATE_ENABLED = True
COST_GATE_MAX_S2T = 4       # gate engages only within this many macro-steps of a terminal
NSTEP_S2T_NONE = 9999.0     # sentinel stored when no terminal is visible inside the lookahead window
COST_GATE_LAMBDA = 1.5      # effective cost price on unsafe-labeled samples
CONFORMAL_TRUST_REGION = True
CTR_ALPHA = 0.10          # conformal frontier = (1-alpha) percentile of the policy-action sigma
CTR_EMA = 0.99            # EMA smoothing of the per-batch percentile into q_hat
CTR_OPTIMISM_BETA = 0.0   # bounded in-band optimism coefficient (lcb_beta stays the out-of-band tax)

DECIMATION_K = 4            # 5 Hz decimation in reward units; must equal the rollout agent's DECISION_EVERY
COST_LIMIT_STD_MULT = 2.0   # d = empirical mean cost of pi_IL minus this many std
LAMBDA_LR = 1e-3         # dual-ascent LR for the Lagrange multiplier (SGD)
RHO = 0.01               # augmented-Lagrangian quadratic penalty coefficient rho
KL_WEIGHT_LR = 2.5e-4      # dual-ascent LR for the two KL-anchor weights (SGD on relative violation)

ANCHOR_GATE_ENABLED = True
ANCHOR_GATE_K = 2.0        # sigmas of ensemble evidence required to release the anchor (~97.5% one-sided test)
ANCHOR_GATE_FLOOR = 0.1    # residual anchor weight when the gate is open (keeps a light IL leash)
ANCHOR_GATE_INCLUDE_COST = True   # scores the gate on reward-LCB minus lambda*cost, not reward alone
ANCHOR_GATE_WARMUP = 20_000  # updates before the gate may open (critic is unreliable before this)
LOG_LAMBDA_INIT = -2.302585093  # lambda = 0.1 at start; auto-scales via dual ascent on online cost
LOG_LAMBDA_MIN = -8.0      # lambda in [~3.3e-4, ~10] (exp(2.3) ~= 10; raise MAX to 4.6 for ~100)
LOG_LAMBDA_MAX = 2.3
LAMBDA_DELAY_FREQ = 10      # dual ascent every N actor steps (actor itself runs every policy_delay_freq updates)

N_STEP_RETURN = 4
N_STEP_COST_LOOKAHEAD = 30   # lookahead window for exact (non-bootstrapped) cost credit; 30 macro-steps = 6.0s

ONLINE_COST_EMA_WINDOW = 30000   # effective averaging horizon in transitions (~dozens of episodes)
ONLINE_COST_WARMUP_MIN_TRANSITIONS = 10000  # fresh transitions required before the budget scheduler measures its warmup baseline
ONLINE_DIST_EPS = 1e-6  # guards a denominator from going to zero

RESET_ONLINE_DUAL_ON_LOAD = False

COST_LIMIT_WARMUP_STEPS = 500    # actor steps measuring the baseline achieved cost before constraining
COST_LIMIT_FLOOR_FRAC   = 0.5   # anneal toward this fraction of the measured warmup baseline
COST_LIMIT_ABS_BACKSTOP = 1e-4   # tiny absolute backstop so the floor is never exactly 0
COST_LIMIT_DECAY_FACTOR = 0.985  # geometric tighten per achievement window (closer to 1.0 == slower)
COST_LIMIT_MEET_STEPS   = 2500   # consecutive achieved (EMA(cost) <= margin*d) actor steps before each tighten
COST_LIMIT_TIGHTEN_MARGIN = 0.98   # "achieved" means EMA(cost) <= this * d
COST_LIMIT_RELAX_STEPS    = 10000  # persistent-violation patience before relaxing d
COST_LIMIT_RELAX_CAP_MULT = 2.0    # relax may lift d to at most this x the warmup baseline
COST_LIMIT_RELAX_HEADROOM = 1.05   # relax target EMA*this: slack so lambda can eventually decay, not freeze
COST_LIMIT_RELAX_STEP_FRAC = 0.25   # each relax moves only this fraction of the way toward the target
COST_LIMIT_TIGHTEN_LAMBDA_MAX = float('inf')  # inf = original unconditional ratchet (gate disabled)

CAPS_WEIGHT_STEER = 1.0   # weight on the temporal steer smoothness penalty


USE_ACTION_QUEUE = False

RSSM_ENABLED = True
RSSM_OBS_DIM = STATE_DIM + ROUTE_DIM   # 522 = [frozen IL embedding, route scalars] — the RSSM's e_t
RSSM_DETER_DIM = 256           # h (GRU state; recomputed per batch by burn-in, never shipped/stored)
RSSM_BURNIN_K = 16             # burn-in window length (frames of history replayed before each chunk)
RSSM_BURNIN_L = RSSM_BURNIN_K - 1          # frames stored per window (the history; e_t itself is the stored state)
RSSM_BURNIN_FEAT = RSSM_OBS_DIM + ACTION_DIM   # 529 = [embedding, route, executed action] per frame
RSSM_BURNIN_COMPILE = True  # compiles the burn-in loop; eval agents (which never set this) load identical tensors
RSSM_STOCH_GROUPS = 16         # z: 16 categorical groups x 16 classes (DreamerV3-style)
RSSM_STOCH_CLASSES = 16
RSSM_BELIEF_DIM = RSSM_DETER_DIM + RSSM_STOCH_GROUPS * RSSM_STOCH_CLASSES   # 512 = [h, z]
RSSM_HIDDEN = 512
RSSM_UNIMIX = 0.01             # 1% uniform mix in the categoricals (degenerate-softmax guard)
RSSM_LR = 3e-4
RSSM_GRAD_CLIP = 100.0         # Dreamer-style loose clip
RSSM_TRAIN_EVERY = 4           # world-model steps per SAC update (1 = every update)
RSSM_SEQ_LEN = 32              # chunk length (episode-contiguous windows; h0=0 per chunk, as Dreamer)
RSSM_SEQ_BATCH = 64            # chunks per world-model step (= up to 2048 timesteps)
RSSM_SEQ_CAPACITY = 4096       # chunk ring (~131k transitions, ~0.27 GB GPU @522-d; NOT persisted)
RSSM_MIN_CHUNKS = 64           # don't train the world model before this many chunks exist
RSSM_MIN_PARTIAL = 2           # commit an episode-final partial chunk only with >= this many steps
RSSM_KL_FREE_NATS = 1.0        # free bits per (sample, step) — the posterior-collapse guard
RSSM_KL_DYN_SCALE = 0.5        # KL(sg(post) || prior): trains the prior to predict (DreamerV3 β_dyn)
RSSM_KL_REP_SCALE = 0.1        # KL(post || sg(prior)): keeps the posterior predictable (β_rep)
RSSM_COST_POS_WEIGHT = 5.0     # BCE pos_weight on the cost head — cost>0 steps are rare
RSSM_COST_RESERVOIR_CAP = 512  # cost-positive chunks (~16k transitions, ~35 MB GPU)
RSSM_COST_SAMPLE_FRAC = 0.25   # fraction of each RSSM batch drawn from the reservoir (when filled)
RSSM_COST_RESERVOIR_FILE = "GREG_RL_Trainer/rssm_cost_reservoir.pt"
RSSM_SEQ_RING_FILE = "GREG_RL_Trainer/rssm_seq_ring.pt"   # the main chunk ring, persisted
MVE_ENABLED = True
MVE_HORIZON = 20               # imagined steps past the n-step landing state (target horizon 4+20)
MVE_MIN_CHUNKS = 512           # chunk gate: w held at 0 below this
MVE_FULL_CHUNKS = 2048         # w scales linearly to MVE_WEIGHT by this many chunks
MVE_WEIGHT = 0.4               # final blend weight w on the model-expanded tail
CRITIC_WARM_UP = 25000         # updates before the actor unfreezes / the denoiser activates
MVE_WARMUP_START = CRITIC_WARM_UP + 10000   # must track CRITIC_WARM_UP if that changes
MVE_WARMUP_STEPS = 15000       # linear ramp length: w = MVE_WEIGHT at WARMUP_START + WARMUP_STEPS
MVE_DIAG_START = 10000         # compute + log MVE tails (w still 0) from here — free model-quality read
MVE_COST_TERM_SPIKE = COST_TERM_SPIKE           # alias of the definition next to COST_TERMINAL_MASS (KAPPA_C also uses it)
MVE_COST_EVENT_MASS = MVE_COST_TERM_SPIKE * COST_TERMINAL_MASS

MVE_SKIP_UNSAFE = True  # world-model imagination is optimistic on the danger tail; skip it for unsafe rows

# Longer-horizon cost expansion. This is NOT the safety mechanism: safety comes from the
# stratified replay buffer, which keeps a dedicated cost partition so safety-critical
# transitions cannot be crowded out of the batch by ordinary driving. This expansion only
# lengthens the effective horizon of the cost target that the buffer already supplies.
SAFETY_MVE_ENABLED = True
SAFETY_MVE_HORIZON = 20
SAFETY_MVE_PARTICLES = 8
SAFETY_MVE_ROWS = 64
SAFETY_MVE_EVERY = 4
SAFETY_MVE_PHASE = 2                  # stagger from RSSM_TRAIN_EVERY phase 0
SAFETY_MVE_CACHE_MAX_AGE = 5000     # bounded policy/RSSM/target drift; stale rows fall back safely
SAFETY_MVE_CACHE_BLEND = MVE_WEIGHT
SAFETY_MVE_ASYNC = True             # refresh on a private CUDA stream after targets are assembled

# Event-centred world-model supervision. Ordinary coverage remains 32 steps; only the protected
# failure reservoir stores 64-step overlapping terminal windows.
RSSM_EVENT_SEQ_LEN = 64
RSSM_OVERSHOOT_ENABLED = True
RSSM_OVERSHOOT_DISTANCES = (1, 2, 4, 8, 16, 32)
RSSM_OVERSHOOT_WEIGHT = 0.10
RSSM_SAFETY_AUX_WEIGHT = 0.25

TIME_FORMAT = '%Y-%m-%d-%H-%M'
START_TIME_FILE = 'GREG_RL_Trainer/start_time.txt'

# Remote sync server list (IPs/hosts/paths for the readds pull) lives outside the script --
# see RL_SYNC_SERVERS_FILE in .env / sync_servers.json.example.
with open(os.environ.get('RL_SYNC_SERVERS_FILE', 'GREG_RL_Trainer/sync_servers.json')) as _f:
    _sync_servers = _json.load(_f)

config_readds = {
        'servers': _sync_servers,
        'local_dir': './GREG_RL_Trainer/downloaded_files',
        'merged_file_path': './GREG_RL_Trainer/merged_data.txt',
        'interval_seconds': 600,
    }

class QueueManager(mp.managers.BaseManager):
    pass


def nan_check(tensor, name):
    if torch.isnan(tensor).any() or torch.isinf(tensor).any():
        print(f"*** NaN/Inf in {name}: min={tensor.min().item()} max={tensor.max().item()} ***")
        raise RuntimeError(f"NaN/Inf detected in {name}")



class ExponentialMovingAverage:
    def __init__(self, alpha=0.999):
        self.alpha = alpha
        self.mean = 0.0
        self.initialized = False

    def update(self, new_value):
        if not self.initialized:
            self.mean = new_value
            self.initialized = True
        else:
            self.mean = (self.alpha * self.mean) + ((1 - self.alpha) * new_value)

class AdaptiveEntropyScheduler:
    def __init__(self,
                 initial_target_entropy: float,
                 decay_factor: float = 0.99,
                 stability_threshold: float = 0.01,
                 smoothing_factor: float = 0.999,
                 meet_time_threshold: float = 100,
                 min_target_entropy: float = 0.1):
        
        self.target_entropy = initial_target_entropy
        self.min_target_entropy = min_target_entropy
        self.decay_factor = decay_factor
        self.stability_threshold = stability_threshold
        self.smoothing_factor = smoothing_factor
        self.meet_time_threshold = meet_time_threshold
        self.meet_time = 0

        self.ema_entropy_mean = 0.0
        self._is_first_step = True
        
        # Determine if we are moving "down" (e.g., -1.2 to -1.45) 
        # or "up" (e.g., 2.0 to 1.0)
        self.is_descending = (self.min_target_entropy < self.target_entropy)

    def step(self, current_policy_entropy: float):
        # 1. Immediate exit if we are already at the goal
        if self.target_entropy == self.min_target_entropy:
            return

        # 2. Update EMA
        if self._is_first_step:
            self.ema_entropy_mean = current_policy_entropy
            self._is_first_step = False
        else:
            self.ema_entropy_mean = (self.smoothing_factor * self.ema_entropy_mean +
                                     (1 - self.smoothing_factor) * current_policy_entropy)

        # 3. Stability Check
        if abs(self.ema_entropy_mean - self.target_entropy) < self.stability_threshold:
            self.meet_time += 1
            
            if self.meet_time >= self.meet_time_threshold:
                self.meet_time = 0
                
                # Use a direction-agnostic decay
                # If we are moving away from zero (like -1.2 to -1.45)
                if self.is_descending:
                    # Logic to make the number "smaller" (more negative)
                    new_target = self.target_entropy / self.decay_factor if self.target_entropy < 0 else self.target_entropy * self.decay_factor
                    self.target_entropy = max(new_target, self.min_target_entropy)
                else:
                    # Logic to make the number "larger" (closer to zero or positive)
                    new_target = self.target_entropy * self.decay_factor if self.target_entropy < 0 else self.target_entropy / self.decay_factor
                    self.target_entropy = min(new_target, self.min_target_entropy)
                
                # Final Snap: Ensure we don't oscillate at the very end
                if (self.is_descending and self.target_entropy < self.min_target_entropy) or \
                   (not self.is_descending and self.target_entropy > self.min_target_entropy):
                    self.target_entropy = self.min_target_entropy
        else:
            # Reset patience if the policy drifts too far from the current target
            self.meet_time = 0

    def get_target(self) -> float:
        return self.target_entropy

    def state_dict(self) -> dict:
        return {
            'target_entropy': self.target_entropy,
            'ema_entropy_mean': self.ema_entropy_mean,
            '_is_first_step': self._is_first_step,
        }

    def load_state_dict(self, state_dict: dict):

        self.target_entropy = state_dict['target_entropy']
        self.ema_entropy_mean = state_dict['ema_entropy_mean']
        self._is_first_step = state_dict['_is_first_step']


class CostLimitScheduler:
    """Achievement-gated curriculum on the CMDP cost budget d (self.cost_limit).

    Phase 1 (warmup): for the first `warmup_steps` observations, do NOT constrain -- get_target()
    returns `warmup_limit` (a large value that keeps the constraint slack so lambda decays to its
    floor) while we measure the current policy's achieved cost-return (running mean of observed
    ucb_q_cost). At the end of warmup, d is seeded at that measured baseline -- we start exactly at
    what the policy already does, so the constraint is feasible from the first constrained step.

    Phase 2 (descend): ratchet d down geometrically (× decay_factor) toward `min_cost_limit` (a small
    absolute positive floor, never 0), but ONLY once the achieved cost has stably met the current
    budget WITH MARGIN (EMA(cost) <= tighten_margin*d for `meet_time_threshold` consecutive steps),
    so a just-tightened d is still comfortably feasible and lambda gets a genuine zero-violation
    region to decay in. Lower is better for cost, so "achieved" == at/below.

    Relax: if EMA(cost) > d continuously for `relax_steps`, the policy genuinely cannot
    meet the budget -- relax d up to EMA*relax_headroom (never above baseline*relax_cap_mult). Without
    this escape hatch a d that ratcheted below the achievable cost was permanent and lambda
    integrated to its max forever. NOTE: both halves of this hatch were dead in the
    per-metre runs -- `relax_steps` was longer than an entire run's actor-step budget, and the cap was
    the baseline itself, which was the very number that had been mis-measured. Keep `relax_steps` well
    under one run's actor steps and keep `relax_cap_mult` > 1. Between tighten_margin*d and d is a dead band: neither counter
    advances, d holds, lambda sees ~zero violation.
    """
    def __init__(self,
                 floor_frac: float = 0.05,
                 abs_backstop: float = 1e-4,
                 warmup_steps: int = 500,
                 warmup_limit: float = 1e6,
                 decay_factor: float = 0.99,
                 tighten_margin: float = 0.95,
                 relax_steps: int = 20000,
                 relax_headroom: float = 1.05,
                 relax_step_frac: float = 0.5,
                 relax_cap_mult: float = 2.0,
                 smoothing_factor: float = 0.999,
                 meet_time_threshold: int = 10000,
                 tighten_lambda_max: float = float('inf')):
        # Floor is set RELATIVE to the measured baseline at the end of warmup (units are now
        # per-step cost and may change to TTC, so no meaningful absolute floor up front).
        self.floor_frac = floor_frac
        self.abs_backstop = abs_backstop
        self.min_cost_limit = abs_backstop     # provisional; re-seeded to baseline*floor_frac after warmup
        self.warmup_steps = warmup_steps
        self.warmup_limit = warmup_limit
        self.decay_factor = decay_factor
        self.tighten_margin = tighten_margin
        self.relax_steps = relax_steps
        self.relax_headroom = relax_headroom
        self.relax_step_frac = relax_step_frac
        self.relax_cap_mult = relax_cap_mult
        self.smoothing_factor = smoothing_factor
        self.meet_time_threshold = meet_time_threshold
        self.tighten_lambda_max = tighten_lambda_max

        self.initialized = False          # True once warmup has measured the baseline and seeded d
        self.warmup_count = 0
        self.warmup_cost_sum = 0.0
        self.warmup_cost_sqsum = 0.0     # for the warmup std used to seed d
        self.baseline = None              # measured warmup cost; relax is capped at baseline*relax_cap_mult
        self.floor_basis = None           # the d0 the floor was seeded from (persisted; see load_state_dict)
        self.cost_limit = warmup_limit    # what get_target() returns during warmup (effectively no constraint)

        self.ema_cost = 0.0
        self._is_first_step = True
        self.meet_time = 0
        self.violate_time = 0

    def step(self, current_cost: float, lam: float = None):
        # --- Phase 1: warmup / baseline measurement (constraint held slack) ---
        if not self.initialized:
            self.warmup_count += 1
            self.warmup_cost_sum += current_cost
            self.warmup_cost_sqsum += current_cost * current_cost
            if self.warmup_count >= self.warmup_steps:
                n = max(self.warmup_count, 1)
                measured = self.warmup_cost_sum / n
                var = max(self.warmup_cost_sqsum / n - measured * measured, 0.0)
                std = math.sqrt(var)
                # The budget is the empirical average cost of the imitation policy, less
                # COST_LIMIT_STD_MULT standard deviations: it demands an improvement over what the
                # initialization already achieves while staying within reach of it.
                self.cost_limit = max(measured - COST_LIMIT_STD_MULT * std, self.abs_backstop)
                # Seed the floor relative to the budget just set (unit-agnostic). Remember the
                # basis so a resume re-derives the same floor: d0 < baseline once the 2-sigma
                # offset applies, so re-deriving from `baseline` would raise the floor, and with
                # it the budget, on every restart.
                self.floor_basis = self.cost_limit
                self.min_cost_limit = max(self.cost_limit * self.floor_frac, self.abs_backstop)
                self.cost_limit = max(self.cost_limit, self.min_cost_limit)
                self.baseline = max(measured, self.min_cost_limit)
                self.ema_cost = measured
                self._is_first_step = False
                self.initialized = True
                print(f"📉 [CostLimitScheduler] Warmup done: baseline online cost={measured:.6f} "
                      f"(std={std:.6f}) -> d0=mean-{COST_LIMIT_STD_MULT:g}std={self.cost_limit:.6f}, "
                      f"floor={self.min_cost_limit:.6f} (={self.floor_frac:.2f}x d0)")
            return

        # --- Phase 2: achievement-gated descent toward the floor, relax on persistent violation ---
        # (EMA keeps updating even at the floor: a floored-but-infeasible d must still be relaxable.)
        if self._is_first_step:
            self.ema_cost = current_cost
            self._is_first_step = False
        else:
            self.ema_cost = (self.smoothing_factor * self.ema_cost +
                             (1 - self.smoothing_factor) * current_cost)

        if self.ema_cost <= self.cost_limit * self.tighten_margin:
            # Met WITH margin: after a x decay_factor tighten, EMA <= margin*d < decay*d keeps the
            # new budget feasible, so lambda always has a real zero-violation region to decay in.
            self.violate_time = 0
            self.meet_time += 1
            lam_quiet = (lam is None) or (lam < self.tighten_lambda_max)
            if self.meet_time >= self.meet_time_threshold and lam_quiet:
                self.meet_time = 0
                if self.cost_limit > self.min_cost_limit:
                    self.cost_limit = max(self.cost_limit * self.decay_factor, self.min_cost_limit)
        elif self.ema_cost > self.cost_limit:
            # After relax_steps of continuous violation, relax d toward EMA*headroom (capped).
            self.meet_time = 0
            self.violate_time += 1
            if self.violate_time >= self.relax_steps:
                self.violate_time = 0
                cap = (self.baseline * self.relax_cap_mult
                       if self.baseline is not None else self.warmup_limit)
                full_target = min(self.ema_cost * self.relax_headroom, cap)
                relaxed = self.cost_limit + self.relax_step_frac * (full_target - self.cost_limit)
                if relaxed > self.cost_limit:
                    print(f"📈 [CostLimitScheduler] Persistent violation (EMA {self.ema_cost:.6f} > "
                          f"d {self.cost_limit:.6f} for {self.relax_steps} steps): relaxing d -> "
                          f"{relaxed:.6f} ({self.relax_step_frac:.0%} step toward {full_target:.6f}, "
                          f"cap {cap:.6f})")
                    self.cost_limit = relaxed
        else:
            # Dead band (margin*d, d]: met but without margin -- hold d, reset both patiences.
            self.meet_time = 0
            self.violate_time = 0

    def get_target(self) -> float:
        return self.cost_limit

    def state_dict(self) -> dict:
        return {
            'initialized': self.initialized,
            'warmup_count': self.warmup_count,
            'warmup_cost_sum': self.warmup_cost_sum,
            'warmup_cost_sqsum': self.warmup_cost_sqsum,
            'floor_basis': self.floor_basis,
            'min_cost_limit': self.min_cost_limit,
            'baseline': self.baseline,
            'cost_limit': self.cost_limit,
            'ema_cost': self.ema_cost,
            '_is_first_step': self._is_first_step,
            'meet_time': self.meet_time,
            'violate_time': self.violate_time,
        }

    def load_state_dict(self, state_dict: dict):
        self.initialized = state_dict['initialized']
        self.warmup_count = state_dict['warmup_count']
        self.warmup_cost_sum = state_dict['warmup_cost_sum']
        self.warmup_cost_sqsum = state_dict.get('warmup_cost_sqsum', 0.0)
        self.min_cost_limit = state_dict['min_cost_limit']
        self.cost_limit = state_dict['cost_limit']
        self.ema_cost = state_dict['ema_cost']
        self._is_first_step = state_dict['_is_first_step']
        self.meet_time = state_dict['meet_time']
        # Reconstruct the baseline from the floor relation min = baseline*floor_frac when the
        # checkpoint does not store it; start the violation patience fresh.
        self.violate_time = state_dict.get('violate_time', 0)
        self.baseline = state_dict.get('baseline', None)
        if self.baseline is None and self.initialized and self.floor_frac > 0:
            self.baseline = self.min_cost_limit / self.floor_frac
            print(f"📈 [CostLimitScheduler] Checkpoint without a baseline: reconstructed "
                  f"baseline={self.baseline:.6f} from floor {self.min_cost_limit:.6f} / "
                  f"floor_frac {self.floor_frac:.2f}")

        # Re-derive the floor from the basis it was seeded from, so a changed floor_frac takes
        # effect without the budget drifting upward on every resume.
        self.floor_basis = state_dict.get('floor_basis', None)
        basis = self.floor_basis if self.floor_basis is not None else self.baseline
        if self.initialized and basis is not None and self.floor_frac > 0:
            new_floor = max(basis * self.floor_frac, self.abs_backstop)
            if abs(new_floor - self.min_cost_limit) > 1e-12:
                print(f"🔧 [CostLimitScheduler] Floor re-derived from current floor_frac "
                      f"{self.floor_frac:.2f} x baseline {self.baseline:.6f}: "
                      f"{self.min_cost_limit:.6f} -> {new_floor:.6f}")
            self.min_cost_limit = new_floor
            self.cost_limit = max(self.cost_limit, self.min_cost_limit)



class RunningMeanStd:
    """Calculates a running mean and standard deviation for online normalization."""
    def __init__(self, shape=()):
        self.mean = np.zeros(shape, 'float64')
        self.var = np.ones(shape, 'float64')
        self.count = 1e-4

    def update(self, x):
        batch_mean = np.mean(x, axis=0)
        batch_var = np.var(x, axis=0)
        batch_count = x.shape[0]
        self.update_from_moments(batch_mean, batch_var, batch_count)

    def update_from_moments(self, batch_mean, batch_var, batch_count):
        delta = batch_mean - self.mean
        tot_count = self.count + batch_count
        new_mean = self.mean + delta * batch_count / tot_count
        m_a = self.var * self.count
        m_b = batch_var * batch_count
        M2 = m_a + m_b + np.square(delta) * self.count * batch_count / tot_count
        new_var = M2 / tot_count
        self.mean = new_mean
        self.var = new_var
        self.count = tot_count


class GpuRunningMeanStd:
    """Calculates a running mean and standard deviation for online normalization on the GPU."""
    def __init__(self, shape=(), device='cuda'):
        self.mean = torch.zeros(shape, dtype=torch.float64, device=device)
        self.var = torch.ones(shape, dtype=torch.float64, device=device)
        self.count = torch.tensor(1e-4, dtype=torch.float64, device=device)
        self.device = device

    def update(self, x: torch.Tensor):
        """Update the running statistics with a new batch of data."""
        # x is expected to be a tensor on self.device
        batch_mean = x.mean(dim=0).to(torch.float64)
        batch_var = x.var(dim=0, unbiased=False).to(torch.float64)
        batch_count = torch.tensor(x.shape[0], dtype=torch.float64, device=self.device)
        self.update_from_moments(batch_mean, batch_var, batch_count)

    def update_from_moments(self, batch_mean: torch.Tensor, batch_var: torch.Tensor, batch_count: torch.Tensor):
        """Update the running statistics from pre-computed moments."""
        delta = batch_mean - self.mean
        tot_count = self.count + batch_count
        
        new_mean = self.mean + delta * batch_count / tot_count
        
        m_a = self.var * self.count
        m_b = batch_var * batch_count
        M2 = m_a + m_b + torch.square(delta) * self.count * batch_count / tot_count
        
        new_var = M2 / tot_count
        
        self.mean = new_mean
        self.var = new_var
        self.count = tot_count

def _install_compiled_dist_params(module, tag):
    """Install a compiled `get_dist_params` as an INSTANCE attribute on a Greg module (see
    ACTOR_COMPILE). Every actor entry point -- sample / get_dist / get_actionrl / log_prob /
    entropy -- resolves `self.get_dist_params` through the instance dict first, so all of them
    pick this up with no change to their signatures or to model.py.

    Deliberately NOT a module wrapper: `module` stays the plain Greg, so state_dict() keys are
    unchanged and policy_trainable_state_dict / save_policy / save_checkpoint keep writing exactly
    the same tensors (the compiled callable is a bound method, never parameter state).
    `dynamic` is left on auto so the route=None / belief=None / batch-size variants specialize
    without tripping the recompile limit. First failure -> permanent eager for the rest of the run."""
    if not ACTOR_COMPILE:
        return
    eager = type(module).get_dist_params.__get__(module)
    compiled = torch.compile(eager)
    state = {'ok': True}

    def get_dist_params(*args, **kwargs):
        if state['ok']:
            try:
                return compiled(*args, **kwargs)
            except Exception as e:
                print(f"⚠️ [Actor] compiled get_dist_params ({tag}) failed "
                      f"({type(e).__name__}: {e}); falling back to eager for the rest of the run.")
                state['ok'] = False
        return eager(*args, **kwargs)

    module.get_dist_params = get_dist_params
    print(f"⚡ [Actor] compiled get_dist_params for the {tag}.")


class SACAgent:
    def __init__(self, state_dim, action_dim, run_wandb):
        torch._functorch.config.donated_buffer = False
        self.device = "cuda"; self.gamma = 0.99; self.tau = 0.005
        self.popArt = False

        self.use_action_queue = USE_ACTION_QUEUE

        self.target_kl_steer_initial = 0.08
        self.target_kl_accel_initial = 0.20   # nats


        self.target_kl_steer = self.target_kl_steer_initial
        self.target_kl_accel = self.target_kl_accel_initial

        self.target_kl_steer_final = 0.12     # final KL-anchor target for steer
        self.target_kl_accel_final = 0.80     # final KL-anchor target for accel (nats)
        self.kl_target_ramp_steps = 1000000   # ramp horizon for the KL target (decoupled from the 1M LR horizon)

        self.acc_vals = torch.tensor([-1.0, 0.0, 0.3, 0.7, 1.0, -0.5], device=self.device)

        self.step_to_target_num = 1000000
        self.step_to_target_cosine_num = self.step_to_target_num


        self.target_entropy_steer_initial = -1#-1.2##
        self.target_entropy_steer_final = -1.4
        self.target_entropy_steer = self.target_entropy_steer_initial
        self.entropy_steer_scheduler = AdaptiveEntropyScheduler(
            initial_target_entropy=self.target_entropy_steer_initial,
            decay_factor=0.9975,
            stability_threshold=0.01,
            smoothing_factor=0.999,
            meet_time_threshold=1000,
            min_target_entropy=self.target_entropy_steer_final
        )

        self.target_entropy_accel_initial = 0.75#0.3*np.log(NUM_DISCRETE_ACTIONS)#0.8*np.log(NUM_DISCRETE_ACTIONS)#0.95*np.log(NUM_DISCRETE_ACTIONS) # Max entropy ratio
        epsilon = 0.05
        self.target_entropy_accel_final = 0.575#0.3*np.log(NUM_DISCRETE_ACTIONS)#0.6#0.55*np.log(NUM_DISCRETE_ACTIONS)#0-((1 - epsilon) * np.log(1 - epsilon) + epsilon * np.log(epsilon / (NUM_DISCRETE_ACTIONS - 1))) # Shannon entropy of an ε-greedy policy
        self.target_entropy_accel = self.target_entropy_accel_initial
        self.entropy_accel_scheduler = AdaptiveEntropyScheduler(
            initial_target_entropy=self.target_entropy_accel_initial,
            decay_factor=0.9975,
            stability_threshold=0.01,
            smoothing_factor=0.999,
            meet_time_threshold=1000,
            min_target_entropy=self.target_entropy_accel_final
        )
        
        # TD3-style target-action smoothing.
        self.target_policy_noise_std = 0.03
        self.target_policy_noise_clip = 0.10

        self.critic_warm_up  = CRITIC_WARM_UP   # single source of truth; MVE_WARMUP_START derives from it
        self.plasticity_freq = 250000
        self.beta_sigma_critic = 0.05
        self.kappa_r = 40.0

        # --- TD3-Style Stability Parameters ---
        self.policy_delay_freq = 2  # Update actor/targets every N critic updates
        self.grad_policy_check_freq = 10000
        self.target_delay_freq = 2
        self.kl_delay_freq     = 10

        self.accumulation_steps = ACCUMULATION_STEPS


        self.num_criticis = NUM_CRITICS
        self.gpu_replay_buffer = GPU_REPLAY_BUFFER

        self.lcb_beta = 1.0
        self.ctr_qhat = None
        # Distance-head diagnostics (written in the cost-critic step, read by the actor's log block
        # which runs on a different cadence -- hence carried on self rather than passed through).
        self.last_dist_loss = 0.0
        self.last_qd_mean = 0.0

        self.cost_bias = 3.0

        self.hard_bellman_accel = False

        if not self.gpu_replay_buffer:
            self.state_normalizer      = RunningMeanStd(shape=(STATE_DIM))
            self.reward_normalizer     = RunningMeanStd(shape=(NUM_REWARD_TERM))
        else:
            self.state_normalizer      = GpuRunningMeanStd(shape=(STATE_DIM))
            self.reward_normalizer     = GpuRunningMeanStd(shape=(NUM_REWARD_TERM))

        self.state_dim = state_dim
        self.action_dim = action_dim
        self.batch_size = TRAINING_BATCH_SIZE

        self.update_count = 0

        # Privileged box-transformer config shared by the reward + cost critics (and their targets).
        box_critic_kwargs = dict(use_boxes=USE_BOX_CRITIC, box_attr_dim=BOX_ATTR_DIM,
                                 box_object_types=BOX_OBJECT_TYPES, box_n_embd=BOX_N_EMBD,
                                 box_n_layer=BOX_N_LAYER, box_n_head=BOX_N_HEAD, box_dropout=BOX_DROPOUT,
                                 box_grad_ckpt=BOX_GRAD_CKPT, build_encoder=False,  # E: encoder is SHARED/external
                                 route_dim=ROUTE_DIM if USE_ROUTE else 0)            # route scalars concat onto critic state

        # stationary input floor; it arrives detached (no_grad) so critic grads never reach the RSSM.
        critic_state_dim = state_dim + (RSSM_BELIEF_DIM if RSSM_ENABLED else 0)

        critic_net = Critic(critic_state_dim, action_dim, num_discrete_actions=NUM_DISCRETE_ACTIONS, num_critics=self.num_criticis, beta=0.999, popArt=self.popArt, **box_critic_kwargs).cuda()
        critic_target_net = Critic(critic_state_dim, action_dim, num_discrete_actions=NUM_DISCRETE_ACTIONS, num_critics=self.num_criticis, beta=0.999, popArt=self.popArt, **box_critic_kwargs).cuda()

        critic_target_net.load_state_dict(critic_net.state_dict())

        self.critic = torch.compile(critic_net, mode=CRITIC_COMPILE_MODE)
        self.critic_target = torch.compile(critic_target_net, mode=CRITIC_COMPILE_MODE)

        cost_critic_net = Critic(critic_state_dim, action_dim, num_discrete_actions=NUM_DISCRETE_ACTIONS, num_critics=self.num_criticis, beta=0.999, popArt=self.popArt, **box_critic_kwargs).cuda()
        cost_critic_target_net = Critic(critic_state_dim, action_dim, num_discrete_actions=NUM_DISCRETE_ACTIONS, num_critics=self.num_criticis, beta=0.999, popArt=self.popArt, **box_critic_kwargs).cuda()
        cost_critic_target_net.load_state_dict(cost_critic_net.state_dict())
        self.cost_critic = torch.compile(cost_critic_net, mode=CRITIC_COMPILE_MODE)
        self.cost_critic_target = torch.compile(cost_critic_target_net, mode=CRITIC_COMPILE_MODE)

        # --- Level-1 RSSM world model (trained ONLY by _update_rssm; SAC reads it under no_grad) ---
        if RSSM_ENABLED:
            self.rssm = RSSMBelief(embed_dim=RSSM_OBS_DIM, action_dim=ACTION_DIM,
                                   deter_dim=RSSM_DETER_DIM, stoch_groups=RSSM_STOCH_GROUPS,
                                   stoch_classes=RSSM_STOCH_CLASSES, hidden=RSSM_HIDDEN,
                                   unimix=RSSM_UNIMIX).to(self.device)
            self.rssm_optimizer = optim.Adam(self.rssm.parameters(), lr=RSSM_LR)
            self._safety_stream = (torch.cuda.Stream(device=self.device, priority=0)
                                   if SAFETY_MVE_ENABLED and SAFETY_MVE_ASYNC else None)
            self._safety_event = None
            self._safety_pending_refs = None
        else:
            self.rssm, self.rssm_optimizer = None, None
            self._safety_stream = self._safety_event = None
            self._safety_pending_refs = None
        # --- Random network distillation: intrinsic exploration bonus (Eq. 2) ---
        if RND_ENABLED:
            self.rnd = RNDModel(input_dim=STATE_DIM).to(self.device)
            # Only the predictor half trains; RNDModel zeroes the target's grads via a hook.
            self.rnd_optimizer = optim.Adam(self.rnd.parameters(), lr=RND_LR)
            self.rnd_normalizer = GpuRunningMeanStd(shape=(), device=self.device)
        else:
            self.rnd, self.rnd_optimizer, self.rnd_normalizer = None, None, None

        # Lazily-built compiled burn-in unroll: None = not built yet, False = eager (disabled or
        # a compile failure). Never checkpointed -- it is a wrapper around self.rssm, not state.
        self._burnin_compiled = None
        # Denoiser gate. update() reassigns this every step, but it MUST also be correct before the
        self._denoise_active = EMBED_DENOISE_ENABLED and (self.update_count > self.critic_warm_up)

        # head optimizers do NOT contain these params, so no double-step). A separate Polyak target encoder
        if USE_BOX_CRITIC:
            box_enc_kwargs = dict(state_dim=state_dim, num_attributes=BOX_ATTR_DIM, object_types=BOX_OBJECT_TYPES,
                                  n_embd=BOX_N_EMBD, n_layer=BOX_N_LAYER, n_head=BOX_N_HEAD, dropout=BOX_DROPOUT,
                                  grad_checkpoint=BOX_GRAD_CKPT)
            self.shared_box_encoder = BoxContextEncoder(**box_enc_kwargs).cuda()
            self.shared_box_encoder_target = BoxContextEncoder(**box_enc_kwargs).cuda()
            self.shared_box_encoder_target.load_state_dict(self.shared_box_encoder.state_dict())
            for p in self.shared_box_encoder_target.parameters():
                p.requires_grad_(False)
            self.box_encode = torch.compile(self.shared_box_encoder, mode=CRITIC_COMPILE_MODE)
            self.box_encode_target = torch.compile(self.shared_box_encoder_target, mode=CRITIC_COMPILE_MODE)
        else:
            self.shared_box_encoder = self.shared_box_encoder_target = None
            self.box_encode = self.box_encode_target = None

        self.run_wandb = run_wandb

        self.config = GlobalConfig()
        my_hf_token = os.environ.get("HF_TOKEN")

        # Load the ViT-Large model directly from Hugging Face
        pretrained_model_name = "facebook/dinov3-vitl16-pretrain-lvd1689m"
        custom_cache_path = "./dinov3_large_cache"
        config = AutoConfig.from_pretrained(
            pretrained_model_name,
            token=my_hf_token,
            cache_dir=custom_cache_path
        )

        # 2. Initialize the model with that config (no weights loaded)
        vit_base = AutoModel.from_config(config)
        net_Greg = Greg(self.config, vit_base_model=vit_base)


        if ORIGINAL:
            ckpt = torch.load(ORGINAL_TCP_CONFIG, map_location="cuda")
            ckpt = ckpt["state_dict"]
            new_state_dict = OrderedDict()

            for key, value in ckpt.items():
                # Chain the replacements to scrub BOTH prefixes
                new_key = key.replace("model.", "").replace("_orig_mod.", "")
                new_state_dict[new_key] = value

            # strict=False so the zero-init route_adapter (absent from the IL ckpt) keeps its no-op init
            # and the model drives identically to IL until the adapter trains.
            net_Greg.load_state_dict(new_state_dict, strict=False)
        else:
            ckpt = torch.load(ORGINAL_TCP_CONFIG, map_location="cuda")
            net_Greg.load_state_dict(ckpt['policy_net_state_dict'], strict=False)



        self.net = torch.compile(net_Greg)
        self.net.cuda()
        self.net.eval()
        policy_net  = copy.deepcopy(net_Greg)
        self.policy_net = torch.compile(policy_net)

        # Compile the actor trunk that sample()/get_dist()/log_prob()/entropy() actually run
        # (see ACTOR_COMPILE). net_Greg is the frozen IL prior (KL anchor), policy_net the RL actor.
        _install_compiled_dist_params(net_Greg, "IL prior")
        _install_compiled_dist_params(policy_net, "RL actor")

        for param in self.policy_net.parameters():
            param.requires_grad = False


        rl_policy_engine_params = self.policy_net.rl_policy_engine.parameters()
        steer_mu_params     = self.policy_net.steer_mu.parameters()
        steer_sigma_params  = self.policy_net.steer_sigma.parameters()
        accel_logits_params = self.policy_net.accel_logits.parameters()
        route_adapter_params = self.policy_net.route_adapter.parameters()  # zero-init route adapter (trains the route path)
        policy_adapter_params = self.policy_net.policy_adapters.parameters()  # zero-init per-layer trunk adapters ( capacity bump)
        belief_proj_params = self.policy_net.belief_proj.parameters()  # zero-init RSSM belief read-in (trained by the actor loss only)

        trainable_params = chain(
            rl_policy_engine_params,
            steer_mu_params, steer_sigma_params, accel_logits_params,
            route_adapter_params,
            policy_adapter_params,
            belief_proj_params,
        )

        trainable_params_list = []
        for p in trainable_params:
            p.requires_grad = True
            trainable_params_list.append(p)

        self.policy_optimizer = optim.AdamW(trainable_params_list, lr=3e-4, weight_decay=1e-3)
        self.critic_optimizer = optim.AdamW(self.critic.parameters(), lr=3e-4, weight_decay=1e-3)  # critic LR


        actor_warmup_steps = 50000
        
        actor_warmup = torch.optim.lr_scheduler.LinearLR(
            self.policy_optimizer, start_factor=0.01, total_iters=actor_warmup_steps
        )
        
        actor_cosine = torch.optim.lr_scheduler.CosineAnnealingLR(
            self.policy_optimizer, T_max=int((self.step_to_target_cosine_num - actor_warmup_steps)/self.policy_delay_freq), eta_min=3e-5
        )
        
        self.actor_lr_scheduler = torch.optim.lr_scheduler.SequentialLR(
            self.policy_optimizer, schedulers=[actor_warmup, actor_cosine], milestones=[actor_warmup_steps]
        )

        self.critic_lr_scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            self.critic_optimizer, T_max=self.step_to_target_cosine_num, eta_min=3e-5
        )

        # --- CMDP: cost-critic optimizer + scheduler (mirror the reward critic) ---
        self.cost_critic_optimizer = optim.AdamW(self.cost_critic.parameters(), lr=3e-4, weight_decay=1e-3)
        self.cost_critic_lr_scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            self.cost_critic_optimizer, T_max=self.step_to_target_cosine_num, eta_min=3e-5
        )

        if EMBED_DENOISE_ENABLED:
            for p in self.policy_net.embed_denoiser.parameters():
                p.requires_grad_(True)
            self.denoiser_optimizer = optim.AdamW(self.policy_net.embed_denoiser.parameters(),
                                                  lr=DENOISER_LR, weight_decay=1e-3)
            self.denoiser_lr_scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
                self.denoiser_optimizer, T_max=self.step_to_target_cosine_num, eta_min=3e-5
            )
        else:
            self.denoiser_optimizer = None
            self.denoiser_lr_scheduler = None

        if USE_BOX_CRITIC:
            self.box_optimizer = optim.AdamW(self.shared_box_encoder.parameters(), lr=3e-4, weight_decay=1e-3)
            self.box_lr_scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
                self.box_optimizer, T_max=self.step_to_target_cosine_num, eta_min=3e-5
            )

        # --- CMDP: Lagrange multiplier (dual variable) tuned by dual ascent on the constraint ---
        self.gamma_cost = GAMMA_COST
        self.cost_limit_scheduler = CostLimitScheduler(
            floor_frac=COST_LIMIT_FLOOR_FRAC,
            abs_backstop=COST_LIMIT_ABS_BACKSTOP,
            warmup_steps=COST_LIMIT_WARMUP_STEPS,
            decay_factor=COST_LIMIT_DECAY_FACTOR,
            tighten_margin=COST_LIMIT_TIGHTEN_MARGIN,
            relax_steps=COST_LIMIT_RELAX_STEPS,
            relax_headroom=COST_LIMIT_RELAX_HEADROOM,
            relax_step_frac=COST_LIMIT_RELAX_STEP_FRAC,
            relax_cap_mult=COST_LIMIT_RELAX_CAP_MULT,
            meet_time_threshold=COST_LIMIT_MEET_STEPS,
            tighten_lambda_max=COST_LIMIT_TIGHTEN_LAMBDA_MAX,
        )
        self.cost_limit = self.cost_limit_scheduler.get_target()
        self.ucb_beta = UCB_BETA
        self.kappa_c = KAPPA_C

        self.log_lambda_online = torch.tensor([LOG_LAMBDA_INIT], requires_grad=True, device=self.device)
        self.lambda_online_optimizer = optim.SGD([self.log_lambda_online], lr=LAMBDA_LR)

        self._ema_cost_raw = 0.0
        self._ema_dist_raw = 0.0
        self._ema_bias = 0.0            # accumulated weight = 1 - decay**N; divides out the cold start
        self.online_cost_ema_decay = 1.0 - 1.0 / float(ONLINE_COST_EMA_WINDOW)
        self.online_cost_transitions = 0   # fresh transitions folded into the EMA so far
        self.online_cost_cumsum = 0.0   # Sum(cost) over fresh transitions
        self.online_dist_cumsum = 0.0   # Sum(max(speed,0)) over fresh transitions (forward distance)

        # Two independent SAC temperatures (steer + accel).
        self.log_alpha_steer = torch.tensor([-2.3], requires_grad=True, device=self.device)
        self.alpha_steer_optimizer = optim.Adam([self.log_alpha_steer], lr=1e-4)
        self.log_alpha_accel = torch.tensor([-1.5], requires_grad=True, device=self.device)
        self.alpha_accel_optimizer = optim.Adam([self.log_alpha_accel], lr=1e-4)

        self.log_kl_weight_steer = torch.tensor([0.0], requires_grad=True, device=self.device)
        self.kl_weight_steer_optimizer = optim.SGD([self.log_kl_weight_steer], lr=KL_WEIGHT_LR)
        self.log_kl_weight_accel = torch.tensor([0.0], requires_grad=True, device=self.device)
        self.kl_weight_accel_optimizer = optim.SGD([self.log_kl_weight_accel], lr=KL_WEIGHT_LR)

        # Initialize the GradScaler for mixed-precision training
        self.scaler = GradScaler(enabled=USE_AMP)
        self.load_checkpoint(SAC_CHECKPOINT_FILE)


    def inject_plasticity(self):
        """Shrinks weights, adds noise, and resets Adam momentum for the Critic heads."""
        print(f"⚡ [Plasticity Injection] Waking up Critic heads at step {self.update_count}!")
        shrink_factor = 0.5
        noise_std = 0.01

        # 1. Identify the layers we want to perturb (The independent branches, NOT the DINO trunk).
        #    Each critic head is paired with its own optimizer so we reset the right momentum state.
        target_pairs = [
            (self.critic._orig_mod.critic_net.q_quantile_head, self.critic_optimizer),
            (self.cost_critic._orig_mod.critic_net.q_quantile_head, self.cost_critic_optimizer),
        ]

        with torch.no_grad():
            for module, opt in target_pairs:
                # 2. Shrink and Perturb Weights
                module.weight.data.mul_(shrink_factor).add_(torch.randn_like(module.weight.data) * noise_std)
                module.bias.data.mul_(shrink_factor)

                # 3. Reset AdamW Momentum state for these specific parameters
                for p in module.parameters():
                    if p in opt.state:
                        # Reset the first and second moments (momentum and variance) to zero
                        opt.state[p]['exp_avg'].zero_()
                        opt.state[p]['exp_avg_sq'].zero_()

    def linear_interpolation(self, initial_value, final_value, total_steps, current_step):
        if current_step >= total_steps:
            return final_value
        if current_step < 0:
            return initial_value
        if total_steps <= 0:
            return initial_value
        step_size = (final_value - initial_value) / total_steps
        current_value = initial_value + step_size * current_step
        return current_value
    

    def get_unscaled_grad_norm(self, optimizer):
        """
        Calculates the L2 norm of gradients for a given optimizer's parameters
        by MANUALLY unscaling them using the scaler's current scale factor.
        This avoids calling scaler.unscale_(), which has state.
        """
        # --- DO NOT CALL self.scaler.unscale_(optimizer) ---
        
        current_scale = self.scaler.get_scale()
        
        # If scale is 0 or inf, it means an inf/nan was found and grads will be (or were) zeroed.
        if current_scale == 0.0 or not torch.isfinite(torch.tensor(current_scale)):
            return 0.0

        total_norm_sq = 0.0
        for group in optimizer.param_groups:
            for p in group['params']:
                if p.grad is not None:
                    # Manually unscale the gradient by dividing by the scale factor
                    try:
                        # Ensure we're working in float32 for the division and norm
                        unscaled_grad = p.grad.data.to(torch.float32) / current_scale
                        param_norm_sq = unscaled_grad.pow(2).sum()
                        
                        if torch.isfinite(param_norm_sq):
                            total_norm_sq += param_norm_sq.item()
                        else:
                            # This can happen if p.grad was inf even before unscaling
                            pass 
                    except RuntimeError as e:
                        print(f"Warning: Grad norm calculation error - {e}")
                        pass # Skip this param
        
        return total_norm_sq ** 0.5


    @property
    def alpha_steer(self):
        return self.log_alpha_steer.exp()
    
    @property
    def alpha_accel(self):
        return self.log_alpha_accel.exp()

    @property
    def lagrange_lambda(self):
        # Dual price on expected cost. log_lambda_online is clamped to [LOG_LAMBDA_MIN, LOG_LAMBDA_MAX].
        return self.log_lambda_online.exp()

    def update_online_cost_ema(self, batch_cost_rate: float, batch_dist_rate: float, n: int):
        """Fold a fresh batch into the DISTANCE-normalized online cost measure.

        Called from the replay buffer's add_batch on incoming (near-online) data. Maintains the
        numerator (cost) and denominator (max(speed,0)=FORWARD distance/dt) as separate
        count-weighted sums+EMAs; the safety signal that drives lambda + the budget scheduler is
        their ratio Sum(cost)/Sum(max(speed,0)) = collisions per meter of forward progress
        (speed-invariant, so it can't be gamed by crawling, and reverse-invariant, so it can't be
        gamed by backing up either -- see the FORWARD ONLY note at the call sites).
        `batch_cost_rate` = mean(cost) and `batch_dist_rate` = mean(max(speed,0)) over the batch.
        Structure-agnostic: works for a sparse terminal collision spike (mass added to the numerator
        once) or a dense TTC cost alike."""
        if n is None or n <= 0 or not np.isfinite(n):
            return
        crate = float(batch_cost_rate)
        drate = float(batch_dist_rate)
        if not (np.isfinite(crate) and np.isfinite(drate)):
            return                                     # never let a NaN batch poison the sensor
        n = int(n)
        self.online_cost_transitions += n
        self.online_cost_cumsum += crate * float(n)   # Sum(cost)   -> lag-free warmup baseline
        self.online_dist_cumsum += drate * float(n)   # Sum(|speed|) -> distance denominator
        decay = self.online_cost_ema_decay ** n   # weight retained on the running EMA over n transitions
        self._ema_cost_raw = decay * self._ema_cost_raw + (1.0 - decay) * crate
        self._ema_dist_raw = decay * self._ema_dist_raw + (1.0 - decay) * drate
        self._ema_bias = decay * self._ema_bias + (1.0 - decay)

    # --- bias-corrected sensor properties (setters keep every existing assignment site working) ---
    @property
    def online_cost_ema(self):
        """Bias-corrected per-step cost EMA: the dual's sensor and the budget scheduler's
        post-warmup signal. None until the first batch. Must agree with
        `online_cost_baseline_perstep` at seeding time."""
        if self._ema_bias <= 0.0:
            return None
        return self._ema_cost_raw / self._ema_bias

    @online_cost_ema.setter
    def online_cost_ema(self, value):
        # None -> cold reset. A number -> a checkpointed, already-debiased measurement: install it
        # as a converged EMA (bias 1.0) so a resume behaves exactly as before.
        if value is None:
            self._ema_cost_raw = 0.0
            self._ema_bias = 0.0
        else:
            self._ema_cost_raw = float(value)
            self._ema_bias = 1.0

    @property
    def online_dist_ema(self):
        """Bias-corrected EMA of per-step max(speed,0). Shares `_ema_bias` with the cost leg."""
        if self._ema_bias <= 0.0:
            return None
        return self._ema_dist_raw / self._ema_bias

    @online_dist_ema.setter
    def online_dist_ema(self, value):
        if value is None:
            self._ema_dist_raw = 0.0
            # bias is owned by the cost leg's setter; only clear it if that leg is also cold.
            if self._ema_cost_raw == 0.0:
                self._ema_bias = 0.0
        else:
            self._ema_dist_raw = float(value)
            self._ema_bias = max(self._ema_bias, 1.0)

    @property
    def online_cost_rate(self):
        """Live per-DISTANCE realized cost (collisions per meter of FORWARD progress) =
        EMA(cost)/EMA(max(speed,0)). Both EMAs share the same weighting AND the same bias term, so
        the correction cancels exactly in the ratio (verified to 0.0 in emulation) and this watch
        signal is bit-identical. Smoothed signal used for lambda +
        the descent curriculum. None until the first batch."""
        if self._ema_bias <= 0.0 or self._ema_dist_raw <= 0.0:
            return None
        return self._ema_cost_raw / max(self._ema_dist_raw, ONLINE_DIST_EPS)

    @property
    def online_cost_baseline_perstep(self):
        """Lag-free per-STEP mean cost = Sum(cost)/N over fresh transitions. This is what seeds the
        budget d at warmup, and it is in the SAME units as `online_cost_ema` (the dual's sensor) --
        seeding from a differently-scaled estimator is how d ended up 2.4x below anything the policy
        could achieve in the per-metre runs. The cumsums are reset at every process start (see
        _load_from_checkpoint) so this always measures the CURRENT policy, never a lifetime average
        carried across resumes."""
        if self.online_cost_transitions <= 0:
            return None
        return self.online_cost_cumsum / float(self.online_cost_transitions)

    @property
    def online_cost_rate_baseline(self):
        """WATCH SIGNAL ONLY. Lag-free per-distance rate =
        Sum(cost)/Sum(max(speed,0))."""
        if self.online_dist_cumsum <= 0.0:
            return None
        return self.online_cost_cumsum / max(self.online_dist_cumsum, ONLINE_DIST_EPS)

    @property
    def kl_weight_steer(self):
        return self.log_kl_weight_steer.exp().clamp(0.0,100)

    @property
    def kl_weight_accel(self):
        return self.log_kl_weight_accel.exp().clamp(0.0,100)

    def _index_to_one_hot(self, action_batch_numpy, num_discrete_actions):
        steer_actions = torch.from_numpy(action_batch_numpy[:, 0:1]).to(self.device)
        accel_indices = torch.from_numpy(action_batch_numpy[:, 1]).long().to(self.device)
        accel_one_hot = F.one_hot(accel_indices, num_classes=num_discrete_actions).float()
        return torch.cat([steer_actions, accel_one_hot], dim=1)

    def calculate_reward(self, reward_term, action):
        # decision frame by the agent -- they are NOT accumulated and must NOT be scaled.
        if DECIMATION_K > 1:
            reward_term = torch.cat([reward_term[:, :6] / DECIMATION_K, reward_term[:, 6:]], dim=1)
        normalized_reward = reward_term
        # Order: [r, Rdis, Rspeed, Rsteer, Rds, Rreverse, speed, collision, ttc, desired_speed, term_cause]
        Rdis = normalized_reward[:, 1]
        Rspeed = normalized_reward[:, 2]
        Rsteer = normalized_reward[:, 3]
        Rds = normalized_reward[:, 4]
        Rreverse = reward_term[:, 5]
        Collision = reward_term[:, 7]
        TTC = reward_term[:, 8]
        DesiredSpeed = reward_term[:, 9]   # normalized target speed (logging only)
        # distinguishes physical danger from rule violations from mere blockage
        if reward_term.shape[1] > 10:
            Cause = reward_term[:, 10].round()
        else:
            Cause = Collision  # 10-term reward vector: treat any terminal infraction as physical
        cause_physical = (Cause == 1.0).float()   # collision (veh/ped/static) or off-road
        cause_rule     = (Cause == 2.0).float()   # red-light / stop-sign running
        cause_blocked  = (Cause == 3.0).float()   # vehicle blocked / route deviation

        Rspeed = Rspeed * (1.0 - action[:, 6])
        Rsteer = 0.8 + 0.2*Rsteer
        Rds = Rds
        Rreverse = Rreverse

        epsilon = torch.tensor(1e-1).cuda()
        Rpenalty = -75.0*(Collision)
        # Rtime = -0.280   # constant per-step time cost; not part of Eq. 2
        # reward is the task signal; danger is handled separately by the cost channel
        Rtotal_reward =  ((Rdis)*(Rspeed)*(Rds))**(1/3)

        epsilon = torch.tensor(1e-2).cuda()
        # c = max(c_TTC, c_red, c_stop) of Eq. 3. The worker already supplies this as ONE unified
        # signal: UnifiedTTC.get_unified_ttc() takes the MINIMUM time-to-collision over actors, the
        # red light, the stop sign and map geometry, so the most severe hazard is already selected
        # and no further max over sources is needed here. It arrives in seconds (small = dangerous),
        # so the only step left is the monotone decreasing map onto a bounded cost.
        cost_ttc       = COST_TTC_WEIGHT * torch.clamp(1.0 - TTC / COST_TTC_HORIZON, min=0.0, max=1.0)
        cost_terminal  = (cause_physical + cause_rule + cause_blocked)*(-torch.log(epsilon))  # spike (~4.6)
        cost_lazy      = torch.zeros_like(Collision)                         # inert channel (logged as 0)
        # The terminal spike is kept as the floor for events that end the episode: the cost label
        # amplifies it by COST_TERMINAL_MASS at `done` (see c_eff), which the dense term does not
        # get, and KAPPA_C / COST_LABEL_MAX are calibrated on that spike.
        Rcost = cost_softplus = torch.maximum(cost_ttc, cost_terminal)
        log = {
            "Rdis": Rdis.mean().item(),
            "Rspeed": Rspeed.mean().item(),
            # Rsteer / Rreverse are diagnostics only; they do not enter Rtotal_reward.
            "UNUSED_Rsteer": Rsteer.mean().item(),
            "Rds": Rds.mean().item(),
            "UNUSED_Rreverse": Rreverse.mean().item(),
            "Rtotal_reward": Rtotal_reward.mean().item(), # Changed from Rtotal
            "Rtotal_scaled": (Rtotal_reward * 9.0).mean().item(),
            "Rcollision": Collision.sum(),
            "Rpenalty": Rpenalty.mean().item(),
            # termination-cause decomposition (fractions of the batch)
            "Cause/physical_frac": cause_physical.mean().item(),   # collision / off-road
            "Cause/rule_frac":     cause_rule.mean().item(),       # red light / stop sign
            "Cause/blocked_frac":  cause_blocked.mean().item(),    # blocked / route deviation
            "RTTC": TTC.mean().item(),
            "Rcost": Rcost.mean().item(),
            # cost decomposition (scaled by 0.6 to match what the cost critic is fed)
            "Cost/ttc_term":          (0.6 * cost_ttc).mean().item(),       # dense near-miss shaping
            "Cost/collision_term":    (0.6 * cost_terminal).mean().item(),  # rare hard terminal spike (all causes)
            "Cost/lazy_term":         (0.6 * cost_lazy).mean().item(),      # standstill/lazy penalty
            "Cost/collision_samp_frac": Collision.float().mean().item(),    # frac of batch that are collision steps
            # share of cost mass from terminals; if ~0, lambda is driven by TTC/lazy, not failures
            "Cost/collision_mass_frac": (cost_terminal.sum() /
                                         (cost_ttc.sum() + cost_terminal.sum() + 1e-6)).item(),
            "DesiredSpeed_norm": DesiredSpeed.mean().item(),       # normalized (raw m/s / 12)
            "DesiredSpeed_mps": (DesiredSpeed.mean().item()) * 12.0,  # back in m/s for readability
        }
        
        Rtotal_reward = Rtotal_reward.unsqueeze(-1)
        Rtotal_reward *=9.0
        # No terminal penalty is applied here. Eq. 2's reward is the task signal only; collisions and
        # rule infractions enter exclusively through the cost channel (cost_terminal below), which is
        # what the constrained formulation is for.
        Rcost = Rcost.unsqueeze(-1) 
        Rcost *= 0.6

        
        return Rtotal_reward, Rcost, log

    def _den_state(self, s):
        """Critic-input state: the critic-trained denoiser output once active, else the RAW embedding.
        Returns raw while inactive (denoiser disabled OR still in critic warmup) so no gradient reaches
        the denoiser and the critic input matches the IL warm-start exactly. When active, grad flows
        into embed_denoiser through the critic's backward -- unless this is called under no_grad (the
        Bellman targets) or on a detached input (the actor's critic evaluation)."""
        if not getattr(self, '_denoise_active', False):
            return s
        return self.policy_net.embed_denoiser(s)

    # ---------------- Level-1 RSSM helpers ----------------
    def _rssm_obs(self, state, route):
        """The RSSM's observation e_t = [frozen 512-d embedding, 10-d route scalars] (522-d).
        Route may be absent (older data / route-less buffers) -> zero-padded, matching the
        route adapter's own missing-route fallback."""
        if route is None:
            route = torch.zeros(state.shape[0], ROUTE_DIM, device=state.device, dtype=state.dtype)
        return torch.cat([state, route.to(state.dtype)], dim=-1)

    def _burnin_unroll(self, e_hist, a_hist, mask):
        """The burn-in filter itself, optionally compiled (see RSSM_BURNIN_COMPILE).

        Compilation is LAZY and self-healing: inductor errors surface on the first call, not at
        torch.compile() time, so the first failure permanently reverts to eager. There is no
        cudagraph here (plain inductor), so this cannot hit the prefetch-thread RNG race that
        forced CRITIC_COMPILE_MODE back to None -- and burn_in takes the mode-z path, which has
        no RNG at all."""
        if RSSM_BURNIN_COMPILE and self._burnin_compiled is not False:
            if self._burnin_compiled is None:
                self._burnin_compiled = torch.compile(self.rssm.burn_in, dynamic=False)
            try:
                return self._burnin_compiled(e_hist, a_hist, mask)
            except Exception as e:
                print(f"⚠️ [RSSM] compiled burn-in failed ({type(e).__name__}: {e}); "
                      f"falling back to eager for the rest of the run.")
                self._burnin_compiled = False
        return self.rssm.burn_in(e_hist, a_hist, mask)

    def _burnin_unroll_safety(self, e_hist, a_hist, mask):
        """Dedicated eager burn-in for the B<=SAFETY_MVE_ROWS cache-refresh path.

        Do not route this through `_burnin_compiled`: that callable is fixed-shape-specialized for
        the ordinary merged 2*TRAINING_BATCH_SIZE SAC burn-in. Alternating it with the B=64 safety
        shape caused repeated 3–12 s inductor specialization stalls on RTX 3090. A read-only
        current-checkpoint/replay profile measured the eager safety path at 203.0 ms/update overall
        versus 204.7 ms for a separate dynamic compiled callable, with no stalls in 32 measured
        actor-on updates. This changes execution only; `RSSMBelief.burn_in` and all inputs/outputs
        are exactly the same. Keep the large ordinary SAC path compiled via `_burnin_unroll`.
        """
        return self.rssm.burn_in(e_hist, a_hist, mask)

    def _burnin_h(self, window, mask, batch):
        """h for the query frame, unrolled from zeros over its stored (K-1)-frame history.
        `window` is (B, L, [embedding, route, executed action]) fp16, oldest first. Missing window
        (burn-in disabled / legacy buffer) falls back to h=0 -- the old zero-h belief."""
        if window is None or window.shape[1] == 0:
            return self.rssm.initial(batch, self.device)
        w = window.float()
        return self._burnin_unroll(w[:, :, :RSSM_OBS_DIM], w[:, :, RSSM_OBS_DIM:], mask.float())

    def _burnin_h_pair(self, win_c, mask_c, win_n, mask_n, batch):
        """h for BOTH query frames (s_t and the n-step landing state) in ONE batched unroll.

        The filter is sequential in TIME but fully independent across ROWS, so the two windows are
        just 2*B rows of the same K-1 step recurrence: one loop of 15 steps at B=2048 instead of
        two loops of 15 at B=1024. Identical math (up to GEMM reassociation), and it halves the
        sequential-launch overhead that dominates this loop at K=16.

        Measured on the 3090 at K=16, B=1024, TF32 on (GREG_RL_Trainer/scratchpad_burnin_bench4.py):
          two separate unrolls (old)  19.9 ms | merged 11.4 ms | merged + torch.compile 6.7 ms
        i.e. the K=4 -> 16 widening cost ~15.8 ms/update and this gives back ~13 of it."""
        if win_c is None or win_c.shape[1] == 0:
            h0 = self.rssm.initial(batch, self.device)
            return h0, h0.clone()
        w = torch.cat([win_c, win_n], dim=0).float()
        m = torch.cat([mask_c, mask_n], dim=0).float()
        h = self._burnin_unroll(w[:, :, :RSSM_OBS_DIM], w[:, :, RSSM_OBS_DIM:], m)
        return h[:batch], h[batch:]

    def _critic_in(self, s, belief, detach=False):
        """Full critic input: [denoised 512-d embedding, 512-d belief]. The belief arrives
        DETACHED (computed under no_grad) so critic gradients never reach the RSSM; the frozen
        embedding half keeps the stationary floor the epistemic/UPER machinery was validated on.
        detach=True additionally stops the denoiser gradient (the actor's critic evaluations)."""
        z = self._den_state(s)
        if detach:
            z = z.detach()
        return torch.cat([z, belief], dim=-1) if belief is not None else z

    def _select_target_subset(self, Z_all_unnorm, mode):
        """Clipped double-Q selection over a random NUM_TARGET_CRITICS subset — the exact recipe
        of the real target path ('min' reward side, 'max' cost side). Input (C, B, N) unnormalized
        quantiles, returns (B, N)."""
        idx = np.random.choice(NUM_CRITICS, NUM_TARGET_CRITICS, replace=False)
        subset = Z_all_unnorm[idx]
        means = subset.mean(dim=-1)
        sel = (torch.argmin if mode == 'min' else torch.argmax)(means, dim=0, keepdim=True)
        sel = sel.unsqueeze(-1).expand(-1, subset.shape[1], subset.shape[2])
        return torch.gather(subset, 0, sel).squeeze(0)

    def _update_rssm(self, seq_buffer):
        """One world-model step on RSSM_SEQ_BATCH episode-contiguous chunks: unroll the filter
        with h0=0, train decoder (feature recon) + symlog reward + Bernoulli cost/done heads +
        balanced free-bits KL. Padded steps are masked out of every loss. This is the ONLY place
        the RSSM trains — the SAC losses never reach it."""
        batch = seq_buffer.sample(RSSM_SEQ_BATCH)
        if batch is None:
            return {}
        emb, act, rew, cost, done, mask = batch          # (B,L,522) (B,L,7) (B,L) x4
        B, L = emb.shape[0], emb.shape[1]
        h = self.rssm.initial(B, self.device)
        feats, kl_dyn, kl_rep = [], [], []
        for t in range(L):
            prior_lp = self.rssm.prior_logits(h)
            post_lp = self.rssm.post_logits(h, emb[:, t])
            z = self.rssm.sample_z(post_lp)
            feats.append(torch.cat([h, z], dim=-1))
            kl_dyn.append(self.rssm.kl_cat(post_lp.detach(), prior_lp))
            kl_rep.append(self.rssm.kl_cat(post_lp, prior_lp.detach()))
            h = self.rssm.step(h, z, act[:, t])          # EXECUTED action [steer, onehot6]
        feats = torch.stack(feats, dim=1)                # (B,L,belief_dim)
        m = mask
        msum = m.sum().clamp(min=1.0)

        recon = self.rssm.decoder(feats)
        loss_recon = (((recon - emb).pow(2).mean(dim=-1)) * m).sum() / msum
        head_in = torch.cat([feats, act], dim=-1)
        r_pred = self.rssm.reward_head(head_in).squeeze(-1)
        loss_rew = ((r_pred - symlog(rew)).pow(2) * m).sum() / msum
        c_logit = self.rssm.cost_head(head_in).squeeze(-1)
        c_tgt = (cost > 0).float()
        pw = torch.tensor(RSSM_COST_POS_WEIGHT, device=self.device)
        loss_cost = (F.binary_cross_entropy_with_logits(c_logit, c_tgt, pos_weight=pw,
                                                        reduction='none') * m).sum() / msum
        d_logit = self.rssm.done_head(head_in).squeeze(-1)
        loss_done = (F.binary_cross_entropy_with_logits(d_logit, done,
                                                        reduction='none') * m).sum() / msum
        safety_logits = self.rssm.safety_horizon_head(head_in)
        safety_terms, safety_masks = [], []
        c_evt = (cost > 0).float()
        for hi, horizon in enumerate(RSSM_OVERSHOOT_DISTANCES):
            tgt = torch.zeros_like(c_evt)
            valid = torch.zeros_like(m)
            for t in range(L):
                end = min(t + horizon, L)
                tgt[:, t] = c_evt[:, t:end].amax(dim=1)
                fully_observed = m[:, end - 1] if (t + horizon) <= L else torch.zeros_like(m[:, t])
                valid[:, t] = m[:, t] * torch.maximum(fully_observed, tgt[:, t])
            safety_terms.append(F.binary_cross_entropy_with_logits(
                safety_logits[:, :, hi], tgt, pos_weight=pw, reduction='none'))
            safety_masks.append(valid)
        safety_num = sum((loss_h * mask_h).sum() for loss_h, mask_h in
                         zip(safety_terms, safety_masks))
        safety_den = sum(mask_h.sum() for mask_h in safety_masks).clamp(min=1.0)
        loss_safety_aux = safety_num / safety_den
        # balanced KL with free bits, per (sample, step) BEFORE the masked mean (DreamerV3)
        kl_dyn_raw = torch.stack(kl_dyn, dim=1)
        kl_rep_raw = torch.stack(kl_rep, dim=1)
        loss_kl = (RSSM_KL_DYN_SCALE * (kl_dyn_raw.clamp(min=RSSM_KL_FREE_NATS) * m).sum() +
                   RSSM_KL_REP_SCALE * (kl_rep_raw.clamp(min=RSSM_KL_FREE_NATS) * m).sum()) / msum

        # One terminal-aligned H64 event window supplies one anchor and every overshooting
        # distance. This explicitly trains the prior mode used by MVE without O(L^2) anchors.
        loss_overshoot = torch.zeros((), device=self.device)
        if RSSM_OVERSHOOT_ENABLED:
            ev = seq_buffer.sample_event(min(16, RSSM_SEQ_BATCH))
            if ev is not None:
                ee, ea, _, ec, _, em = ev
                valid_rows = em[:, 31] * em[:, 63]
                keep = valid_rows > 0.5
                if keep.any():
                    ee, ea, ec = ee[keep], ea[keep], ec[keep]
                    Be = ee.shape[0]
                    he = self.rssm.initial(Be, self.device)
                    event_posts, event_feats = [], []
                    for t in range(RSSM_EVENT_SEQ_LEN):
                        lp = self.rssm.post_logits(he, ee[:, t])
                        ze = self.rssm.sample_z(lp)
                        event_posts.append(lp)
                        event_feats.append(torch.cat([he, ze], dim=-1))
                        he = self.rssm.step(he, ze, ea[:, t])
                    start = 31
                    belief_o = event_feats[start]
                    ho, zo = belief_o[:, :RSSM_DETER_DIM], belief_o[:, RSSM_DETER_DIM:]
                    over_terms = []
                    for dist in range(1, max(RSSM_OVERSHOOT_DISTANCES) + 1):
                        ho = self.rssm.step(ho, zo, ea[:, start + dist - 1])
                        prior_o = self.rssm.prior_logits(ho)
                        zo = self.rssm.sample_z(prior_o)
                        if dist in RSSM_OVERSHOOT_DISTANCES:
                            future = start + dist
                            target_lp = event_posts[future].detach()
                            belief_p = torch.cat([ho, zo], dim=-1)
                            over_terms.append(self.rssm.kl_cat(target_lp, prior_o).mean())
                            over_terms.append((self.rssm.decoder(belief_p) -
                                               ee[:, future]).pow(2).mean())
                            # Head supervision at the overshot (prior) latent.
                            head_o = torch.cat([belief_p, ea[:, future]], dim=-1)
                            over_terms.append(F.binary_cross_entropy_with_logits(
                                self.rssm.cost_head(head_o).squeeze(-1),
                                (ec[:, future] > 0).float(), pos_weight=pw))
                    if over_terms:
                        loss_overshoot = torch.stack(over_terms).mean()

        loss = (loss_recon + loss_rew + loss_cost + loss_done + loss_kl +
                RSSM_SAFETY_AUX_WEIGHT * loss_safety_aux +
                RSSM_OVERSHOOT_WEIGHT * loss_overshoot)
        self.rssm_optimizer.zero_grad(set_to_none=True)
        loss.backward()
        gn = float(nn.utils.clip_grad_norm_(self.rssm.parameters(), RSSM_GRAD_CLIP))
        self.rssm_optimizer.step()

        with torch.no_grad():
            # health probes: cost-head separation (pred prob on cost steps vs clean steps) + raw KL
            c_prob = torch.sigmoid(c_logit)
            pos = (c_tgt * m).sum()
            cost_sep = ((c_prob * c_tgt * m).sum() / pos.clamp(min=1.0)
                        - (c_prob * (1 - c_tgt) * m).sum() / (m.sum() - pos).clamp(min=1.0))
        return {'RSSM/loss': loss.item(), 'RSSM/recon': loss_recon.item(),
                'RSSM/reward': loss_rew.item(), 'RSSM/cost': loss_cost.item(),
                'RSSM/done': loss_done.item(), 'RSSM/kl': loss_kl.item(),
                'RSSM/safety_aux': loss_safety_aux.item(),
                'RSSM/overshoot': loss_overshoot.item(),
                'RSSM/kl_dyn_raw': (kl_dyn_raw * m).sum().item() / msum.item(),
                'RSSM/grad_norm': gn, 'RSSM/cost_head_sep': cost_sep.item(),
                'RSSM/chunks': seq_buffer.count, 'RSSM/cost_chunks': seq_buffer.c_count,
                'RSSM/batch_cost_frac': (pos / msum).item()}

    # -------- Level-2 MVE: model-based value expansion of the critic targets --------
    def _mve_weight(self):
        t = self.update_count - MVE_WARMUP_START
        if t <= 0:
            return 0.0
        w = MVE_WEIGHT * min(1.0, t / float(MVE_WARMUP_STEPS))
        # backstop for a missing/corrupt/shape-changed ring file and for capacity retunes.
        c = getattr(self, '_seq_chunks', None)
        if c is not None:
            span = max(MVE_FULL_CHUNKS - MVE_MIN_CHUNKS, 1)
            w *= float(np.clip((c - MVE_MIN_CHUNKS) / span, 0.0, 1.0))
        return w

    @torch.no_grad()
    def _mve_expand(self, h, z, e_emb, e_route, alpha_s, alpha_a):
        """From the n-step landing belief (h, z, the REAL landing embedding+route), imagine
        MVE_HORIZON steps with the current policy through the RSSM (prior z after the first step,
        decoded [embedding, route] as the policy/critic inputs), accumulating symexp'd predicted
        rewards and Bernoulli expected cost-event mass with done-head continuation discounting;
        then bootstrap BOTH target ensembles at the imagined endpoint, mirroring the real target
        path exactly (TD3 steer smoothing, min/max subset select, entropy shift). Returns
        (tail_r, tail_c, diag) — model-expanded replacements for the model-free tails, each (B,N).

        Action-format trap (explicitly handled): the GRU and heads train on EXECUTED actions
        [steer, onehot6]; the policy's bootstrap form is [steer, probs]. Sample+one-hot for every
        model call; the native policy form only for the endpoint critic bootstrap."""
        B = h.shape[0]
        R = torch.zeros(B, 1, device=self.device)
        C_im = torch.zeros(B, 1, device=self.device)
        # must be too: the surrogate E[C - d*D] only restates E[C]/E[D] <= d when BOTH legs come
        D_im = torch.zeros(B, 1, device=self.device)
        disc_r = torch.ones(B, 1, device=self.device)
        disc_c = torch.ones(B, 1, device=self.device)
        belief = torch.cat([h, z], dim=-1)
        for _ in range(MVE_HORIZON):
            a_pi, _ = self.policy_net.sample(e_emb, route=e_route, hard=False, belief=belief)
            idx = torch.multinomial(a_pi[:, 1:].clamp(min=1e-8), 1).squeeze(-1)
            a_exec = torch.cat([a_pi[:, 0:1],
                                F.one_hot(idx, NUM_DISCRETE_ACTIONS).to(a_pi.dtype)], dim=-1)
            head_in = torch.cat([belief, a_exec], dim=-1)
            r_hat = symexp(self.rssm.reward_head(head_in))
            # Bernoulli event prob x per-event discounted cost mass (see MVE_COST_EVENT_MASS)
            c_hat = torch.sigmoid(self.rssm.cost_head(head_in)) * MVE_COST_EVENT_MASS
            cont = 1.0 - torch.sigmoid(self.rssm.done_head(head_in))
            d_hat = e_route[:, 0:1].clamp(min=0.0)
            R = R + disc_r * r_hat
            C_im = C_im + disc_c * c_hat
            # disc_c carries the done-head continuation, so a predicted terminal stops accruing
            # distance -- the imagination-side statement of "a crashed car covers no more ground".
            D_im = D_im + disc_c * d_hat
            disc_r = disc_r * self.gamma * cont
            disc_c = disc_c * self.gamma_cost * cont
            h = self.rssm.step(h, z, a_exec)
            z = self.rssm.sample_z(self.rssm.prior_logits(h))       # PRIOR z: no obs in imagination
            belief = torch.cat([h, z], dim=-1)
            obs = self.rssm.decoder(belief)                          # decoded [embedding, route]
            e_emb, e_route = obs[:, :STATE_DIM], obs[:, STATE_DIM:]
        # endpoint bootstrap, mirroring the real target path (TD3 smoothing + entropy shift)
        a_k, logp_s, logp_a, _, _ = self.policy_net.sample(e_emb, route=e_route, hard=False,
                                                           return_sum=False, return_entropy=True,
                                                           belief=belief)
        a_k = a_k.clone()
        noise = torch.clamp(torch.randn_like(a_k[:, 0:1]) * self.target_policy_noise_std,
                            -self.target_policy_noise_clip, self.target_policy_noise_clip)
        a_k[:, 0:1] = torch.clamp(a_k[:, 0:1] + noise, 0.0, 1.0)
        zc_im = self._critic_in(e_emb, belief)
        Z_r = self.critic_target.unnormalize(
            self.critic_target(zc_im, a_k, context=None, route=e_route).clone())
        ent_shift = alpha_s * logp_s.unsqueeze(-1) + alpha_a * logp_a.unsqueeze(-1)
        tail_r = R + disc_r * (self._select_target_subset(Z_r, 'min') - ent_shift)   # (B,N)
        # one cost-critic call carries both legs: return_dist=True adds Q_d at no extra einsum cost
        _zc_out = self.cost_critic_target(zc_im, a_k, context=None, route=e_route, return_dist=True)
        Z_c = self.cost_critic_target.unnormalize(_zc_out[0].clone())
        tail_c = C_im + disc_c * self._select_target_subset(Z_c, 'max')              # (B,N)
        # Q_d uses the ensemble mean (policy evaluation, not risk) -- no min/max subset select
        qd_end = _zc_out[1].clone().mean(dim=0, keepdim=False).unsqueeze(-1)         # (B,1)
        tail_d = D_im + disc_c * qd_end                                             # (B,1)
        diag = {'MVE/imag_reward': R.mean().item(), 'MVE/imag_cost': C_im.mean().item(),
                'MVE/imag_dist': D_im.mean().item(),
                'MVE/cont_prod': (disc_r / (self.gamma ** MVE_HORIZON)).mean().item()}
        return tail_r, tail_c, tail_d, diag

    @torch.no_grad()
    def _safety_mve_expand(self, h, z, e_emb, e_route):
        """Cost-only H32 expansion. K particles are flattened into the batch so the sequential
        kernel-launch cost is paid once; the critic target receives the particle mean."""
        B = h.shape[0]
        K = SAFETY_MVE_PARTICLES
        h = h.repeat_interleave(K, 0)
        z = z.repeat_interleave(K, 0)
        e_emb = e_emb.repeat_interleave(K, 0)
        e_route = e_route.repeat_interleave(K, 0)
        BK = h.shape[0]
        c_im = torch.zeros((BK, 1), device=self.device)
        disc = torch.ones((BK, 1), device=self.device)
        belief = torch.cat([h, z], -1)
        for _ in range(SAFETY_MVE_HORIZON):
            a_pi, _ = self.policy_net.sample(e_emb, route=e_route, hard=False, belief=belief)
            idx = torch.multinomial(a_pi[:, 1:].clamp(min=1e-8), 1).squeeze(-1)
            a_exec = torch.cat([a_pi[:, :1],
                                F.one_hot(idx, NUM_DISCRETE_ACTIONS).to(a_pi.dtype)], -1)
            head_in = torch.cat([belief, a_exec], -1)
            pc = torch.sigmoid(self.rssm.cost_head(head_in)) * MVE_COST_EVENT_MASS
            cont = 1.0 - torch.sigmoid(self.rssm.done_head(head_in))
            c_im.add_(disc * pc)
            disc.mul_(self.gamma_cost * cont)
            h = self.rssm.step(h, z, a_exec)
            z = self.rssm.sample_z(self.rssm.prior_logits(h))
            belief = torch.cat([h, z], -1)
            obs = self.rssm.decoder(belief)
            e_emb, e_route = obs[:, :STATE_DIM], obs[:, STATE_DIM:]
        a_end, _ = self.policy_net.sample(e_emb, route=e_route, hard=False, belief=belief)
        zc = self._critic_in(e_emb, belief)
        # The compiled critic is specialized to B=1024. Cache refresh is B=64*K and would trigger
        # expensive recompilation/cache eviction, so use the same underlying target module eagerly.
        ctarget = getattr(self.cost_critic_target, '_orig_mod', self.cost_critic_target)
        z_all = ctarget.unnormalize(
            ctarget(zc, a_end, context=None, route=e_route).clone())
        tail = c_im + disc * self._select_target_subset(z_all, 'max')
        tail_k = tail.view(B, K, -1)
        return tail_k.mean(1), tail_k.mean(-1).std(1, unbiased=False)

    def _refresh_safety_cache(self, replay_buffer, sample_indices, original_ids,
                              cost_state, cost_route, cost_burnin, cost_burnin_mask,
                              cost_valid):
        """Refresh up to SAFETY_MVE_ROWS eligible sampled slots. Invalid rows never block and keep
        the exact-H30/model-free fallback. Writes are transition-id checked before launch."""
        if (not SAFETY_MVE_ENABLED or cost_state is None or
                self.update_count % SAFETY_MVE_EVERY != SAFETY_MVE_PHASE):
            return {}
        queued_slots, queued_ids = [], []
        while replay_buffer.safety_refresh_queue and len(queued_slots) < SAFETY_MVE_ROWS * 2:
            slot, tid = replay_buffer.safety_refresh_queue.popleft()
            if slot < replay_buffer.cap_safe:
                queued_slots.append(slot)
                queued_ids.append(tid)
        if queued_slots:
            qs = torch.tensor(queued_slots, dtype=torch.long, device=self.device)
            qi = torch.tensor(queued_ids, dtype=torch.long, device=self.device)
            qok = ((replay_buffer.transition_ids[qs] == qi) &
                   replay_buffer.cost_landing_valid[qs])
            qs, qi = qs[qok][:SAFETY_MVE_ROWS], qi[qok][:SAFETY_MVE_ROWS]
            queued_slots, queued_ids = qs.detach().cpu().tolist(), qi.detach().cpu().tolist()

        # Fill unused capacity with stale, high-cost-priority rows from this replay batch.
        remaining = SAFETY_MVE_ROWS - len(queued_slots)
        eligible = (cost_valid.bool() & (sample_indices < replay_buffer.cap_safe) &
                    (replay_buffer.transition_ids[sample_indices] == original_ids))
        stale = ((self.update_count - replay_buffer.safety_cache_updates[
            sample_indices.clamp(max=replay_buffer.cap_safe - 1)]) >
                 SAFETY_MVE_CACHE_MAX_AGE)
        rows = torch.nonzero(eligible & stale, as_tuple=False).squeeze(1)
        if rows.numel() > remaining:
            p = replay_buffer.priorities_cost[sample_indices[rows]]
            rows = rows[torch.topk(p, remaining).indices]
        sample_slots = sample_indices[rows].detach().cpu().tolist() if remaining > 0 else []
        sample_ids = original_ids[rows].detach().cpu().tolist() if remaining > 0 else []
        pairs = list(dict.fromkeys(zip(queued_slots + sample_slots,
                                       queued_ids + sample_ids)))
        if not pairs:
            return {'SafetyMVE/refresh_rows': 0.0,
                    'SafetyMVE/queue_depth': float(len(replay_buffer.safety_refresh_queue))}
        slots = torch.tensor([p[0] for p in pairs], dtype=torch.long, device=self.device)
        ids = torch.tensor([p[1] for p in pairs], dtype=torch.long, device=self.device)

        def work(report_sd=True):
            with torch.no_grad():
                win = replay_buffer.cost_burnin[slots].float()
                mask = replay_buffer.cost_burnin_mask[slots].float()
                h = self._burnin_unroll_safety(win[:, :, :RSSM_OBS_DIM],
                                               win[:, :, RSSM_OBS_DIM:], mask)
                obs = torch.cat([replay_buffer.cost_next_states[slots].float(),
                                 replay_buffer.cost_next_routes[slots].float()], -1)
                belief, z = self.rssm.posterior_belief(h, obs)
                tail, particle_sd = self._safety_mve_expand(
                    h, z, replay_buffer.cost_next_states[slots].float(),
                    replay_buffer.cost_next_routes[slots].float())
                # Cache the complete blended t+30 tail so ordinary SAC updates do not need another
                # burn-in/policy/critic pass merely to form the 0.6 model-free component.
                a30, _ = self.policy_net.sample(
                    replay_buffer.cost_next_states[slots].float(),
                    route=replay_buffer.cost_next_routes[slots].float(),
                    hard=False, belief=belief)
                z30 = self._critic_in(replay_buffer.cost_next_states[slots].float(), belief)
                ctarget = getattr(self.cost_critic_target, '_orig_mod', self.cost_critic_target)
                all30 = ctarget.unnormalize(
                    ctarget(
                        z30, a30, context=None,
                        route=replay_buffer.cost_next_routes[slots].float()).clone())
                mf30 = self._select_target_subset(all30, 'max')
                tail = ((1.0 - SAFETY_MVE_CACHE_BLEND) * mf30 +
                        SAFETY_MVE_CACHE_BLEND * tail)
                still = replay_buffer.transition_ids[slots] == ids
                if still.any():
                    ss = slots[still]
                    replay_buffer.safety_cache[ss] = tail[still].half()
                    replay_buffer.safety_cache_ids[ss] = ids[still]
                    replay_buffer.safety_cache_updates[ss] = self.update_count
                return float(particle_sd.mean().item()) if report_sd else 0.0

        if self._safety_stream is not None:
            # Current-stream event makes parameter reads and sampled tensors visible to the worker
            # stream; the next update waits before mutating those parameters.
            ready = torch.cuda.Event()
            ready.record(torch.cuda.current_stream(self.device))
            with torch.cuda.stream(self._safety_stream):
                self._safety_stream.wait_event(ready)
                work(report_sd=False)
                done = torch.cuda.Event()
                done.record(self._safety_stream)
            self._safety_event = done
            self._safety_pending_refs = (sample_indices, original_ids, slots, ids)
            return {'SafetyMVE/refresh_rows': float(slots.numel()),
                    'SafetyMVE/queue_depth': float(len(replay_buffer.safety_refresh_queue)),
                    'SafetyMVE/async': 1.0}
        psd = work()
        return {'SafetyMVE/refresh_rows': float(slots.numel()),
                'SafetyMVE/queue_depth': float(len(replay_buffer.safety_refresh_queue)),
                'SafetyMVE/particle_sd': psd, 'SafetyMVE/async': 0.0}

    def update(self, replay_buffer, batch_size, seq_buffer=None):

        if self._safety_event is not None:
            torch.cuda.current_stream(self.device).wait_event(self._safety_event)
            self._safety_event = None
            self._safety_pending_refs = None

        # KL-to-IL targets anneal toward (steer 0.6 / accel 0.8). A higher target means a
        # looser leash to the IL prior, so the auto-tuned KL weight stays naturally low.
        self.target_kl_steer = self.linear_interpolation(initial_value=self.target_kl_steer_initial,
                                                          final_value=self.target_kl_steer_final,
                                                          total_steps=self.kl_target_ramp_steps,
                                                          current_step=self.update_count-self.critic_warm_up)

        self.target_kl_accel = self.linear_interpolation(initial_value=self.target_kl_accel_initial,
                                                          final_value=self.target_kl_accel_final,
                                                          total_steps=self.kl_target_ramp_steps,
                                                          current_step=self.update_count-self.critic_warm_up)

        if not self.gpu_replay_buffer:
            sample_result, sample_indices, original_ids = replay_buffer.sample(batch_size, self.update_count)
            if sample_result is None:
                return
            ps_np, s_np, a_np, r_np, ns_np, d_np, aq_np, aqn_np, is_w_r_np, is_w_c_np = sample_result

            self.state_normalizer.update(s_np)
            self.reward_normalizer.update(r_np)

            pre_state = torch.from_numpy(ps_np).pin_memory().to(self.device, non_blocking=True)
            state = torch.from_numpy(s_np).pin_memory().to(self.device, non_blocking=True)
            action = torch.from_numpy(a_np).pin_memory().to(self.device, non_blocking=True)
            reward_extrinsic_raw = torch.from_numpy(r_np).pin_memory().to(self.device, non_blocking=True)
            next_state = torch.from_numpy(ns_np).pin_memory().to(self.device, non_blocking=True)
            done = torch.from_numpy(d_np).pin_memory().to(self.device, non_blocking=True)
            action_queue = torch.from_numpy(aq_np).pin_memory().to(self.device, non_blocking=True)
            action_queue_next = torch.from_numpy(aqn_np).pin_memory().to(self.device, non_blocking=True)
            is_weight_r = torch.from_numpy(is_w_r_np).pin_memory().to(self.device, non_blocking=True)
            is_weight_c = torch.from_numpy(is_w_c_np).pin_memory().to(self.device, non_blocking=True)
            boxes = next_boxes = None  # CPU buffer path has no box tokens (asserts in critic if USE_BOX_CRITIC)
            route_scalars = next_route_scalars = None
            nstep_reward = nstep_cost = nstep_n = nstep_cost_done = nstep_dist = nstep_s2t = None  # CPU buffer path: classic 1-step targets
            burnin_cur = burnin_next = burnin_cur_mask = burnin_next_mask = None  # CPU buffer path: no burn-in windows -> zero-h fallback
            cost_next_state = cost_next_route = cost_burnin = cost_burnin_mask = None
            cost_landing_valid = cache_tail = cache_ids = cache_updates = None
        else:
            sample_result, sample_indices, original_ids = replay_buffer.sample(batch_size, self.update_count)
            if sample_result is None:
                return

            # --- Unpack GPU tensors directly (boxes, then route scalars, appended at the end) ---
            pre_state, state, action, reward_extrinsic_raw, next_state, done, action_queue, action_queue_next, is_weight_r, is_weight_c, boxes, next_boxes, route_scalars, next_route_scalars = sample_result[:14]
            # n-step scalar targets (StratifiedGpuReplayBuffer appends them; other buffers don't).
            if len(sample_result) > 14:
                nstep_reward, nstep_cost, nstep_n = sample_result[14:17]
                # Cost-channel done (exact-return-to-terminal flag; position 17); falls back to
                # the reward-channel done when the buffer does not supply it.
                nstep_cost_done = sample_result[17] if len(sample_result) > 17 else done
                # RSSM burn-in windows (positions 18-21): the (K-1) frames before s_t and before
                # the n-step landing state, with their validity masks. None -> zero-h belief.
                burnin_cur = sample_result[18] if len(sample_result) > 21 else None
                burnin_next = sample_result[19] if len(sample_result) > 21 else None
                burnin_cur_mask = sample_result[20] if len(sample_result) > 21 else None
                burnin_next_mask = sample_result[21] if len(sample_result) > 21 else None
                # n-step DISTANCE target (position 22, appended last). None -> the distance head
                # simply does not train this step and the surrogate falls back to plain Q_c.
                nstep_dist = sample_result[22] if len(sample_result) > 22 else None
                # Steps-to-terminal (position 23). None -> the gate falls back to partition-label
                # keying (see the actor's cost block).
                nstep_s2t = sample_result[23] if len(sample_result) > 23 else None
                cost_next_state = sample_result[24] if len(sample_result) > 31 else None
                cost_next_route = sample_result[25] if len(sample_result) > 31 else None
                cost_burnin = sample_result[26] if len(sample_result) > 31 else None
                cost_burnin_mask = sample_result[27] if len(sample_result) > 31 else None
                cost_landing_valid = sample_result[28] if len(sample_result) > 31 else None
                cache_tail = sample_result[29] if len(sample_result) > 31 else None
                cache_ids = sample_result[30] if len(sample_result) > 31 else None
                cache_updates = sample_result[31] if len(sample_result) > 31 else None
            else:
                nstep_reward = nstep_cost = nstep_n = nstep_cost_done = nstep_dist = None
                nstep_s2t = None
                burnin_cur = burnin_next = burnin_cur_mask = burnin_next_mask = None
                cost_next_state = cost_next_route = cost_burnin = cost_burnin_mask = None
                cost_landing_valid = cache_tail = cache_ids = cache_updates = None
            self.reward_normalizer.update(reward_extrinsic_raw)
            self.state_normalizer.update(state)
            # Box tokens are stored fp16; the critic encoder runs fp32 (USE_AMP off).
            if boxes is not None:
                boxes = boxes.float()
                next_boxes = next_boxes.float()

        # CMDP: reward is the pure task signal; cost_raw is the constraint signal fed to the cost critic.
        reward_extrinsic_raw, cost_raw, log_reward = self.calculate_reward(reward_extrinsic_raw, action)

        # Exploration term of Eq. 2: r = task + omega_int * r_int, with r_int the RND predictor
        # error on the next-state embedding. The predictor is trained on the same batch.
        rnd_bonus = None
        if RND_ENABLED and self.rnd is not None:
            rnd_in = next_state.detach().float()
            pred, target = self.rnd(rnd_in)
            rnd_err = (pred - target.detach()).pow(2).mean(dim=-1)          # [B]
            with torch.no_grad():
                self.rnd_normalizer.update(rnd_err.detach())
                r_int = (rnd_err.detach()
                         / torch.sqrt(self.rnd_normalizer.var.float() + 1e-8)
                         ).clamp(0.0, RND_CLIP).unsqueeze(-1)               # [B,1]
            rnd_bonus = OMEGA_INT * r_int          # applied to task_reward below, after n-step selection
            rnd_loss = rnd_err.mean()
            self.rnd_optimizer.zero_grad(set_to_none=True)
            rnd_loss.backward()
            self.rnd_optimizer.step()
            log_reward["RND/loss"] = rnd_loss.detach().item()
            log_reward["RND/r_int"] = r_int.mean().item()

        if not self.use_action_queue:
            action_queue = None
            action_queue_next = None

        # --- Sanity checking tensor shapes ---
        assert reward_extrinsic_raw.shape == torch.Size([self.batch_size, 1])
        assert state.shape == torch.Size([self.batch_size, self.state_dim])
        assert pre_state.shape == torch.Size([self.batch_size, self.state_dim])
        assert next_state.shape == torch.Size([self.batch_size, self.state_dim])
        assert action.shape == torch.Size([self.batch_size, self.action_dim])
        assert done.shape == torch.Size([self.batch_size, 1])

        nan_check(cost_raw, "cost_raw")
        nan_check(state, "state from buffer")
        nan_check(next_state, "next_state from buffer")
        nan_check(reward_extrinsic_raw, "reward from buffer")

        if nstep_reward is not None:
            task_reward = nstep_reward
            gamma_n_r = self.gamma ** nstep_n            # [B,1], broadcasts over quantiles
            gamma_n_c = self.gamma_cost ** nstep_n
        else:
            task_reward = reward_extrinsic_raw
            gamma_n_r = self.gamma
            gamma_n_c = self.gamma_cost

        # Exploration term of Eq. 2. It is added HERE, after the n-step target is selected: the n-step
        # returns are aggregated worker-side from the extrinsic reward alone, so adding the bonus any
        # earlier would be discarded by the branch above and r_int would never reach the critic.
        if rnd_bonus is not None:
            task_reward = task_reward + rnd_bonus
        normalized_next_state = next_state
        normalized_state = state

        assert task_reward.shape == torch.Size([self.batch_size, 1])
        nan_check(task_reward, "task_reward")

        # Inject plasticity into the (reward) critic heads at strategic points in training.
        if self.update_count == self.critic_warm_up:
            self.inject_plasticity()
        elif self.update_count > self.critic_warm_up and (self.update_count - self.critic_warm_up) % self.plasticity_freq == 0:
            self.inject_plasticity()

        denoise_active = EMBED_DENOISE_ENABLED and (self.update_count > self.critic_warm_up)
        self._denoise_active = denoise_active

        # under no_grad -- the SAC losses never backprop into the RSSM.
        rssm_log = {}
        belief = belief_next = z_next = h_n = None
        if RSSM_ENABLED:
            # Data support of the world model, read by the MVE chunk gate in _mve_weight().
            self._seq_chunks = int(seq_buffer.count) if seq_buffer is not None else 0
            if seq_buffer is not None and self.update_count % RSSM_TRAIN_EVERY == 0:
                rssm_log = self._update_rssm(seq_buffer)
            with torch.no_grad():
                B = state.shape[0]
                # RSSM (never a stored h -> no representational drift). h_n is the filter state at
                h_c, h_n = self._burnin_h_pair(burnin_cur, burnin_cur_mask,
                                               burnin_next, burnin_next_mask, B)
                belief, _ = self.rssm.posterior_belief(h_c, self._rssm_obs(state, route_scalars))
                belief_next, z_next = self.rssm.posterior_belief(h_n, self._rssm_obs(next_state, next_route_scalars))

        # --- Distributional Target Calculation (reward critic only) ---
        with torch.no_grad():
            N = self.critic.critic_net.num_quantiles

            next_action, next_log_prob_steer, next_log_prob_accel = self.policy_net.sample(next_state, route=next_route_scalars, hard=False, return_sum=False, belief=belief_next)
            next_log_prob_steer = next_log_prob_steer.unsqueeze(-1)
            next_log_prob_accel = next_log_prob_accel.unsqueeze(-1)

            nan_check(next_action, "next_action")
            nan_check(next_log_prob_steer, "next_log_prob_steer")
            nan_check(next_log_prob_accel, "next_log_prob_accel")

            # TD3-style target-action smoothing (kept; reduced noise).
            noise = (torch.randn_like(next_action[:, 0]) * self.target_policy_noise_std).clamp(-self.target_policy_noise_clip, self.target_policy_noise_clip)
            smoothed_next_steer = (next_action[:, 0] + noise).clamp(0.0, 1.0).unsqueeze(-1)
            smoothed_next_action = torch.cat([smoothed_next_steer, next_action[:, 1:]], dim=1)

            # E: ONE shared TARGET box-context (Polyak target encoder) for BOTH target critics.
            ctx_t = self.box_encode_target(normalized_next_state, next_boxes) if (USE_BOX_CRITIC and next_boxes is not None) else None

            # --- Target Q (Reward): clipped double-Q over a random subset of critics ---
            zc_next = self._critic_in(normalized_next_state, belief_next)  # [denoised next-state, belief_next] (no_grad)
            target_q_r_all_critics_norm = self.critic_target(zc_next, smoothed_next_action, context=ctx_t, route=next_route_scalars).clone()  # clone: free output from CUDA-graph buffer
            target_q_r_all_critics_unnorm = self.critic_target.unnormalize(target_q_r_all_critics_norm) # [C, B, N]

            indices = np.random.choice(NUM_CRITICS, NUM_TARGET_CRITICS, replace=False)
            target_q_r_subset = target_q_r_all_critics_unnorm[indices]

            # Min over expected value
            target_means_r_subset = target_q_r_subset.mean(dim=-1)
            min_idx_r = torch.argmin(target_means_r_subset, dim=0, keepdim=True)
            min_idx_expanded_r = min_idx_r.unsqueeze(-1).expand(-1, self.batch_size, N)
            target_q_r = torch.gather(target_q_r_subset, 0, min_idx_expanded_r).squeeze(0) # [B, N]

            # entropy-shifted distributional Bellman backup
            if self.hard_bellman_accel:
                ent_shift_next = self.alpha_steer.detach() * next_log_prob_steer
            else:
                ent_shift_next = self.alpha_steer.detach() * next_log_prob_steer + self.alpha_accel.detach() * next_log_prob_accel
            tail_r = target_q_r - ent_shift_next                     # (B,N) model-free tail

            # per update; the distance leg must be blended with the SAME w as the cost leg or the
            w_mve, tail_c_mve, tail_d_mve, _mve_gate = 0.0, None, None, None
            if RSSM_ENABLED and MVE_ENABLED and self.update_count >= MVE_DIAG_START and z_next is not None:
                w_mve = self._mve_weight()
                # the danger tail. Measured against the model-free target on real buffer rows:
                _mve_gate = None
                _cap_safe = getattr(replay_buffer, 'cap_safe', None)
                if MVE_SKIP_UNSAFE and _cap_safe is not None:
                    # (B,) -> 1.0 on safe rows, 0.0 on unsafe. Broadcast over the quantile axis.
                    _mve_gate = (sample_indices < _cap_safe).to(tail_r.dtype).unsqueeze(-1)
                tail_r_mve, tail_c_mve, tail_d_mve, mve_diag = self._mve_expand(
                    h_n, z_next, next_state, next_route_scalars,
                    self.alpha_steer.detach(), self.alpha_accel.detach())
                rssm_log.update(mve_diag)
                rssm_log['MVE/w'] = w_mve
                rssm_log['MVE/target_gap_r'] = (tail_r_mve.mean(-1) - tail_r.mean(-1)).abs().mean().item()
                # SIGNED bias: >0 = model tail optimistic vs model-free tail (abs gap hides direction)
                rssm_log['MVE/target_bias_r'] = (tail_r_mve.mean(-1) - tail_r.mean(-1)).mean().item()
                if _mve_gate is not None:
                    rssm_log['MVE/safe_row_frac'] = _mve_gate.mean().item()
                    # signed bias split by partition -- the number that justifies the mask
                    _d = (tail_r_mve.mean(-1) - tail_r.mean(-1))
                    _g = _mve_gate.squeeze(-1)
                    _ns = _g.sum().clamp(min=1.0)
                    _nu = (1.0 - _g).sum().clamp(min=1.0)
                    rssm_log['MVE/target_bias_r_safe'] = ((_d * _g).sum() / _ns).item()
                    rssm_log['MVE/target_bias_r_unsafe'] = ((_d * (1.0 - _g)).sum() / _nu).item()
                if w_mve > 0.0:
                    w_r = w_mve if _mve_gate is None else w_mve * _mve_gate
                    tail_r = (1.0 - w_r) * tail_r + w_r * tail_r_mve

            target_q_reward = task_reward + (1 - done) * gamma_n_r * tail_r

        target_q_reward_norm = target_q_reward.unsqueeze(0).expand(NUM_CRITICS, -1, -1)

        # --- Distributional Critic Update (quantile-Huber, kappa_r) ---
        with autocast(device_type='cuda', dtype=torch.bfloat16, enabled=USE_AMP):
            ctx = self.box_encode(normalized_state, boxes) if (USE_BOX_CRITIC and boxes is not None) else None
            ctx_det = ctx.detach() if ctx is not None else None
            current_q_r_quantiles = self.critic(self._critic_in(normalized_state, belief), action, context=ctx, route=route_scalars).clone() # [denoised state (trains the denoiser), detached belief]; [C, B, N]; clone: retained for priority calc past later critic calls

            target_Z_r = target_q_reward_norm.unsqueeze(-2) # [C, B, 1, N]
            current_Z_r = current_q_r_quantiles.unsqueeze(-1) # [C, B, N, 1]
            u_r = target_Z_r - current_Z_r

            huber_loss_r = torch.where(u_r.abs() <= self.kappa_r, 0.5 * u_r.pow(2), self.kappa_r * (u_r.abs() - 0.5 * self.kappa_r))
            tau = (torch.arange(N, device=self.device, dtype=torch.float32) + 0.5) / N
            tau = tau.view(1, 1, N, 1)
            quantile_loss_r = torch.abs(tau - (u_r.detach() < 0).float()) * huber_loss_r
            unreduced_bellman_loss_r = quantile_loss_r.mean(dim=-1).mean(dim=-1).mean(dim=0)
            bellman_loss_r = (unreduced_bellman_loss_r * is_weight_r.squeeze()).mean()

            critic_loss_r = bellman_loss_r / self.accumulation_steps
            nan_check(critic_loss_r, "critic_loss_r")
            critic_loss = critic_loss_r

        self.scaler.scale(critic_loss).backward(retain_graph=(ctx is not None))

        if self.update_count % self.accumulation_steps == 0:
            self.scaler.unscale_(self.critic_optimizer)
            critic_grad_norm = torch.nn.utils.clip_grad_norm_(self.critic.parameters(), max_norm=REWARD_CRITIC_GRAD_CLIP)
            self.scaler.step(self.critic_optimizer)
            self.critic_optimizer.zero_grad()

        with torch.no_grad():
            _tgt_c_out = self.cost_critic_target(self._critic_in(normalized_next_state, belief_next), smoothed_next_action, context=ctx_t, route=next_route_scalars, return_dist=True)  # [denoised next-state, belief_next] (no_grad); E: reuse shared target context
            target_q_c_all_critics_norm = _tgt_c_out[0].clone()
            tail_d_all = _tgt_c_out[1].clone()                      # [C, B]
            target_q_c_all_critics_unnorm = self.cost_critic_target.unnormalize(target_q_c_all_critics_norm) # [C, B, N]

            indices_c = np.random.choice(NUM_CRITICS, NUM_TARGET_CRITICS, replace=False)
            target_q_c_subset = target_q_c_all_critics_unnorm[indices_c]

            # MAX over expected value (pessimistic about SAFETY = optimistic about cost)
            target_means_c_subset = target_q_c_subset.mean(dim=-1)
            max_idx_c = torch.argmax(target_means_c_subset, dim=0, keepdim=True)
            max_idx_expanded_c = max_idx_c.unsqueeze(-1).expand(-1, self.batch_size, N)
            target_q_c = torch.gather(target_q_c_subset, 0, max_idx_expanded_c).squeeze(0) # [B, N]

            # factor below, so the no-double-count invariant holds by construction.
            tail_c = target_q_c                                       # (B,N) model-free tail
            if tail_c_mve is not None:
                rssm_log['MVE/target_gap_c'] = (tail_c_mve.mean(-1) - tail_c.mean(-1)).abs().mean().item()
                # SIGNED bias: <0 = model tail UNDER-estimates cost (the dangerous direction)
                _dc = (tail_c_mve.mean(-1) - tail_c.mean(-1))
                rssm_log['MVE/target_bias_c'] = _dc.mean().item()
                if _mve_gate is not None:
                    _g = _mve_gate.squeeze(-1)
                    rssm_log['MVE/target_bias_c_safe'] = ((_dc * _g).sum() / _g.sum().clamp(min=1.0)).item()
                    rssm_log['MVE/target_bias_c_unsafe'] = ((_dc * (1.0 - _g)).sum() / (1.0 - _g).sum().clamp(min=1.0)).item()
                if w_mve > 0.0 and not SAFETY_MVE_ENABLED:
                    w_c = w_mve if _mve_gate is None else w_mve * _mve_gate
                    tail_c = (1.0 - w_c) * tail_c + w_c * tail_c_mve

            # never blocks and never replaces the exact observed prefix.
            long_valid = (cost_landing_valid.bool() if cost_landing_valid is not None else
                          torch.zeros(self.batch_size, dtype=torch.bool, device=self.device))
            long_tail = tail_c
            fresh = torch.zeros_like(long_valid)
            if SAFETY_MVE_ENABLED and cache_tail is not None:
                fresh = (long_valid & (cache_ids == original_ids) &
                         ((self.update_count - cache_updates) >= 0) &
                         ((self.update_count - cache_updates) <=
                          SAFETY_MVE_CACHE_MAX_AGE))
                fi = torch.nonzero(fresh, as_tuple=False).squeeze(1)
                if fi.numel() > 0:
                    long_tail = tail_c.clone()
                    long_tail[fi] = cache_tail[fi].float()
                rssm_log['SafetyMVE/cache_hit_frac'] = fresh.float().mean().item()
                rssm_log['SafetyMVE/cache_hit_eligible'] = (
                    fresh.float().sum() / long_valid.float().sum().clamp(min=1.0)).item()

            if nstep_cost is not None:
                cost_done = nstep_cost_done if nstep_cost_done is not None else done
                cost_discount = torch.where(
                    fresh.unsqueeze(-1),
                    torch.full_like(gamma_n_c, self.gamma_cost ** N_STEP_COST_LOOKAHEAD),
                    gamma_n_c)
                target_q_cost = nstep_cost + (1 - cost_done) * cost_discount * long_tail
            else:
                target_q_cost = cost_raw + (1 - done) * self.gamma_cost * tail_c + done * (cost_raw / (1 - self.gamma_cost))

            if nstep_dist is not None:
                d_done = nstep_cost_done if nstep_cost_done is not None else done
                tail_d = tail_d_all.mean(dim=0, keepdim=False).unsqueeze(-1)       # [B, 1]
                # factor below, mirroring the cost channel's no-double-count invariant.
                if tail_d_mve is not None:
                    rssm_log['MVE/target_gap_d'] = (tail_d_mve - tail_d).abs().mean().item()
                    # SIGNED bias: <0 = model tail UNDER-estimates distance, which would make the
                    # credit too small and re-open the braking degeneracy this leg exists to close.
                    rssm_log['MVE/target_bias_d'] = (tail_d_mve - tail_d).mean().item()
                    if w_mve > 0.0:
                        # MUST use the same effective weight as the cost leg (including the
                        w_d = w_mve if _mve_gate is None else w_mve * _mve_gate
                        tail_d = (1.0 - w_d) * tail_d + w_d * tail_d_mve
                target_q_dist = nstep_dist + (1 - d_done) * gamma_n_c * tail_d     # [B, 1]
                target_q_dist = target_q_dist.squeeze(-1).unsqueeze(0).expand(NUM_CRITICS, -1)  # [C, B]
            else:
                target_q_dist = None

        target_q_cost_norm = target_q_cost.unsqueeze(0).expand(NUM_CRITICS, -1, -1)

        with autocast(device_type='cuda', dtype=torch.bfloat16, enabled=USE_AMP):
            # reuses the shared context (no second encode); retain_graph lets this cost backward also flow g_cost into the shared encoder
            _cur_c_out = self.cost_critic(self._critic_in(normalized_state, belief), action, context=ctx, route=route_scalars, return_dist=True)
            current_q_c_quantiles = _cur_c_out[0].clone()
            current_q_dist = _cur_c_out[1]                  # [C, B]

            target_Z_c = target_q_cost_norm.unsqueeze(-2) # [C, B, 1, N]
            current_Z_c = current_q_c_quantiles.unsqueeze(-1) # [C, B, N, 1]
            u_c = target_Z_c - current_Z_c

            huber_loss_c = torch.where(u_c.abs() <= self.kappa_c, 0.5 * u_c.pow(2), self.kappa_c * (u_c.abs() - 0.5 * self.kappa_c))
            quantile_loss_c = torch.abs(tau - (u_c.detach() < 0).float()) * huber_loss_c # tau reused (same N)
            unreduced_bellman_loss_c = quantile_loss_c.mean(dim=-1).mean(dim=-1).mean(dim=0)
            bellman_loss_c = (unreduced_bellman_loss_c * is_weight_c.squeeze()).mean()

            if target_q_dist is not None:
                dist_loss = F.mse_loss(current_q_dist, target_q_dist)
                if self.update_count % LOG_INTERVAL == 0:
                    self.last_dist_loss = float(dist_loss.detach().item())
                    self.last_qd_mean = float(current_q_dist.detach().mean().item())
            else:
                dist_loss = torch.zeros((), device=bellman_loss_c.device, dtype=bellman_loss_c.dtype)

            cost_critic_loss = (bellman_loss_c + DIST_CRITIC_LOSS_WEIGHT * dist_loss) / self.accumulation_steps
            nan_check(cost_critic_loss, "cost_critic_loss")

        self.scaler.scale(cost_critic_loss).backward()

        if self.update_count % self.accumulation_steps == 0:
            self.scaler.unscale_(self.cost_critic_optimizer)
            cost_critic_grad_norm = torch.nn.utils.clip_grad_norm_(self.cost_critic.parameters(), max_norm=COST_CRITIC_GRAD_CLIP)
            self.scaler.step(self.cost_critic_optimizer)
            self.cost_critic_optimizer.zero_grad()

        if USE_BOX_CRITIC and boxes is not None and self.update_count % self.accumulation_steps == 0:
            self.scaler.unscale_(self.box_optimizer)
            box_grad_norm = torch.nn.utils.clip_grad_norm_(self.shared_box_encoder.parameters(), max_norm=BOX_GRAD_CLIP)
            self.scaler.step(self.box_optimizer)
            self.box_optimizer.zero_grad()

        self.denoiser_grad_norm = 0.0
        if denoise_active and self.denoiser_optimizer is not None and self.update_count % self.accumulation_steps == 0:
            self.scaler.unscale_(self.denoiser_optimizer)
            self.denoiser_grad_norm = float(torch.nn.utils.clip_grad_norm_(
                self.policy_net.embed_denoiser.parameters(), max_norm=DENOISER_GRAD_CLIP))
            self.scaler.step(self.denoiser_optimizer)
            self.denoiser_optimizer.zero_grad()

        # --- Actor Update: LCB pessimism + entropy + low uniform KL-to-IL + augmented-Lagrangian cost ---
        if self.update_count % self.policy_delay_freq == 0 and self.update_count > self.critic_warm_up:
            with autocast(device_type='cuda', dtype=torch.bfloat16, enabled=USE_AMP):
                with autocast(device_type='cuda', enabled=False):
                    new_action, log_prob_steer, log_prob_accel, steer_entropy, accel_entropy = self.policy_net.sample(state, route=route_scalars, hard=False, return_sum=False, return_entropy=True, belief=belief)
                log_prob_steer = log_prob_steer.unsqueeze(-1)
                log_prob_accel = log_prob_accel.unsqueeze(-1)

                # reward objective from the quantile ensemble: conformal trust region (CTR, default) or plain LCB mean - beta*std
                q_r_new_all_critics_norm = self.critic(self._critic_in(normalized_state, belief, detach=True), new_action, context=ctx_det, route=route_scalars).clone()  # detached state/belief/context -- actor must not train the encoder
                q_r_new_all_critics_unnorm = self.critic.unnormalize(q_r_new_all_critics_norm)

                q_r_new_means = q_r_new_all_critics_unnorm.mean(dim=-1)
                q_r_new_mean = torch.mean(q_r_new_means, dim=0)
                q_r_new_std = torch.std(q_r_new_means, dim=0)
                if CONFORMAL_TRUST_REGION:
                    with torch.no_grad():
                        # distributions, so the conformal exchangeability assumption never held and
                        batch_qhat = torch.quantile(q_r_new_std.detach().float(), 1.0 - CTR_ALPHA)
                        if self.ctr_qhat is None:
                            self.ctr_qhat = batch_qhat
                        else:
                            self.ctr_qhat = CTR_EMA * self.ctr_qhat + (1.0 - CTR_EMA) * batch_qhat
                    ctr_qh = self.ctr_qhat.detach()
                    # Tent: reward in-band disagreement (bounded at the frontier), tax the excess.
                    lcb_q_reward = (q_r_new_mean
                                    + CTR_OPTIMISM_BETA * torch.minimum(q_r_new_std, ctr_qh)
                                    - self.lcb_beta * torch.relu(q_r_new_std - ctr_qh))
                    ctr_excess_frac = (q_r_new_std > ctr_qh).float().mean()
                else:
                    lcb_q_reward = q_r_new_mean - self.lcb_beta * q_r_new_std
                    ctr_excess_frac = torch.zeros((), device=q_r_new_std.device)

                # --- CMDP: UCB of the cost ensemble (mean + beta*std); the actor MINIMIZES it ---
                _q_c_new_out = self.cost_critic(self._critic_in(normalized_state, belief, detach=True), new_action, context=ctx_det, route=route_scalars, return_dist=True)  # denoised+detached state + detached belief; E: shared detached context
                q_c_new_all_critics_norm = _q_c_new_out[0].clone()
                q_d_new_all_critics = _q_c_new_out[1]                 # [C, B]
                q_c_new_all_critics_unnorm = self.cost_critic.unnormalize(q_c_new_all_critics_norm)

                q_c_new_means = q_c_new_all_critics_unnorm.mean(dim=-1)
                q_c_new_mean = torch.mean(q_c_new_means, dim=0)
                q_c_new_std = torch.std(q_c_new_means, dim=0)
                ucb_q_cost = q_c_new_mean + self.ucb_beta * q_c_new_std # [B]

                q_d_new_mean = torch.mean(q_d_new_all_critics, dim=0)  # [B]
                if DIST_CREDIT_ENABLED and self.cost_limit_scheduler.initialized:
                    d_eff = float(self.cost_limit) * COST_TERMINAL_MASS
                    raw_credit = d_eff * q_d_new_mean                  # [B] gradient via Qd
                    # DETACHED, so the gradient still flows only through Qd (distance value) and never
                    target = DIST_CREDIT_FRAC * ucb_q_cost.detach().clamp(min=0.0)  # [B]
                    scale = (target / raw_credit.detach().clamp(min=1e-6)).clamp(max=1.0)
                    dist_credit = scale * raw_credit                   # [B], <= f*UCB by construction
                else:
                    d_eff = 0.0
                    dist_credit = 0.0 * q_d_new_mean                   # [B]
                cost_surrogate = ucb_q_cost - dist_credit              # [B]

                lam = self.lagrange_lambda.detach()
                cap_safe = getattr(replay_buffer, 'cap_safe', None)
                if COST_GATE_ENABLED and nstep_s2t is not None:
                    cost_gate = (nstep_s2t.squeeze(-1) <= float(COST_GATE_MAX_S2T)).to(ucb_q_cost.dtype)
                    lam_eff = lam + (COST_GATE_LAMBDA - lam).clamp(min=0.0) * cost_gate
                    loss_comp_cost = (lam_eff * cost_surrogate).mean()
                elif COST_GATE_ENABLED and cap_safe is not None:
                    cost_gate = (sample_indices >= cap_safe).to(ucb_q_cost.dtype)
                    lam_eff = lam + (COST_GATE_LAMBDA - lam).clamp(min=0.0) * cost_gate
                    loss_comp_cost = (lam_eff * cost_surrogate).mean()
                else:
                    cost_gate = torch.zeros_like(ucb_q_cost)
                    lam_eff = lam * torch.ones_like(ucb_q_cost)
                    loss_comp_cost = (lam * cost_surrogate).mean()

                # Augmented Lagrangian: the linear dual price above plus a quadratic penalty that
                # activates only once the cost upper bound crosses the budget,
                #   V = mu_c + nu_c*U_c - c_max,   L_AL = lambda*V + (rho/2)*max(0, V)^2.
                # c_max is constant w.r.t. the policy, so the linear term uses cost_surrogate
                # directly: it differs from lambda*V by a constant and has the same gradient.
                # self.cost_limit is a per-STEP mean of the RAW cost; cost_surrogate is a
                # discounted cost return. Converting between them needs both factors: the terminal
                # amplification folded into the label, and the discounted state occupancy
                #   E[Q_c] = mean(c_eff)/(1-gamma_c),  mean(c_eff) = COST_TERMINAL_MASS * c_bar,
                # so the budget scales by COST_TERMINAL_MASS/(1-gamma_c). (Exact for the
                # terminal-only channel; approximate once the dense TTC term contributes.)
                al_violation = cost_surrogate - float(self.cost_limit) * COST_BUDGET_TO_RETURN
                al_penalty = 0.5 * RHO * torch.clamp(al_violation, min=0.0).pow(2)
                loss_comp_cost = loss_comp_cost + al_penalty.mean()

                # --- Location anchor to the IL prior (see squared-distance block below) ---
                with torch.no_grad():
                    il_steer_dist, il_accel_dist = self.net.get_dist(state)

                # RL policy dist WITH the belief (what actually acts); the IL reference above stays
                # belief-free — it never saw the belief, matching its training distribution.
                rl_steer_dist, rl_accel_dist = self.policy_net.get_dist(state, route=route_scalars, belief=belief)

                def _steer_mode(d):
                    a = d.concentration1.float()
                    b = d.concentration0.float()
                    return ((a - 1.0 + 1e-3) / (a + b - 2.0 + 2e-3)) * 2.0 - 1.0
                next_steer_dist, _ = self.policy_net.get_dist(next_state, route=next_route_scalars, belief=belief_next)
                caps_steer_raw = (_steer_mode(rl_steer_dist) - _steer_mode(next_steer_dist)).pow(2).mean()
                loss_comp_caps = CAPS_WEIGHT_STEER * caps_steer_raw

                # Reconstruct distributions on clamped params so the mode / expected-command
                # used by the location anchor below can never hit a degenerate (NaN) value.
                min_conc = 1e-5
                rl_steer_dist = torch.distributions.Beta(
                    torch.clamp(rl_steer_dist.concentration1, min=min_conc),
                    torch.clamp(rl_steer_dist.concentration0, min=min_conc)
                )
                il_steer_dist = torch.distributions.Beta(
                    torch.clamp(il_steer_dist.concentration1, min=min_conc),
                    torch.clamp(il_steer_dist.concentration0, min=min_conc)
                )

                min_prob = 1e-8
                rl_accel_probs = torch.clamp(rl_accel_dist.probs, min=min_prob)
                rl_accel_probs = rl_accel_probs / rl_accel_probs.sum(dim=-1, keepdim=True)
                rl_accel_dist = torch.distributions.Categorical(probs=rl_accel_probs)

                il_accel_probs = torch.clamp(il_accel_dist.probs, min=min_prob)
                il_accel_probs = il_accel_probs / il_accel_probs.sum(dim=-1, keepdim=True)
                il_accel_dist = torch.distributions.Categorical(probs=il_accel_probs)

                kl_steer_ps = (_steer_mode(rl_steer_dist) - _steer_mode(il_steer_dist)).pow(2).flatten()
                # differentiated at a measured danger state (RL expected command -0.411, IL +0.422):
                kl_accel_ps = (rl_accel_dist.probs
                               * (rl_accel_dist.probs.log() - il_accel_dist.probs.log())
                               ).sum(dim=-1).clamp(min=0.0).flatten()
                # expected acceleration command under each policy (logged as a drift signal)
                acc_rl = (rl_accel_dist.probs * self.acc_vals).sum(dim=-1)
                acc_il = (il_accel_dist.probs * self.acc_vals).sum(dim=-1)

                anchor_gate = None
                if ANCHOR_GATE_ENABLED:
                    with torch.no_grad():
                        il_steer_01 = (_steer_mode(il_steer_dist) + 1.0) * 0.5
                        il_action = torch.cat([il_steer_01, il_accel_dist.probs], dim=-1)
                        cin_det = self._critic_in(normalized_state, belief, detach=True)
                        q_r_il = self.critic.unnormalize(self.critic(
                            cin_det, il_action, context=ctx_det, route=route_scalars)).mean(dim=-1)  # [C,B]
                        # per-ensemble-member gain of RL over IL; differencing inside each member cancels the state-value term
                        d_r = q_r_new_means - q_r_il                       # [C,B]
                        gap = d_r.mean(dim=0)
                        var = d_r.var(dim=0)
                        if ANCHOR_GATE_INCLUDE_COST:
                            q_c_il = self.cost_critic.unnormalize(self.cost_critic(
                                cin_det, il_action, context=ctx_det, route=route_scalars)).mean(dim=-1)
                            d_c = q_c_new_means - q_c_il                   # [C,B] (RL minus IL cost)
                            gap = gap - lam * d_c.mean(dim=0)              # cost is a PENALTY
                            var = var + (lam ** 2) * d_c.var(dim=0)        # independent ensembles
                        sd = var.clamp(min=0.0).sqrt()
                        gate_open = (gap > ANCHOR_GATE_K * sd)
                        if self.update_count < ANCHOR_GATE_WARMUP:
                            gate_open = torch.zeros_like(gate_open)
                        anchor_gate = torch.where(
                            gate_open,
                            torch.full_like(gap, ANCHOR_GATE_FLOOR),
                            torch.ones_like(gap))                          # [B]
                    kl_steer = (anchor_gate * kl_steer_ps).mean()
                    kl_accel = (anchor_gate * kl_accel_ps).mean()
                else:
                    kl_steer = kl_steer_ps.mean()
                    kl_accel = kl_accel_ps.mean()
                if torch.isnan(kl_accel).any().item(): kl_accel = torch.zeros_like(kl_accel)
                if torch.isnan(kl_steer).any().item(): kl_steer = torch.zeros_like(kl_steer)

                # actor loss components
                loss_comp_q_reward = (-lcb_q_reward).mean()
                loss_comp_ent_steer = (self.alpha_steer.detach() * log_prob_steer).mean()
                loss_comp_ent_accel = (self.alpha_accel.detach() * log_prob_accel).mean()
                loss_comp_kl_steer = self.kl_weight_steer.detach() * kl_steer
                loss_comp_kl_accel = self.kl_weight_accel.detach() * kl_accel

                grad_log_dict = {}
                if self.run_wandb and self.update_count % self.accumulation_steps == 0 and self.update_count % self.grad_policy_check_freq == 0:
                    loss_components_map = {
                        "Grads/q_reward": loss_comp_q_reward,
                        "Grads/ent_steer": loss_comp_ent_steer,
                        "Grads/ent_accel": loss_comp_ent_accel,
                        "Grads/kl_steer": loss_comp_kl_steer,
                        "Grads/kl_accel": loss_comp_kl_accel,
                        "Grads/cost": loss_comp_cost,
                        "Grads/caps_steer": loss_comp_caps,
                    }
                    for name, loss_tensor in loss_components_map.items():
                        self.policy_optimizer.zero_grad()
                        if loss_tensor.requires_grad:
                            self.scaler.scale(loss_tensor / self.accumulation_steps).backward(retain_graph=True)
                        grad_norm = self.get_unscaled_grad_norm(self.policy_optimizer)
                        grad_log_dict[name] = grad_norm
                    self.policy_optimizer.zero_grad()

                sac_actor_loss = (
                    loss_comp_q_reward +
                    loss_comp_ent_steer +
                    loss_comp_ent_accel
                )

                actor_loss = (sac_actor_loss
                             + loss_comp_kl_steer
                             + loss_comp_kl_accel
                             + loss_comp_cost
                             + loss_comp_caps)

                actor_loss = actor_loss / self.accumulation_steps

            self.scaler.scale(actor_loss).backward()
            if self.update_count % self.accumulation_steps == 0:
                self.scaler.unscale_(self.policy_optimizer)
                policy_grad_norm = torch.nn.utils.clip_grad_norm_(self.policy_net.parameters(), max_norm=ACTOR_GRAD_CLIP)
                self.scaler.step(self.policy_optimizer)
                self.policy_optimizer.zero_grad()
                self.critic_optimizer.zero_grad()
                # The cost-UCB term backprops into the cost critic too; drop those grads.
                self.cost_critic_optimizer.zero_grad()

            with torch.no_grad():
                policy_entropy_steer = steer_entropy.mean()
                policy_entropy_accel = accel_entropy.mean()

            current_batch_entropy = accel_entropy.mean().item()
            self.entropy_accel_scheduler.step(current_batch_entropy)
            self.target_entropy_accel = self.entropy_accel_scheduler.get_target()

            current_batch_entropy = steer_entropy.mean().item()
            self.entropy_steer_scheduler.step(current_batch_entropy)
            self.target_entropy_steer = self.entropy_steer_scheduler.get_target()

            # that drives lambda), not the stale buffer-average of Q_c. d and the dual's sensor must
            if self.online_cost_ema is not None \
                    and (self.cost_limit_scheduler.initialized
                         or self.online_cost_transitions >= ONLINE_COST_WARMUP_MIN_TRANSITIONS):
                if self.cost_limit_scheduler.initialized:
                    sched_signal = self.online_cost_ema
                else:
                    sched_signal = self.online_cost_baseline_perstep
                if sched_signal is not None:
                    # lam gates the ratchet (tighten only while the dual is quiet -- see
                    # COST_LIMIT_TIGHTEN_LAMBDA_MAX); it does not affect warmup/relax.
                    self.cost_limit_scheduler.step(sched_signal,
                                                   lam=float(self.lagrange_lambda.detach().item()))
            self.cost_limit = self.cost_limit_scheduler.get_target()

            # Update Alpha Steer
            with autocast(device_type='cuda', dtype=torch.bfloat16, enabled=USE_AMP):
                alpha_steer_loss = (self.log_alpha_steer * (steer_entropy.detach() - self.target_entropy_steer)).mean()
                alpha_steer_loss = alpha_steer_loss/self.accumulation_steps
            self.scaler.scale(alpha_steer_loss).backward()
            if self.update_count % self.accumulation_steps == 0:
                self.scaler.unscale_(self.alpha_steer_optimizer)
                self.scaler.step(self.alpha_steer_optimizer)
                self.alpha_steer_optimizer.zero_grad()

            # Update Alpha Accel
            with autocast(device_type='cuda', dtype=torch.bfloat16, enabled=USE_AMP):
                alpha_accel_loss = (self.log_alpha_accel * (accel_entropy.detach() - self.target_entropy_accel)).mean()
                alpha_accel_loss = alpha_accel_loss/self.accumulation_steps
            self.scaler.scale(alpha_accel_loss).backward()
            if self.update_count % self.accumulation_steps == 0:
                self.scaler.unscale_(self.alpha_accel_optimizer)
                self.scaler.step(self.alpha_accel_optimizer)
                self.alpha_accel_optimizer.zero_grad()

            # RELATIVE violation (kl/target - 1), same scale-invariant scheme as lambda: the raw gap
            if self.update_count % self.kl_delay_freq == 0 and self.update_count > self.critic_warm_up:
                with autocast(device_type='cuda', dtype=torch.bfloat16, enabled=USE_AMP):
                    kl_steer_rel = torch.log(
                        kl_steer.detach().clamp(min=1e-8) / max(self.target_kl_steer, 1e-6)
                    ).clamp(-3.0, 3.0)
                    kl_weight_steer_loss = -(self.log_kl_weight_steer * kl_steer_rel).mean()
                    kl_weight_steer_loss = kl_weight_steer_loss/self.accumulation_steps
                self.scaler.scale(kl_weight_steer_loss).backward()
                if self.update_count % self.accumulation_steps == 0:
                    self.scaler.unscale_(self.kl_weight_steer_optimizer)
                    self.scaler.step(self.kl_weight_steer_optimizer)
                    self.kl_weight_steer_optimizer.zero_grad()

                with autocast(device_type='cuda', dtype=torch.bfloat16, enabled=USE_AMP):
                    kl_accel_rel = torch.log(                                   # relative KL violation, clamped
                        kl_accel.detach().clamp(min=1e-8) / max(self.target_kl_accel, 1e-6)
                    ).clamp(-3.0, 3.0)
                    kl_weight_accel_loss = -(self.log_kl_weight_accel * kl_accel_rel).mean()
                    kl_weight_accel_loss = kl_weight_accel_loss/self.accumulation_steps
                self.scaler.scale(kl_weight_accel_loss).backward()
                if self.update_count % self.accumulation_steps == 0:
                    self.scaler.unscale_(self.kl_weight_accel_optimizer)
                    self.scaler.step(self.kl_weight_accel_optimizer)
                    self.kl_weight_accel_optimizer.zero_grad()

            if self.update_count % (self.policy_delay_freq * LAMBDA_DELAY_FREQ) == 0 \
                    and self.cost_limit_scheduler.initialized \
                    and self.online_cost_ema is not None:
                # RELATIVE (normalized by d) so the update is scale-invariant: the cost is O(1e-2)
                denom = max(self.cost_limit, 1e-6)
                violation = float(np.clip(
                    np.log(max(self.online_cost_ema, 1e-12) / denom), -3.0, 3.0))
                lambda_loss = -(self.log_lambda_online * violation)
                self.lambda_online_optimizer.zero_grad()
                lambda_loss.backward()
                self.lambda_online_optimizer.step()

        if self.update_count % self.accumulation_steps == 0:
            self.scaler.update()

        with torch.no_grad():
            self.log_alpha_steer.clamp_(-20.0, 2.0)
            self.log_alpha_accel.clamp_(-20.0, 2.0)
            self.log_kl_weight_steer.clamp_(-20.0, 4.6)   # exp(4.6) ~= 100: 10x more headroom for the
            self.log_kl_weight_accel.clamp_(-20.0, 4.6)    # smaller-magnitude location anchor (see kl_weight_*).
            self.log_lambda_online.clamp_(LOG_LAMBDA_MIN, LOG_LAMBDA_MAX)

        assert self.log_alpha_steer.requires_grad
        assert self.log_alpha_accel.requires_grad
        assert self.log_kl_weight_steer.requires_grad
        assert self.log_kl_weight_accel.requires_grad

        if self.update_count % self.accumulation_steps == 0 and self.update_count % self.target_delay_freq == 0:
            with torch.no_grad():
                for param, target_param in zip(self.critic.parameters(), self.critic_target.parameters()):
                    target_param.data.lerp_(param.data, self.tau)
                # CMDP: Polyak-update the cost target critic as well.
                for param, target_param in zip(self.cost_critic.parameters(), self.cost_critic_target.parameters()):
                    target_param.data.lerp_(param.data, self.tau)
                # E: Polyak-update the SHARED target box encoder ONCE (it is external to both critics, so the
                # two loops above never touched it).
                if USE_BOX_CRITIC:
                    for param, target_param in zip(self.shared_box_encoder.parameters(), self.shared_box_encoder_target.parameters()):
                        target_param.data.lerp_(param.data, self.tau)

        # --- UPER Priority Update (reward stream; same priority written to both buffer streams) ---
        with torch.no_grad():
            unnormalized_q_r_quantiles = self.critic.unnormalize(current_q_r_quantiles)

            q_r_means = unnormalized_q_r_quantiles.mean(dim=-1)
            epistemic_var_r = torch.var(q_r_means, dim=0)
            epistemic_std_r = torch.sqrt(epistemic_var_r)

            aleatoric_var_r = torch.var(unnormalized_q_r_quantiles, dim=-1).mean(dim=0)
            aleatoric_std_r_clamped = torch.clamp(torch.sqrt(aleatoric_var_r), min=1e-6)

            learnability_ratio_r = epistemic_std_r / aleatoric_std_r_clamped

            sample_ages = replay_buffer.ages[sample_indices]
            if not self.gpu_replay_buffer:
                sample_ages = torch.from_numpy(sample_ages).pin_memory().to(self.device, non_blocking=True)
            age = (self.update_count - sample_ages).float().clamp(min=1.0)
            age_penalty = torch.log(1.0 + age / 10000.0).clamp(min=1.0) # Scales up as age increases

            new_priorities_r = torch.log(1 + learnability_ratio_r)/age_penalty
            new_priorities_r = torch.clamp(new_priorities_r, min=UPER_EPSILON)

            # finds uncertain (typically the rare danger/collision ones) instead of a reward copy.
            unnormalized_q_c_quantiles = self.cost_critic.unnormalize(current_q_c_quantiles)

            q_c_means_p = unnormalized_q_c_quantiles.mean(dim=-1)
            epistemic_std_c = torch.sqrt(torch.var(q_c_means_p, dim=0))

            aleatoric_var_c = torch.var(unnormalized_q_c_quantiles, dim=-1).mean(dim=0)
            aleatoric_std_c_clamped = torch.clamp(torch.sqrt(aleatoric_var_c), min=1e-6)

            learnability_ratio_c = epistemic_std_c / aleatoric_std_c_clamped

            new_priorities_c = torch.log(1 + learnability_ratio_c)/age_penalty
            new_priorities_c = torch.clamp(new_priorities_c, min=UPER_EPSILON)

            if not self.gpu_replay_buffer:
                new_priorities_r_np = new_priorities_r.detach().cpu().numpy()
                new_priorities_c_np = new_priorities_c.detach().cpu().numpy()
                replay_buffer.update_priorities(sample_indices, original_ids,
                                                new_priorities_r_np, new_priorities_c_np)
            else:
                replay_buffer.update_priorities(sample_indices, original_ids,
                                                new_priorities_r, new_priorities_c)

        if self.gpu_replay_buffer and SAFETY_MVE_ENABLED:
            refresh_log = self._refresh_safety_cache(
                replay_buffer, sample_indices, original_ids, cost_next_state, cost_next_route,
                cost_burnin, cost_burnin_mask, cost_landing_valid)
            rssm_log.update(refresh_log)

        nan_check(task_reward, "task_reward")
        nan_check(next_log_prob_steer, "next_log_prob_steer")
        nan_check(next_log_prob_accel, "next_log_prob_accel")
        nan_check(target_q_reward, "target_q_reward")

        if self.update_count % LOG_INTERVAL == 0:
            log_dict = {
                "General/step_count": self.update_count,

                # Critic-trained latent denoiser grad norm (0 while inactive/in warmup).
                # Grouped under Gradients/ alongside the critic/cost/actor norms for one-glance comparison.
                "Gradients/denoiser_grad_norm": getattr(self, 'denoiser_grad_norm', 0.0),
                "Denoiser/active": float(getattr(self, '_denoise_active', False)),

                "Params/target_kl_steer": self.target_kl_steer,
                "Params/target_kl_accel": self.target_kl_accel,

                "Normalization/state_mean": self.state_normalizer.mean.mean().item(),
                "Normalization/state_var": self.state_normalizer.var.mean().item(),

                "Loss/bellman_reward": bellman_loss_r.item(),
                "Loss/critic_total_reward": critic_loss_r.item(),

                "Loss/u_r_mean": u_r.mean().item(),
                "Loss/u_r_max": u_r.max().item(),
                "Loss/u_r_min": u_r.min().item(),

                "Reward/raw_mean": reward_extrinsic_raw.mean().item(),
                "Reward/raw_min": reward_extrinsic_raw.min().item(),
                "Reward/raw_max": reward_extrinsic_raw.max().item(),
                "Reward/total_task_reward": task_reward.mean().item(),

                "Cost/raw_mean": cost_raw.mean().item(),
                "Cost/raw_min": cost_raw.min().item(),
                "Cost/raw_max": cost_raw.max().item(),

                # --- CMDP: cost critic + constraint diagnostics ---
                "Loss/bellman_cost": bellman_loss_c.item(),
                "Loss/critic_total_cost": cost_critic_loss.item(),
                "Loss/u_c_mean": u_c.mean().item(),
                "CMDP/Lagrange_Lambda": self.lagrange_lambda.detach().item(),
                "CMDP/Cost_Limit": self.cost_limit,
                "CMDP/Online_Cost_EMA_perstep": (self.online_cost_ema if self.online_cost_ema is not None else 0.0),
                "CMDP/Online_Constraint_Violation": ((self.online_cost_ema - self.cost_limit)
                                                     if self.online_cost_ema is not None else 0.0),
                "CMDP/Online_Cost_Rate": (self.online_cost_rate if self.online_cost_rate is not None else 0.0),
                "CMDP/Online_Speed_EMA": (self.online_dist_ema if self.online_dist_ema is not None else 0.0),
                # --- cost-budget curriculum diagnostics ---
                "CMDP/Cost_Limit_Floor": self.cost_limit_scheduler.min_cost_limit,
                "CMDP/Cost_Limit_Initialized": 1.0 if self.cost_limit_scheduler.initialized else 0.0,
                # Fresh transitions folded in; warmup baseline gated on this >= WARMUP_MIN_TRANSITIONS.
                "CMDP/Online_Cost_Transitions": float(self.online_cost_transitions),
                "CMDP/Warmup_Gate_Frac": min(1.0, self.online_cost_transitions
                                             / float(ONLINE_COST_WARMUP_MIN_TRANSITIONS)),
                # against Online_Cost_EMA_perstep at seeding time: they must AGREE. A large gap means
                "CMDP/Online_Cost_Baseline_perstep": (self.online_cost_baseline_perstep
                                                      if self.online_cost_baseline_perstep is not None else 0.0),
                "CMDP/Online_EMA_Bias": float(self._ema_bias),
                "CMDP/Sensor_Over_Baseline": (
                    float(self.online_cost_ema / self.online_cost_baseline_perstep)
                    if (self.online_cost_ema is not None
                        and self.online_cost_baseline_perstep not in (None, 0.0)) else 1.0),
                # Watch signal (per-metre companion of the above).
                "CMDP/Online_Cost_Rate_Baseline": (self.online_cost_rate_baseline
                                                   if self.online_cost_rate_baseline is not None else 0.0),
                "CMDP/Cost_Limit_EMA_Cost": self.cost_limit_scheduler.ema_cost,
                "CMDP/Cost_Limit_MeetTime": float(self.cost_limit_scheduler.meet_time),
                "CMDP/Qc_target_mean": target_q_cost.mean().item(),
                "Loss/dist_critic": self.last_dist_loss,
                "CMDP/Qd_critic_mean": self.last_qd_mean,
                "Gradients/cost_critic_grad_norm": cost_critic_grad_norm.item(),
                "UPER/cost_epistemic": epistemic_std_c.mean().item(),
                "UPER/cost_aleatoric": aleatoric_std_c_clamped.mean().item(),
                "UPER/cost_learnability": learnability_ratio_c.mean().item(),
                "UPER/batch_priority_cost": new_priorities_c.mean().item(),

                "Gradients/critic_grad_norm": critic_grad_norm.item(),

                "UPER/reward_epistemic": epistemic_std_r.mean().item(),
                "UPER/reward_aleatoric": aleatoric_std_r_clamped.mean().item(),
                "UPER/reward_learnability": learnability_ratio_r.mean().item(),
                "UPER/batch_age": age.mean().item(),
                "UPER/batch_priority_reward": new_priorities_r.mean().item(),

                "UPER/IS_Weight_Mean_r": is_weight_r.mean().item(),
                "UPER/IS_Weight_Min_r": is_weight_r.min().item(),
            }

            for key, value in log_reward.items():
                log_dict[f"Reward_Components/{key}"] = value

            # RSSM world-model + MVE diagnostics (empty dict when RSSM_ENABLED=False)
            log_dict.update(rssm_log)

            if self.update_count % self.policy_delay_freq == 0 and self.update_count > self.critic_warm_up:
                log_dict.update({
                    "Policy/accel_logit_brake":   rl_accel_dist.logits[:,0].mean().item(),
                    "Policy/accel_logit_coast":   rl_accel_dist.logits[:,1].mean().item(),
                    "Policy/accel_logit_thr03":   rl_accel_dist.logits[:,2].mean().item(),
                    "Policy/accel_logit_thr07":   rl_accel_dist.logits[:,3].mean().item(),
                    "Policy/accel_logit_thr10":   rl_accel_dist.logits[:,4].mean().item(),
                    "Policy/accel_logit_reverse": rl_accel_dist.logits[:,5].mean().item(),
                    # Probabilities too: logits are only meaningful up to a shared additive
                    # constant, so the softmax is what actually says how often reverse is chosen.
                    "Policy/accel_prob_brake":    rl_accel_dist.probs[:,0].mean().item(),
                    "Policy/accel_prob_reverse":  rl_accel_dist.probs[:,5].mean().item(),
                    "Policy/steer_alpha": rl_steer_dist.concentration1.mean().item(),
                    "Policy/steer_beta": rl_steer_dist.concentration0.mean().item(),
                    "Policy/entropy_steer": policy_entropy_steer.item(),
                    "Policy/entropy_accel": policy_entropy_accel.item(),

                    "Loss/actor_total": actor_loss.item(),
                    "Loss/actor_sac": sac_actor_loss.item(),
                    "Loss/actor_q_reward": loss_comp_q_reward.item(),
                    "Loss/caps_steer": loss_comp_caps.item(),
                    "Loss/caps_steer_raw": caps_steer_raw.item(),
                    "Policy/steer_mode_jerk_rms": caps_steer_raw.sqrt().item(),
                    "Loss/kl_steer": kl_steer.item(),
                    "Loss/kl_accel": kl_accel.item(),
                    "Anchor/gate_open_frac": (1.0 - (anchor_gate.mean().item() - ANCHOR_GATE_FLOOR)
                                              / max(1.0 - ANCHOR_GATE_FLOOR, 1e-9))
                                             if anchor_gate is not None else 0.0,
                    "CMDP/Gate_S2T_Frac": float(cost_gate.mean().item()),
                    "Buffer/Forced_New": float(getattr(replay_buffer, 'last_forced_new', 0)),
                    "Buffer/Priority_Elite": float(getattr(replay_buffer, 'last_priority_elite', 0)),
                    "Anchor/sqdist_steer_raw": kl_steer_ps.mean().item(),
                    "Anchor/kl_accel_raw_nats": kl_accel_ps.mean().item(),
                    "Loss/alpha_steer": alpha_steer_loss.item(),
                    "Loss/alpha_accel": alpha_accel_loss.item(),

                    "Q_Values/reward_norm_mean": q_r_new_all_critics_norm.mean().item(),
                    "Q_Values/reward_unnorm_mean": q_r_new_mean.mean().item(),
                    "Q_Values/reward_unnorm_std": q_r_new_std.mean().item(),

                    # Conformal trust region (healthy excess_frac ~ 0.25-0.35; see CTR_* constants)
                    "CTR/q_hat": (self.ctr_qhat.item() if self.ctr_qhat is not None else 0.0),
                    "CTR/excess_frac": ctr_excess_frac.item(),
                    "CTR/sigma_mean": q_r_new_std.mean().item(),

                    "Q_Values/cost_unnorm_mean": q_c_new_mean.mean().item(),
                    "Q_Values/cost_unnorm_std": q_c_new_std.mean().item(),
                    "Loss/actor_cost": loss_comp_cost.item(),
                    "CMDP/UCB_Cost_Q_Mean": ucb_q_cost.mean().item(),
                    "CMDP/Qd_actor_mean": q_d_new_mean.mean().item(),
                    "CMDP/Dist_Credit_Mean": dist_credit.mean().item(),
                    "CMDP/Dist_Credit_Frac": (dist_credit.mean() / ucb_q_cost.mean().clamp(min=1e-6)).item(),
                    "CMDP/Cost_Surrogate_Mean": cost_surrogate.mean().item(),
                    "CMDP/d_eff": d_eff,
                    "CMDP/Gate_Mean": cost_gate.mean().item(),
                    "CMDP/Gate_Frac_Engaged": (cost_gate > 0.5).float().mean().item(),
                    "CMDP/Gate_Lambda_Eff_Mean": lam_eff.mean().item(),
                    # Q_c is on a discounted-return scale and d on a per-step-cost scale; the
                    # comparable constraint gap is CMDP/Online_Constraint_Violation.

                    "Gradients/policy_grad_norm": policy_grad_norm.item(),

                    "Params/alpha_steer": self.alpha_steer.detach().item(),
                    "Params/alpha_accel": self.alpha_accel.detach().item(),
                    "Params/target_entropy_accel": self.target_entropy_accel,
                    "Params/target_entropy_steer": self.target_entropy_steer,

                    "lr/actor": self.policy_optimizer.param_groups[0]['lr'],
                    "lr/critic": self.critic_optimizer.param_groups[0]['lr'],
                })
                log_dict.update(grad_log_dict)

            if self.update_count % self.policy_delay_freq == 0 and self.update_count % self.kl_delay_freq == 0 and self.update_count > self.critic_warm_up:
                log_dict.update({
                    "Params/kl_weight_steer": self.kl_weight_steer.detach().item(),
                    "Loss/kl_weight_steer": kl_weight_steer_loss.item(),
                    "Params/kl_weight_accel": self.kl_weight_accel.detach().item(),
                    "Loss/kl_weight_accel": kl_weight_accel_loss.item(),
                })

            self.run_wandb.log(log_dict)

        if self.update_count % self.accumulation_steps == 0:
            self.critic_lr_scheduler.step()
            self.cost_critic_lr_scheduler.step()
            if self.denoiser_lr_scheduler is not None:
                self.denoiser_lr_scheduler.step()   # denoiser LR rides the critic cosine
            if USE_BOX_CRITIC:
                self.box_lr_scheduler.step()
            if self.update_count % self.policy_delay_freq == 0 and self.update_count > self.critic_warm_up:
                self.actor_lr_scheduler.step()

        self.update_count += 1

    def policy_trainable_state_dict(self):
        full_state_dict = self.policy_net._orig_mod.state_dict()

        # 2. Filter for only parameters that have requires_grad = True
        # We use the underlying parameters to identify which keys to keep
        trainable_keys = {
            name for name, param in self.policy_net._orig_mod.named_parameters() 
            if param.requires_grad
        }

        # 3. Create the filtered dict
        trainable_state_dict = {
            k: v for k, v in full_state_dict.items() if k in trainable_keys
        }   
        return trainable_state_dict

    def save_policy(self, filepath):
        sd = self.policy_trainable_state_dict()
        if self.rssm is not None:
            # safety_horizon_head is learner-only auxiliary supervision; rollout workers do not
            # need it, so it is stripped from the actor payload.
            sd['rssm_state_dict'] = {
                k: v for k, v in self.rssm.state_dict().items()
                if not k.startswith('safety_horizon_head.')}
            sd['rssm_burnin_k'] = RSSM_BURNIN_K
        tmp = filepath + ".tmp"
        torch.save(sd, tmp)
        os.replace(tmp, filepath)

    def save_checkpoint(self, filepath):
        checkpoint = {
            'rssm_burnin_k': RSSM_BURNIN_K,
            'policy_net_state_dict': self.policy_trainable_state_dict(),
            'critic_state_dict': self.critic._orig_mod.state_dict(),
            'critic_target_state_dict': self.critic_target._orig_mod.state_dict(),
            'policy_optimizer_state_dict': self.policy_optimizer.state_dict(),
            'critic_optimizer_state_dict': self.critic_optimizer.state_dict(),

            # --- CMDP: cost critic + Lagrange multiplier state ---
            'cost_critic_state_dict': self.cost_critic._orig_mod.state_dict(),
            'cost_critic_target_state_dict': self.cost_critic_target._orig_mod.state_dict(),
            'cost_critic_optimizer_state_dict': self.cost_critic_optimizer.state_dict(),
            # Critic-trained latent denoiser optimizer (the denoiser weights themselves ride in
            # policy_net_state_dict).
            'denoiser_optimizer_state_dict': (self.denoiser_optimizer.state_dict()
                                              if self.denoiser_optimizer is not None else None),
            'cost_critic_lr_scheduler_state_dict': self.cost_critic_lr_scheduler.state_dict(),
            'dual_ascent_optimizer': 'sgd',
            'log_lambda_online': self.log_lambda_online,
            'lambda_online_optimizer_state_dict': self.lambda_online_optimizer.state_dict(),
            'online_cost_ema': self.online_cost_ema,
            # Distance-normalization state (numerator/denominator sums + speed EMA).
            'online_dist_ema': self.online_dist_ema,
            'online_ema_cost_raw': self._ema_cost_raw,
            'online_ema_dist_raw': self._ema_dist_raw,
            'online_ema_bias': self._ema_bias,
            'online_cost_cumsum': self.online_cost_cumsum,
            'online_dist_cumsum': self.online_dist_cumsum,
            'online_cost_transitions': self.online_cost_transitions,

            'actor_lr_scheduler_state_dict': self.actor_lr_scheduler.state_dict(),
            'critic_lr_scheduler_state_dict': self.critic_lr_scheduler.state_dict(),

            'update_count': self.update_count,
            'log_alpha_steer': self.log_alpha_steer,
            'alpha_steer_optimizer_state_dict': self.alpha_steer_optimizer.state_dict(),
            'log_alpha_accel': self.log_alpha_accel,
            'alpha_accel_optimizer_state_dict': self.alpha_accel_optimizer.state_dict(),
            'log_kl_weight_steer': self.log_kl_weight_steer,
            'kl_weight_steer_optimizer_state_dict': self.kl_weight_steer_optimizer.state_dict(),
            'log_kl_weight_accel': self.log_kl_weight_accel,
            'kl_weight_accel_optimizer_state_dict': self.kl_weight_accel_optimizer.state_dict(),
            'state_normalizer_state_dict': (self.state_normalizer.mean, self.state_normalizer.var, self.state_normalizer.count),
            'reward_normalizer_state_dict': (self.reward_normalizer.mean, self.reward_normalizer.var, self.reward_normalizer.count),
            'entropy_accel_scheduler_state_dict': self.entropy_accel_scheduler.state_dict(),
            'entropy_steer_scheduler_state_dict': self.entropy_steer_scheduler.state_dict(),
            # Cost-budget curriculum state (units: per-step cost).
            'cost_limit_scheduler_online_state_dict': self.cost_limit_scheduler.state_dict(),
            # Conformal trust-region frontier (None until the first actor step seeds it).
            'ctr_qhat': (float(self.ctr_qhat.item()) if self.ctr_qhat is not None else None),
            # --- Level-1 RSSM world model + its optimizer (None when RSSM_ENABLED=False) ---
            'rssm_state_dict': (self.rssm.state_dict() if self.rssm is not None else None),
            'rssm_optimizer_state_dict': (self.rssm_optimizer.state_dict()
                                          if self.rssm_optimizer is not None else None),
            'grad_scaler_state_dict': self.scaler.state_dict(),
        }
        # Denoiser LR scheduler: rides the critic cosine; guarded like its optimizer.
        if self.denoiser_lr_scheduler is not None:
            checkpoint['denoiser_lr_scheduler_state_dict'] = self.denoiser_lr_scheduler.state_dict()
        # E: shared box encoder (+ Polyak target) and its dedicated optimizer/scheduler.
        if USE_BOX_CRITIC:
            checkpoint['shared_box_encoder_state_dict'] = self.shared_box_encoder.state_dict()
            checkpoint['shared_box_encoder_target_state_dict'] = self.shared_box_encoder_target.state_dict()
            checkpoint['box_optimizer_state_dict'] = self.box_optimizer.state_dict()
            checkpoint['box_lr_scheduler_state_dict'] = self.box_lr_scheduler.state_dict()
        temp_filepath = filepath + ".tmp"
        torch.save(checkpoint, temp_filepath)
        os.replace(temp_filepath, filepath)

    def _load_from_checkpoint(self, checkpoint):
        """Loads all kept agent state from an already-loaded checkpoint dict (raises on missing keys)."""
        self.scaler.load_state_dict(checkpoint['grad_scaler_state_dict'])

        self.policy_optimizer.load_state_dict(checkpoint['policy_optimizer_state_dict'])
        self.critic_optimizer.load_state_dict(checkpoint['critic_optimizer_state_dict'])
        self.alpha_steer_optimizer.load_state_dict(checkpoint['alpha_steer_optimizer_state_dict'])
        self.alpha_accel_optimizer.load_state_dict(checkpoint['alpha_accel_optimizer_state_dict'])
        # Dual-ascent optimizer states are never restored: momentum-free SGD is stateless.
        dual_sgd = checkpoint.get('dual_ascent_optimizer') == 'sgd'

        if self.rssm is not None:
            if checkpoint.get('rssm_state_dict') is None:
                raise RuntimeError("RSSM_ENABLED=True but the checkpoint has no 'rssm_state_dict' "
                                   "(pre-RSSM checkpoint). Start a FRESH run (clean GREG_RL_Trainer/model_pth "
                                   "+ replay_buffer.pkl) or set RSSM_ENABLED=False.")
            rssm_missing, rssm_unexpected = self.rssm.load_state_dict(
                checkpoint['rssm_state_dict'], strict=False)
            if rssm_missing or rssm_unexpected:
                print("🧭 [Migration] RSSM sparse-safety heads initialized fresh; "
                      f"missing={rssm_missing}, unexpected={rssm_unexpected}")
            if self.rssm_optimizer is not None and checkpoint.get('rssm_optimizer_state_dict') is not None:
                try:
                    self.rssm_optimizer.load_state_dict(checkpoint['rssm_optimizer_state_dict'])
                except (ValueError, RuntimeError) as e:
                    print(f"🧭 [Migration] RSSM optimizer reset for new safety head: {e}")
            # RSSM_BURNIN_COMPILE compiles the BOUND METHOD self.rssm.burn_in, never the module, so
            self._burnin_compiled = None

        # guards on dtype/shape/device/requires_grad, never on values, so there is nothing to
        self.policy_net._orig_mod.load_state_dict(checkpoint['policy_net_state_dict'], strict=False)
        # a legitimate match that must not be rejected.
        _ck_dueling = any('v_quantile_head' in k for k in checkpoint['critic_state_dict'].keys())
        _net_dueling = hasattr(self.critic._orig_mod.critic_net, 'v_quantile_head')
        if _ck_dueling != _net_dueling:
            raise RuntimeError(
                f"Checkpoint/critic head mismatch: checkpoint dueling={_ck_dueling}, "
                f"model dueling={_net_dueling}. Start a FRESH run: clear GREG_RL_Trainer/model_pth/*.pth "
                f"and replay_buffer.pkl, and set a new WANDB_RUN_ID.")
        self.critic._orig_mod.load_state_dict(checkpoint['critic_state_dict'])
        self.critic_target._orig_mod.load_state_dict(checkpoint['critic_target_state_dict'])

        # --- CMDP: cost critic ---
        if 'cost_critic_state_dict' in checkpoint:
            self.cost_critic._orig_mod.load_state_dict(checkpoint['cost_critic_state_dict'])
            self.cost_critic_target._orig_mod.load_state_dict(checkpoint['cost_critic_target_state_dict'])
            self.cost_critic_optimizer.load_state_dict(checkpoint['cost_critic_optimizer_state_dict'])
            self.cost_critic_lr_scheduler.load_state_dict(checkpoint['cost_critic_lr_scheduler_state_dict'])
        else:
            print("⚠️ [Agent] Checkpoint has no cost critic. Cost critic starts fresh.")

        if self.denoiser_optimizer is not None and checkpoint.get('denoiser_optimizer_state_dict') is not None:
            self.denoiser_optimizer.load_state_dict(checkpoint['denoiser_optimizer_state_dict'])
        # The denoiser LR rides the critic cosine schedule; fall back to it when absent.
        if self.denoiser_lr_scheduler is not None:
            if checkpoint.get('denoiser_lr_scheduler_state_dict') is not None:
                self.denoiser_lr_scheduler.load_state_dict(checkpoint['denoiser_lr_scheduler_state_dict'])
            else:
                self.denoiser_lr_scheduler.load_state_dict(checkpoint['critic_lr_scheduler_state_dict'])
                for g, lr in zip(self.denoiser_optimizer.param_groups,
                                 self.denoiser_lr_scheduler._last_lr):
                    g['lr'] = lr
                print(f"🧹 [Agent] No denoiser LR scheduler in checkpoint: LR aligned to the critic cosine "
                      f"(lr -> {self.denoiser_optimizer.param_groups[0]['lr']:.2e}).")

        if 'log_lambda_online' in checkpoint and not RESET_ONLINE_DUAL_ON_LOAD:
            if dual_sgd:
                # lambda VALUE resumes; its SGD optimizer state is not restored.
                self.log_lambda_online.data.copy_(checkpoint['log_lambda_online'])
            else:
                print("🧹 [Agent] No SGD dual state in checkpoint: lambda restarts at "
                      "exp(LOG_LAMBDA_INIT). The online cost EMA/cumsums are measurements, "
                      "not dual state, and are kept.")
            self.online_cost_ema = checkpoint.get('online_cost_ema', None)
            # Distance-normalization state.
            self.online_dist_ema = checkpoint.get('online_dist_ema', None)
            if 'online_ema_bias' in checkpoint:
                self._ema_cost_raw = float(checkpoint.get('online_ema_cost_raw', self._ema_cost_raw))
                self._ema_dist_raw = float(checkpoint.get('online_ema_dist_raw', self._ema_dist_raw))
                self._ema_bias = float(checkpoint.get('online_ema_bias', self._ema_bias))
            self.online_cost_cumsum = 0.0
            self.online_dist_cumsum = 0.0
            self.online_cost_transitions = 0
        elif RESET_ONLINE_DUAL_ON_LOAD:
            print("🧹 [Agent] RESET_ONLINE_DUAL_ON_LOAD=True: lambda, its optimizer, and the online "
                  "cost EMA start FRESH (cost critic + policy kept).")
        else:
            print("🧹 [Agent] No online dual variable in checkpoint: lambda, its optimizer, and the "
                  "online cost EMA start fresh. Cost critic weights kept.")

        # Shared box encoder + Polyak target + its optimizer.
        if USE_BOX_CRITIC and 'shared_box_encoder_state_dict' in checkpoint:
            self.shared_box_encoder.load_state_dict(checkpoint['shared_box_encoder_state_dict'])
            self.shared_box_encoder_target.load_state_dict(checkpoint['shared_box_encoder_target_state_dict'])
            self.box_optimizer.load_state_dict(checkpoint['box_optimizer_state_dict'])
            self.box_lr_scheduler.load_state_dict(checkpoint['box_lr_scheduler_state_dict'])
        elif USE_BOX_CRITIC:
            print("⚠️ [Agent] No shared box encoder in checkpoint. It starts fresh.")

        self.actor_lr_scheduler.load_state_dict(checkpoint['actor_lr_scheduler_state_dict'])
        self.critic_lr_scheduler.load_state_dict(checkpoint['critic_lr_scheduler_state_dict'])

        self.log_alpha_steer.data.copy_(checkpoint['log_alpha_steer'])
        self.log_alpha_accel.data.copy_(checkpoint['log_alpha_accel'])
        if dual_sgd:
            self.log_kl_weight_steer.data.copy_(checkpoint['log_kl_weight_steer'])
            self.log_kl_weight_accel.data.copy_(checkpoint['log_kl_weight_accel'])
        else:
            print("🧹 [Agent] No SGD dual state in checkpoint: KL weights restart at exp(0)=1.")

        self.update_count = checkpoint['update_count']
        self._denoise_active = EMBED_DENOISE_ENABLED and (self.update_count > self.critic_warm_up)
        # Conformal trust-region frontier; when absent the first actor step re-seeds it from a
        # batch percentile (the EMA converges within ~100 actor steps).
        _ctr = checkpoint.get('ctr_qhat', None)
        self.ctr_qhat = (torch.tensor(float(_ctr), device=self.device) if _ctr is not None else None)
        self.state_normalizer.mean, self.state_normalizer.var, self.state_normalizer.count = checkpoint['state_normalizer_state_dict']
        self.reward_normalizer.mean, self.reward_normalizer.var, self.reward_normalizer.count = checkpoint['reward_normalizer_state_dict']

        self.entropy_accel_scheduler.load_state_dict(checkpoint['entropy_accel_scheduler_state_dict'])
        self.entropy_steer_scheduler.load_state_dict(checkpoint['entropy_steer_scheduler_state_dict'])

        # Cost-budget curriculum (per-step-cost units).
        if 'cost_limit_scheduler_online_state_dict' in checkpoint and not RESET_ONLINE_DUAL_ON_LOAD:
            self.cost_limit_scheduler.load_state_dict(checkpoint['cost_limit_scheduler_online_state_dict'])
            self.cost_limit = self.cost_limit_scheduler.get_target()
        else:
            print("🧹 [Agent] Cost-limit scheduler starts FRESH (RESET_ONLINE_DUAL_ON_LOAD or no online "
                  "scheduler in checkpoint): warmup re-measures the baseline online cost in per-step "
                  "units with the current floor + relative gate before constraining.")


    def load_checkpoint_critic(self, filepath):
        try:
            if not os.path.exists(filepath):
                raise FileNotFoundError("Checkpoint not found.")

            print(f"🧠 [Agent] Attempting to load critic checkpoint from {filepath}...")
            checkpoint = torch.load(filepath, map_location="cuda", weights_only=False)

            self.scaler.load_state_dict(checkpoint['grad_scaler_state_dict'])
            self.critic_optimizer.load_state_dict(checkpoint['critic_optimizer_state_dict'])
            self.critic._orig_mod.load_state_dict(checkpoint['critic_state_dict'])
            self.critic_target._orig_mod.load_state_dict(checkpoint['critic_target_state_dict'])
            self.critic_lr_scheduler.load_state_dict(checkpoint['critic_lr_scheduler_state_dict'])

            # E: keep the shared box encoder consistent with the loaded critics.
            if USE_BOX_CRITIC and 'shared_box_encoder_state_dict' in checkpoint:
                self.shared_box_encoder.load_state_dict(checkpoint['shared_box_encoder_state_dict'])
                self.shared_box_encoder_target.load_state_dict(checkpoint['shared_box_encoder_target_state_dict'])
                self.box_optimizer.load_state_dict(checkpoint['box_optimizer_state_dict'])
                self.box_lr_scheduler.load_state_dict(checkpoint['box_lr_scheduler_state_dict'])

            self.update_count = checkpoint['update_count']
            self.state_normalizer.mean, self.state_normalizer.var, self.state_normalizer.count = checkpoint['state_normalizer_state_dict']
            self.reward_normalizer.mean, self.reward_normalizer.var, self.reward_normalizer.count = checkpoint['reward_normalizer_state_dict']

            print(f"🧠 [Agent] Critic checkpoint loaded successfully.")
        except Exception as e:
            print(f"❌ [Agent] Error loading critic checkpoint: {e}. Continuing without loading.")

    def load_checkpoint(self, filepath):
        try:
            if not os.path.exists(filepath):
                raise FileNotFoundError("Primary checkpoint not found.")

            print(f"🧠 [Agent] Attempting to load primary checkpoint from {filepath}...")
            checkpoint = torch.load(filepath, map_location="cuda", weights_only=False)
            self._load_from_checkpoint(checkpoint)
            print(f"🧠 [Agent] Primary checkpoint loaded successfully. Resuming from update count: {self.update_count}")
            return

        except Exception as e:
            print(f"❌ [Agent] Error loading primary checkpoint: {e}. Attempting to load versioned backups.")

            try:
                all_files = os.listdir(MODEL_DIR)
                versioned_checkpoints = sorted(
                    [f for f in all_files if f.startswith('sac_checkpoint_') and f.endswith('.pth')],
                    reverse=True
                )

                if not versioned_checkpoints:
                    print("🧠 [Agent] No versioned backups found. Starting with fresh weights.")
                    return

                for backup_file in versioned_checkpoints:
                    backup_filepath = os.path.join(MODEL_DIR, backup_file)
                    try:
                        print(f"🧠 [Agent] Trying backup: {backup_file}...")
                        checkpoint = torch.load(backup_filepath, map_location="cuda", weights_only=False)
                        self._load_from_checkpoint(checkpoint)
                        print(f"✅ [Agent] Versioned backup '{backup_file}' loaded successfully. Resuming from update count: {self.update_count}")
                        return
                    except Exception as backup_e:
                        print(f"❌ [Agent] Failed to load backup '{backup_file}': {backup_e}")

                print("🧠 [Agent] All versioned backups failed to load. Starting with fresh weights.")

            except Exception as final_e:
                print(f"❌ [Agent] A critical error occurred during backup search: {final_e}. Starting with fresh weights.")

class LearnerReplayBuffer:
    """
    A CPU-based replay buffer using NumPy with prefetching and versioning.
    1.  Prefetching: A background thread prepares training batches in advance.
    2.  Transition Versioning: Prevents race conditions during priority updates.
    """
    def __init__(self, capacity, state_dim, action_dim, save_path='GREG_RL_Trainer/replay_buffer.pkl', prefetch_size=5, batch_size=1024):
        self.save_path = save_path
        self.capacity = capacity

        # Core data storage using NumPy arrays
        self.pre_states = np.zeros((capacity, state_dim), dtype=np.float32)
        self.states = np.zeros((capacity, state_dim), dtype=np.float32)
        self.actions = np.zeros((capacity, action_dim), dtype=np.float32)
        self.rewards = np.zeros((capacity, NUM_REWARD_TERM), dtype=np.float32)
        self.next_states = np.zeros((capacity, state_dim), dtype=np.float32)
        self.action_queue = np.zeros((capacity, action_dim*ACTION_QUEUE_SIZE), dtype=np.float32)
        self.action_queue_next = np.zeros((capacity, action_dim*ACTION_QUEUE_SIZE), dtype=np.float32)
        self.dones = np.zeros((capacity, 1), dtype=np.float32)

        # Prioritized replay metadata
        self.priorities_reward = np.zeros(capacity, dtype=np.float32)
        self.priorities_cost = np.zeros(capacity, dtype=np.float32)
        self.ages = np.zeros(capacity, dtype=np.int64)
        
        self.max_priority_reward = 1.0
        self.max_priority_cost = 1.0

        self.sampling_ratio  = SAMPLE_RATIO_REWARD_TO_COST

        # Versioning System
        self.transition_ids = np.zeros(capacity, dtype=np.int64)
        self.id_counter = 0

        self.ptr, self.size, self.max_priority = 0, 0, 1.0
        self.beta_is = 0.4

        # Prefetching Mechanism
        self.prefetch_queue = queue.Queue(maxsize=prefetch_size)
        self.stop_event = threading.Event()
        self.prefetch_thread = threading.Thread(
            target=self._prefetch_worker,
            args=(batch_size,),
            daemon=True
        )
        self.prefetch_thread.start()
        print("🚀 [CPU ReplayBuffer] Prefetching worker started.")

        self.load_from_disk()

    def _prefetch_worker(self, batch_size):
        """Worker function to prepare batches in the background."""
        while not self.stop_event.is_set():
            if self.size < UPER_CANDIDATE_SET_SIZE or self.prefetch_queue.full():
                time.sleep(0.05)
                continue

            # 1. UPER Sampling: Create candidate set
            num_reward_samples = int(UPER_CANDIDATE_SET_SIZE * self.sampling_ratio)
            num_cost_samples = UPER_CANDIDATE_SET_SIZE - num_reward_samples

            # 2. Sample from Reward Priority distribution
            priorities_r = self.priorities_reward[:self.size]**UPER_ALPHA + UPER_EPSILON
            probs_r = priorities_r / priorities_r.sum()
            reward_indices = np.random.choice(self.size, size=num_reward_samples, p=probs_r, replace=True)

            # 3. Sample from Cost Priority distribution
            current_priorities_c = self.priorities_cost[:self.size]**UPER_ALPHA + UPER_EPSILON
            probs_c = current_priorities_c / current_priorities_c.sum()
            cost_indices = np.random.choice(self.size, size=num_cost_samples, p=probs_c, replace=True)

            # 4. Combine the indices into one batch
            candidate_indices = np.concatenate([reward_indices, cost_indices])

            # 2. Diversity-Based Sub-sampling using cosine similarity
            candidate_states = self.states[candidate_indices]
            final_indices_in_candidate_set = self._get_diverse_indices(candidate_states, batch_size)
            final_indices = candidate_indices[final_indices_in_candidate_set]

            prob_r = priorities_r[final_indices] / priorities_r.sum()
            is_weight_r = (self.size * prob_r) ** -self.beta_is
            is_weight_r = is_weight_r / is_weight_r.max()

            prob_c = current_priorities_c[final_indices] / current_priorities_c.sum()
            is_weight_c = (self.size * prob_c) ** -self.beta_is
            is_weight_c = is_weight_c / is_weight_c.max()

            # 3. Gather final data batch
            sample_data = (
                self.pre_states[final_indices],
                self.states[final_indices],
                self.actions[final_indices],
                self.rewards[final_indices],
                self.next_states[final_indices],
                self.dones[final_indices],
                self.action_queue[final_indices],
                self.action_queue_next[final_indices],
                np.expand_dims(is_weight_r, axis=-1).astype(np.float32),
                np.expand_dims(is_weight_c, axis=-1).astype(np.float32)
            )

            # 4. Fetch unique IDs
            original_ids = self.transition_ids[final_indices]

            # 5. Queue the result
            self.prefetch_queue.put((sample_data, final_indices, original_ids))
    
    def _get_diverse_indices(self, features, num_to_select):
        """Selects a diverse subset of indices based on cosine similarity."""
        num_candidates = features.shape[0]
        if num_candidates == 0:
            return np.array([], dtype=int)
            
        # Start with a random index
        first_idx = np.random.randint(num_candidates)
        selected_indices = [first_idx]
        selected_features = features[first_idx][np.newaxis, :]

        for _ in range(num_to_select - 1):
            similarities = cosine_similarity(features, selected_features)
            min_similarities_to_selected = np.min(similarities, axis=1)
            next_idx = np.argmax(1 - min_similarities_to_selected) # Find the least similar
            
            selected_indices.append(next_idx)
            selected_features = np.vstack([selected_features, features[next_idx]])
            
        return np.array(selected_indices)

    def sample(self, batch_size, agent_update_count: int):
        """Retrieves a pre-sampled batch from the prefetch queue."""
        if self.size < UPER_CANDIDATE_SET_SIZE:
            return None, None, None
        return self.prefetch_queue.get()

    def add_batch(self, batch: list, agent_update_count: int, agent=None):
        """Adds a batch of new experiences to the buffer."""
        batch_size = len(batch)
        if batch_size == 0:
            return

        pre_states_np = np.array([e['pre_state'] for e in batch], dtype=np.float32)
        states_np = np.array([e['state'] for e in batch], dtype=np.float32)
        actions_np = np.array([e['action'] for e in batch], dtype=np.float32)
        rewards_np = np.array([e['reward'] for e in batch], dtype=np.float32)
        next_states_np = np.array([e['next_state'] for e in batch], dtype=np.float32)
        dones_np = np.array([[float(e['done'])] for e in batch], dtype=np.float32)
        action_queue_np = np.array([e['action_queue'] for e in batch], dtype=np.float32)
        action_queue_next_np = np.array([e['action_queue_next'] for e in batch], dtype=np.float32)

        if self.size < self.capacity:
            if self.ptr + batch_size <= self.capacity:
                indices = np.arange(self.ptr, self.ptr + batch_size)
            else:
                num_until_wrap = self.capacity - self.ptr
                indices_part1 = np.arange(self.ptr, self.capacity)
                indices_part2 = np.arange(0, batch_size - num_until_wrap)
                indices = np.concatenate([indices_part1, indices_part2])
        else:
            # 1. Calculate how many to evict from each pool
            num_reward_evict = int(batch_size * self.sampling_ratio)
            num_cost_evict = batch_size - num_reward_evict

            # Add small noise to break ties consistently
            noisy_priorities_r = self.priorities_reward + np.random.rand(self.capacity) * 1e-5
            noisy_priorities_c = self.priorities_cost + np.random.rand(self.capacity) * 1e-5

            # 2. Find indices with the lowest reward priority
            #    `argpartition` is faster than `argsort` for finding k smallest
            reward_evict_indices = np.argpartition(noisy_priorities_r, num_reward_evict)[:num_reward_evict]

            # 3. Find indices with the lowest cost priority
            cost_evict_indices = np.argpartition(noisy_priorities_c, num_cost_evict)[:num_cost_evict]

            # 4. Combine eviction indices. Use union to get unique indices.
            combined_evict_indices = np.union1d(reward_evict_indices, cost_evict_indices)

            num_needed_more = batch_size - len(combined_evict_indices)
            if num_needed_more > 0:
                # Find indices NOT already chosen
                remaining_indices = np.setdiff1d(np.arange(self.capacity), combined_evict_indices, assume_unique=True)
                # Find the lowest reward priorities among the remaining
                additional_indices = remaining_indices[np.argpartition(noisy_priorities_r[remaining_indices], num_needed_more)[:num_needed_more]]
                indices = np.concatenate([combined_evict_indices, additional_indices])
            else:
                # If the union is >= batch_size, just take the first batch_size unique indices
                # (This handles the case where union > batch_size if num_reward_evict + num_cost_evict > batch_size, though typically they sum to batch_size)
                indices = combined_evict_indices[:batch_size]

            # Ensure we have exactly batch_size indices
            if len(indices) != batch_size:
                 # Fallback: If logic somehow failed, just evict lowest average like before
                 print("⚠️ Stratified eviction fallback triggered. Evicting based on average priority.")
                 combined_priorities = (self.priorities_reward + self.priorities_cost) / 2
                 noisy_priorities = combined_priorities + np.random.rand(combined_priorities.shape[0]) * 1e-5
                 indices = np.argpartition(noisy_priorities, batch_size)[:batch_size]
        
        self.pre_states[indices] = pre_states_np
        self.states[indices] = states_np
        self.actions[indices] = actions_np
        self.rewards[indices] = rewards_np
        self.next_states[indices] = next_states_np
        self.action_queue[indices] = action_queue_np
        self.action_queue_next[indices] = action_queue_next_np
        self.dones[indices] = dones_np
        
        self.priorities_reward[indices] = self.max_priority_reward
        self.priorities_cost[indices] = self.max_priority_cost
        self.ages[indices] = agent_update_count

        new_ids = np.arange(self.id_counter, self.id_counter + batch_size, dtype=np.int64)
        self.transition_ids[indices] = new_ids
        self.id_counter += batch_size

        self.size = min(self.size + batch_size, self.capacity)
        self.ptr = (self.ptr + batch_size) % self.capacity

        if batch_size > 0:
            if agent is not None:
                with torch.no_grad():
                    # Temporarily push to GPU just for the math calculation
                    rewards_t = torch.from_numpy(rewards_np).to(agent.device, non_blocking=True)
                    actions_t = torch.from_numpy(actions_np).to(agent.device, non_blocking=True)
                    
                    _, cost_t, log_dict = agent.calculate_reward(rewards_t, actions_t)
                    # Online realized per-DISTANCE cost -> drives lambda + the budget scheduler.
                    # Speed (reward index 6) is the distance-per-step denominator; FORWARD ONLY.
                    speed_t = rewards_t[:, 6].clamp(min=0.0)
                    agent.update_online_cost_ema(cost_t.mean().item(), speed_t.mean().item(), cost_t.shape[0])
                    incoming_logs = {f"Incoming_Reward/{k}": v for k, v in log_dict.items()}
                    run_wandb.log(incoming_logs)
            else:
                run_wandb.log({"new_extrinsic_reward": rewards_np.mean()})

    def update_priorities(self, indices: np.ndarray, original_ids: np.ndarray, priorities_r: np.ndarray, priorities_c: np.ndarray):
        """Updates priorities, checking transition versions first."""
        current_ids_in_buffer = self.transition_ids[indices]
        mask = (current_ids_in_buffer == original_ids)
        
        
        EPS = 1e-6  # Small value
        priorities_r = torch.nan_to_num(priorities_r, 
                                                nan=0.0, 
                                                posinf=1e6, 
                                                neginf=0.0)
        priorities_r = torch.abs(priorities_r)
        priorities_r = priorities_r + EPS

        valid_indices = indices[mask]
        # Update Reward Priorities
        valid_priorities_r = priorities_r.squeeze(-1)[mask]
        if valid_indices.size > 0:
            self.priorities_reward[valid_indices] = valid_priorities_r
            self.max_priority_reward = max(self.max_priority_reward, np.max(valid_priorities_r))

        # Update Cost Priorities
        EPS = 1e-6  # Small value
        priorities_c = torch.nan_to_num(priorities_c, 
                                                nan=0.0, 
                                                posinf=1e6, 
                                                neginf=0.0)
        priorities_c = torch.abs(priorities_c)
        priorities_c = priorities_c + EPS
        valid_priorities_c = priorities_c.squeeze(-1)[mask]
        if valid_indices.size > 0:
            self.priorities_cost[valid_indices] = valid_priorities_c
            self.max_priority_cost = max(self.max_priority_cost, np.max(valid_priorities_c))

    def save_to_disk(self, save_path=None):
        target_path = save_path if save_path else self.save_path
        temp_path = target_path + ".tmp"
        if self.size == 0: return

        data_to_save = {
            'pre_states': self.pre_states[:self.size],
            'states': self.states[:self.size], 'actions': self.actions[:self.size],
            'rewards': self.rewards[:self.size], 'next_states': self.next_states[:self.size],
            'action_queue': self.action_queue[:self.size],
            'action_queue_next': self.action_queue_next[:self.size],
            'dones': self.dones[:self.size],
            'ages': self.ages[:self.size], 'transition_ids': self.transition_ids[:self.size],
            'priorities_reward': self.priorities_reward[:self.size],
            'priorities_cost': self.priorities_cost[:self.size],
            'id_counter': self.id_counter, 'ptr': self.ptr, 'size': self.size,
            
        }
        print(f"💾 Saving CPU replay buffer ({self.size} experiences) to {target_path}...")
        try:
            with open(temp_path, 'wb') as f: pickle.dump(data_to_save, f)
            os.replace(temp_path, target_path)
            print("💾 Save complete.")
        except Exception as e:
            print(f"❌ Error saving CPU buffer: {e}")

    def load_from_disk(self):
        if not os.path.exists(self.save_path):
            print("💾 No buffer file found. Starting fresh.")
            return

        print(f"💾 Loading CPU buffer from {self.save_path}...")
        try:
            with open(self.save_path, 'rb') as f:
                data_loaded = pickle.load(f)

            size = data_loaded['size']
            self.pre_states[:size] = data_loaded['pre_states']
            self.states[:size] = data_loaded['states']
            self.actions[:size] = data_loaded['actions']
            self.rewards[:size] = data_loaded['rewards']
            self.next_states[:size] = data_loaded['next_states']
            self.action_queue[:size] = data_loaded['action_queue']
            self.action_queue_next[:size] = data_loaded['action_queue_next']
            self.dones[:size] = data_loaded['dones']
            self.priorities_reward[:size] = data_loaded['priorities_reward']
            self.priorities_cost[:size] = data_loaded['priorities_cost']
            self.ages[:size] = data_loaded['ages']
            self.transition_ids[:size] = data_loaded['transition_ids']
            self.id_counter = data_loaded.get('id_counter', 0)

            self.ptr, self.size = data_loaded['ptr'], size
            print(f"💾 CPU buffer loaded. Buffer has {self.size} experiences.")
        except Exception as e:
            print(f"❌ Error loading CPU buffer: {e}. Starting fresh.")
            self.__init__(self.capacity, self.states.shape[1], self.actions.shape[1], self.save_path)

    def close(self):
        print("🛑 [CPU ReplayBuffer] Stopping prefetching worker...")
        self.stop_event.set()
        while not self.prefetch_queue.empty():
            try: self.prefetch_queue.get_nowait()
            except queue.Empty: continue
        self.prefetch_thread.join(timeout=2)
        print("✅ [CPU ReplayBuffer] Prefetching worker stopped.")

    def reset_priorities_and_ages(self):
        if self.size == 0: return
        print("✨ Resetting CPU buffer priorities and ages for new agent.")
        self.priorities[:self.size] = self.max_priority
        self.ages[:self.size] = 0

    def __len__(self):
        return self.size

class GpuReplayBuffer:
    """
    A GPU-based replay buffer with two key features:
    1.  Prefetching: A background thread prepares training batches in advance to
        hide sampling latency and maximize GPU utilization.
    2.  Transition Versioning: Each piece of data is assigned a unique ID to
        prevent a race condition where data is overwritten between being sampled
        and having its priority updated.
    """
    def __init__(self, capacity, state_dim, action_dim, device='cuda', save_path='GREG_RL_Trainer/replay_buffer.pkl', prefetch_size=3, batch_size=1024):
        self.save_path = save_path
        self.capacity = capacity
        self.device = device

        # Core data storage on the GPU
        self.pre_states = torch.zeros((capacity, state_dim), dtype=torch.float32, device=device)
        self.states = torch.zeros((capacity, state_dim), dtype=torch.float32, device=device)
        self.actions = torch.zeros((capacity, action_dim), dtype=torch.float32, device=device)
        self.rewards = torch.zeros((capacity, NUM_REWARD_TERM), dtype=torch.float32, device=device)
        self.next_states = torch.zeros((capacity, state_dim), dtype=torch.float32, device=device)
        self.dones = torch.zeros((capacity, 1), dtype=torch.float32, device=device)
        self.action_queue = torch.zeros((capacity, action_dim*ACTION_QUEUE_SIZE), dtype=torch.float32, device=device)
        self.action_queue_next = torch.zeros((capacity, action_dim*ACTION_QUEUE_SIZE), dtype=torch.float32, device=device)

        # Prioritized replay metadata
        self.priorities_reward = torch.zeros(capacity, dtype=torch.float32, device=device)
        self.priorities_cost = torch.zeros(capacity, dtype=torch.float32, device=device)
        self.max_priority_reward = torch.tensor(100.0, dtype=torch.float32, device=device)
        self.max_priority_cost = torch.tensor(100.0, dtype=torch.float32, device=device)
        self.sampling_ratio = SAMPLE_RATIO_REWARD_TO_COST
        self.ages = torch.zeros(capacity, dtype=torch.int64, device=device)

        # --- Versioning System to prevent race conditions ---
        self.transition_ids = torch.zeros(capacity, dtype=torch.int64, device=device)

        self.env_metadata = np.empty(capacity, dtype=object)
        
        self.seen_class_counts = Counter()

        self.id_counter = 0

        self.ptr, self.size, self.max_priority = 0, 0, 1.0
        self.beta_is = 0.4

        # --- Prefetching Mechanism ---
        self.prefetch_queue = queue.Queue(maxsize=prefetch_size)
        self.stop_event = threading.Event()
        self.prefetch_thread = threading.Thread(
            target=self._prefetch_worker,
            args=(batch_size,),
            daemon=True
        )
        self.prefetch_thread.start()
        print("🚀 [ReplayBuffer] Prefetching worker started.")

        self.load_from_disk()

    def _prefetch_worker(self, batch_size):
        """
        Worker function running in a background thread.
        It continuously samples data, prepares batches, and puts them in a queue.
        """
        while not self.stop_event.is_set():
            if self.size < UPER_CANDIDATE_SET_SIZE or self.prefetch_queue.full():
                time.sleep(0.05)
                continue

            with torch.no_grad():
                # 1. Uncertainty-Weighted Candidate Selection with Dual Priorities
                # Step 1: Calculate how many samples to draw from each pool
                num_reward_samples = int(UPER_CANDIDATE_SET_SIZE * self.sampling_ratio)
                num_cost_samples = UPER_CANDIDATE_SET_SIZE - num_reward_samples

                # Step 2: Sample from the Reward Priority distribution
                priorities_r = self.priorities_reward[:self.size].pow(UPER_ALPHA) + UPER_EPSILON
                reward_indices = torch.multinomial(priorities_r, 
                                                num_samples=num_reward_samples, 
                                                replacement=True)

                # Step 3: Sample from the Cost Priority distribution
                current_priorities_c = self.priorities_cost[:self.size].pow(UPER_ALPHA) + UPER_EPSILON
                cost_indices = torch.multinomial(current_priorities_c, 
                                                num_samples=num_cost_samples, 
                                                replacement=True)

                # Step 4: Combine the indices into one batch
                # The batch may contain duplicate indices, which is acceptable here.
                candidate_indices = torch.cat([reward_indices, cost_indices])
                candidate_states = self.states[candidate_indices]
    
                # 2. Diversity-Based Sub-sampling
                candidate_states_norm = candidate_states / (torch.linalg.norm(candidate_states, dim=1, keepdim=True) + 1e-8)
                anchor_indices = torch.randperm(UPER_CANDIDATE_SET_SIZE, device=self.device)[:DIVERSITY_ANCHORS]
                anchor_features = candidate_states_norm[anchor_indices]
                similarities = torch.matmul(candidate_states_norm, anchor_features.T)
                max_similarities, _ = torch.max(similarities, dim=1)
                _, top_dissimilar_indices = torch.topk(max_similarities, k=batch_size, largest=False)

                final_indices = candidate_indices[top_dissimilar_indices]

                prob_r = priorities_r[final_indices] / priorities_r.sum()
                is_weight_r = (self.size * prob_r).pow(-self.beta_is)
                is_weight_r = is_weight_r / is_weight_r.max()

                prob_c = current_priorities_c[final_indices] / current_priorities_c.sum()
                is_weight_c = (self.size * prob_c).pow(-self.beta_is)
                is_weight_c = is_weight_c / is_weight_c.max()
                # 3. Gather the final data batch
                sample_data = (
                    self.pre_states[final_indices],
                    self.states[final_indices],
                    self.actions[final_indices],
                    self.rewards[final_indices],
                    self.next_states[final_indices],
                    self.dones[final_indices],
                    self.action_queue[final_indices],
                    self.action_queue_next[final_indices],
                    is_weight_r.unsqueeze(1), 
                    is_weight_c.unsqueeze(1)
                )

                # 4. Fetch the unique IDs for the sampled data to ensure consistency
                original_ids = self.transition_ids[final_indices]

                # 5. Put the complete sample (data, indices, and IDs) into the queue
                self.prefetch_queue.put((sample_data, final_indices, original_ids))

    def sample(self, batch_size, agent_update_count: int):
        """
        Retrieves a pre-sampled batch from the prefetch queue. Returns data, indices, and original IDs.
        """
        if self.size < UPER_CANDIDATE_SET_SIZE:
            return None, None, None # Not enough samples to start
        
        self.beta_is = min(1.0, self.beta_is + 2e-6)
        return self.prefetch_queue.get()

    def add_batch(self, batch: list, agent_update_count: int, agent=None):
        """
        Adds a batch of new experiences to the buffer, evicting old ones if full.
        Assigns a new, unique ID to each incoming transition.
        """
        batch_size = len(batch)
        if batch_size == 0:
            return

        # Convert list of dicts to tensors
        pre_states_t = torch.from_numpy(np.array([e['pre_state'] for e in batch], dtype=np.float32)).to(self.device)
        states_t = torch.from_numpy(np.array([e['state'] for e in batch], dtype=np.float32)).to(self.device)
        actions_t = torch.from_numpy(np.array([e['action'] for e in batch], dtype=np.float32)).to(self.device)
        rewards_t = torch.from_numpy(np.array([e['reward'] for e in batch], dtype=np.float32)).to(self.device)
        next_states_t = torch.from_numpy(np.array([e['next_state'] for e in batch], dtype=np.float32)).to(self.device)
        dones_t = torch.from_numpy(np.array([[float(e['done'])] for e in batch], dtype=np.float32)).to(self.device)
        action_queue_t = torch.from_numpy(np.array([e['action_queue'] for e in batch], dtype=np.float32)).to(self.device)
        action_queue_next_t = torch.from_numpy(np.array([e['action_queue_next'] for e in batch], dtype=np.float32)).to(self.device)
        metadata_list = [e.get('env_metadata', '') for e in batch]
        # Determine indices for insertion
        if self.size < self.capacity:
            if self.ptr + batch_size <= self.capacity:
                indices = torch.arange(self.ptr, self.ptr + batch_size, device=self.device)
            else:
                num_until_wrap = self.capacity - self.ptr
                indices_part1 = torch.arange(self.ptr, self.capacity, device=self.device)
                indices_part2 = torch.arange(0, batch_size - num_until_wrap, device=self.device)
                indices = torch.cat([indices_part1, indices_part2])
        else: # Buffer is full, evict lowest-priority samples
            # 1. Calculate how many to evict from each pool
            num_reward_evict = int(batch_size * self.sampling_ratio)
            num_cost_evict = batch_size - num_reward_evict

            # Add small noise to break ties
            noisy_priorities_r = self.priorities_reward + torch.rand_like(self.priorities_reward) * 1e-5
            noisy_priorities_c = self.priorities_cost + torch.rand_like(self.priorities_cost) * 1e-5

            # 2. Find indices with the lowest reward priority
            reward_evict_indices = torch.topk(noisy_priorities_r, num_reward_evict, largest=False).indices

            # 3. Find indices with the lowest cost priority
            cost_evict_indices = torch.topk(noisy_priorities_c, num_cost_evict, largest=False).indices

            # 4. Combine eviction indices and get unique ones
            combined_evict_indices = torch.cat([reward_evict_indices, cost_evict_indices]).unique()

            # 5. Determine the final set of indices
            num_needed_more = batch_size - len(combined_evict_indices)
            if num_needed_more > 0:
                # Find indices NOT already chosen
                combined_mask = torch.zeros(self.capacity, dtype=torch.bool, device=self.device)
                combined_mask.scatter_(0, combined_evict_indices, True)
                remaining_indices = torch.where(~combined_mask)[0]
                
                # Find the lowest reward priorities among the remaining
                additional_indices = remaining_indices[torch.topk(noisy_priorities_r[remaining_indices], num_needed_more, largest=False).indices]
                indices = torch.cat([combined_evict_indices, additional_indices])
            else:
                # If the union is >= batch_size, just take the first batch_size
                indices = combined_evict_indices[:batch_size]

            # 6. Fallback (should be rare)
            if len(indices) != batch_size:
                print("⚠️ Stratified eviction fallback triggered (GPU). Evicting based on average priority.")
                combined_priorities = (self.priorities_reward + self.priorities_cost) / 2
                noisy_priorities = combined_priorities + torch.rand_like(combined_priorities) * 1e-5
                indices = torch.topk(noisy_priorities, batch_size, largest=False).indices
        # Store data
        self.pre_states[indices] = pre_states_t
        self.states[indices] = states_t
        self.actions[indices] = actions_t
        self.rewards[indices] = rewards_t
        self.next_states[indices] = next_states_t
        self.action_queue[indices] = action_queue_t
        self.action_queue_next[indices] = action_queue_next_t
        self.dones[indices] = dones_t

        # Initialize metadata for new transitions
        self.priorities_reward[indices] = self.max_priority_reward
        self.priorities_cost[indices] = self.max_priority_cost
        self.ages[indices] = agent_update_count

        # Assign new, unique IDs to the incoming data
        new_ids = torch.arange(self.id_counter, self.id_counter + batch_size, device=self.device, dtype=torch.int64)
        self.transition_ids[indices] = new_ids
        self.id_counter += batch_size

        # Update buffer size and pointer
        self.size = min(self.size + batch_size, self.capacity)
        if self.size >= self.capacity:
            self.ptr = (self.ptr + batch_size) % self.capacity
        else:
            self.ptr = self.size

        if batch_size > 0:
            import wandb 
            
            # 1. Update the running total with the new incoming batch
            valid_incoming = [m for m in metadata_list if m] 
            self.seen_class_counts.update(valid_incoming)
            
            # 2. Format the cumulative counts into a WandB Table
            data = [[meta_class, count] for meta_class, count in self.seen_class_counts.items()]
            table = wandb.Table(data=data, columns=["Scenario Class", "Total Frames Seen"])
            
            # 3. Create the Bar Chart object
            class_bar_chart = wandb.plot.bar(
                table, "Scenario Class", "Total Frames Seen", title="All-Time Scenario Distribution"
            )

            if agent is not None:
                with torch.no_grad():
                    _, cost_t, log_dict = agent.calculate_reward(rewards_t, actions_t)
                    # Online realized per-DISTANCE cost -> drives lambda + the budget scheduler.
                    # Speed (reward index 6) is the distance-per-step denominator; FORWARD ONLY.
                    speed_t = rewards_t[:, 6].clamp(min=0.0)
                    agent.update_online_cost_ema(cost_t.mean().item(), speed_t.mean().item(), cost_t.shape[0])
                    incoming_logs = {f"Incoming_Reward/{k}": v for k, v in log_dict.items()}

                    # Attach the cumulative bar chart
                    incoming_logs["Incoming_Reward/All_Time_Classes"] = class_bar_chart
                    run_wandb.log(incoming_logs)
            else:
                run_wandb.log({
                    "new_extrinsic_reward": rewards_t[:,:-2].mean().item(),
                    "All_Time_Classes": class_bar_chart
                })

    def update_priorities(self, indices: torch.Tensor, original_ids: torch.Tensor, 
                      priorities_r: torch.Tensor, priorities_c: torch.Tensor):
        """
        Updates the priorities of sampled transitions. Crucially, it first checks
        if the transition at a given index is still the same one that was sampled.
        """
        with torch.no_grad():
            current_ids_in_buffer = self.transition_ids[indices]
            mask = (current_ids_in_buffer == original_ids)
            valid_indices = indices[mask]

            EPS = 1e-6  # Small value
            priorities_r = torch.nan_to_num(priorities_r, 
                                                    nan=0.0, 
                                                    posinf=1e6, 
                                                    neginf=0.0)
            priorities_r = torch.abs(priorities_r)
            priorities_r = priorities_r + EPS
            
            # Update Reward Priorities
            valid_priorities_r = priorities_r.squeeze(-1)[mask]
            if valid_indices.numel() > 0:
                self.priorities_reward[valid_indices] = valid_priorities_r
                self.max_priority_reward = max(self.max_priority_reward, valid_priorities_r.max().item())

            # Update Cost Priorities
            EPS = 1e-6  # Small value
            priorities_c = torch.nan_to_num(priorities_c, 
                                                    nan=0.0, 
                                                    posinf=1e6, 
                                                    neginf=0.0)
            priorities_c = torch.abs(priorities_c)
            priorities_c = priorities_c + EPS
            valid_priorities_c = priorities_c.squeeze(-1)[mask]
            if valid_indices.numel() > 0:
                self.priorities_cost[valid_indices] = valid_priorities_c
                self.max_priority_cost = max(self.max_priority_cost, valid_priorities_c.max().item())

    def save_to_disk(self, save_path=None):
        target_path = save_path if save_path else self.save_path
        temp_path = target_path + ".tmp"
        if self.size == 0: return

        data_to_save = {
            'pre_states': self.pre_states[:self.size].cpu().numpy(),
            'states': self.states[:self.size].cpu().numpy(),
            'actions': self.actions[:self.size].cpu().numpy(),
            'rewards': self.rewards[:self.size].cpu().numpy(),
            'next_states': self.next_states[:self.size].cpu().numpy(),
            'action_queue': self.action_queue[:self.size].cpu().numpy(),
            'action_queue_next': self.action_queue_next[:self.size].cpu().numpy(),
            'dones': self.dones[:self.size].cpu().numpy(),
            'priorities_reward': self.priorities_reward[:self.size].cpu().numpy(),
            'priorities_cost': self.priorities_cost[:self.size].cpu().numpy(),
            'ages': self.ages[:self.size].cpu().numpy(),
            'transition_ids': self.transition_ids[:self.size].cpu().numpy(),
            'env_metadata': self.env_metadata[:self.size],
            'seen_class_counts': self.seen_class_counts,
            'id_counter': self.id_counter,
            'ptr': self.ptr,
            'size': self.size,
        }
        print(f"💾 Saving GPU replay buffer ({self.size} experiences) to {target_path}...")
        try:
            with open(temp_path, 'wb') as f:
                pickle.dump(data_to_save, f)
            os.replace(temp_path, target_path)
            print("💾 Save complete.")
        except Exception as e:
            print(f"❌ Error saving GPU buffer: {e}")

    def load_from_disk(self):
        if not os.path.exists(self.save_path):
            print("💾 No buffer file found. Starting fresh.")
            return

        print(f"💾 Loading buffer from {self.save_path}...")
        try:
            with open(self.save_path, 'rb') as f:
                data_loaded = pickle.load(f)

            size = data_loaded['size']
            self.pre_states[:size] = torch.from_numpy(data_loaded['pre_states']).to(self.device)
            self.states[:size] = torch.from_numpy(data_loaded['states']).to(self.device)
            self.actions[:size] = torch.from_numpy(data_loaded['actions']).to(self.device)
            self.rewards[:size] = torch.from_numpy(data_loaded['rewards']).to(self.device)
            self.next_states[:size] = torch.from_numpy(data_loaded['next_states']).to(self.device)
            self.action_queue[:size] = torch.from_numpy(data_loaded['action_queue']).to(self.device)
            self.action_queue_next[:size] = torch.from_numpy(data_loaded['action_queue_next']).to(self.device)
            self.dones[:size] = torch.from_numpy(data_loaded['dones']).to(self.device)
            self.priorities_cost[:size] = torch.from_numpy(data_loaded['priorities_cost']).to(self.device)
            self.priorities_reward[:size] = torch.from_numpy(data_loaded['priorities_reward']).to(self.device)    
            self.ages[:size] = torch.from_numpy(data_loaded['ages']).to(self.device)
            self.env_metadata[:size] = data_loaded['env_metadata']
            self.seen_class_counts = data_loaded['seen_class_counts']
            
            # Load versioning system state
            if 'transition_ids' in data_loaded:
                self.transition_ids[:size] = torch.from_numpy(data_loaded['transition_ids']).to(self.device)
                self.id_counter = data_loaded.get('id_counter', 0)
            
            self.ptr, self.size = data_loaded['ptr'], size
            print(f"💾 GPU buffer loaded. Buffer has {self.size} experiences.")
        except Exception as e:
            print(f"❌ Error loading buffer: {e}. Starting fresh.")
            # Reset state if loading fails
            self.__init__(self.capacity, self.states.shape[1], self.actions.shape[1], self.device, self.save_path)

    def close(self):
        """Signals the prefetching thread to stop and waits for it to finish."""
        print("🛑 [ReplayBuffer] Stopping prefetching worker...")
        self.stop_event.set()
        while not self.prefetch_queue.empty():
            try:
                self.prefetch_queue.get_nowait()
            except queue.Empty:
                continue
        self.prefetch_thread.join(timeout=2)
        print("✅ [ReplayBuffer] Prefetching worker stopped.")

    def reset_priorities_and_ages(self):
        if self.size == 0: return
        print("✨ Resetting GPU buffer priorities and ages for new agent.")
        self.priorities_reward[:self.size] = self.max_priority_reward
        self.priorities_cost[:self.size] = self.max_priority_cost
        self.ages[:self.size] = 0

    def __len__(self):
        return self.size


class SequenceReplayBuffer:
    """SEPARATE from the transition buffer: the SAC path keeps
    its per-transition UPER sampling untouched; the world model needs TEMPORAL ORDER, which the
    prioritized buffer destroys. Transitions arrive per-worker in order (the same stream guarantee
    the n-step aggregator relies on); we accumulate per worker id, cut a chunk every RSSM_SEQ_LEN
    steps or at episode end / continuity break (partials zero-padded + masked), and store chunks
    in a GPU ring. Fed from StratifiedGpuReplayBuffer._nstep_process (set `.seq_buffer`).
    The observation is [512-d embedding, 10-d route] = RSSM_OBS_DIM; the action is the EXECUTED
    [steer, onehot6]; reward/cost are the learner-computed per-step scalars (terminal penalties
    included in r; c is the raw terminal spike, NOT the absorbing-folded c_eff — the cost head is
    a Bernoulli on c>0). Main ring NOT persisted — refills within minutes. Cost-positive chunks
    are ALSO copied into a persisted reservoir ring and RSSM_COST_SAMPLE_FRAC of every batch is
    drawn from it, so the cost/done heads keep seeing violations as the live stream goes clean."""

    def __init__(self, capacity=RSSM_SEQ_CAPACITY, seq_len=RSSM_SEQ_LEN, obs_dim=RSSM_OBS_DIM,
                 action_dim=ACTION_DIM, device='cuda'):
        self.cap, self.L, self.device = capacity, seq_len, device
        f32 = torch.float32
        self.emb = torch.zeros((capacity, seq_len, obs_dim), dtype=f32, device=device)
        self.act = torch.zeros((capacity, seq_len, action_dim), dtype=f32, device=device)
        self.rew = torch.zeros((capacity, seq_len), dtype=f32, device=device)
        self.cost = torch.zeros((capacity, seq_len), dtype=f32, device=device)
        self.done = torch.zeros((capacity, seq_len), dtype=f32, device=device)
        self.mask = torch.zeros((capacity, seq_len), dtype=f32, device=device)
        self.ptr = 0
        self.count = 0
        cc = RSSM_COST_RESERVOIR_CAP
        self.cL = RSSM_EVENT_SEQ_LEN
        self.c_emb = torch.zeros((cc, self.cL, obs_dim), dtype=f32, device=device)
        self.c_act = torch.zeros((cc, self.cL, action_dim), dtype=f32, device=device)
        self.c_rew = torch.zeros((cc, self.cL), dtype=f32, device=device)
        self.c_cost = torch.zeros((cc, self.cL), dtype=f32, device=device)
        self.c_done = torch.zeros((cc, self.cL), dtype=f32, device=device)
        self.c_mask = torch.zeros((cc, self.cL), dtype=f32, device=device)
        self.c_ptr = 0
        self.c_count = 0
        self.acc = {}          # worker_id -> list of in-order step dicts (open chunk)
        self.event_hist = {}   # worker_id -> rolling H64 context, independent of H32 chunk cuts

    def _main_bufs(self):
        return (self.emb, self.act, self.rew, self.cost, self.done, self.mask)

    def _res_bufs(self):
        return (self.c_emb, self.c_act, self.c_rew, self.c_cost, self.c_done, self.c_mask)

    def ingest(self, incoming):
        """incoming: per-step dicts {worker_id, state(512), route(10), action(7), r, c, done,
        next_state(512)} in temporal order per worker. Continuity check on the raw embedding —
        worker restarts / dropped batches must not be stitched into one fake sequence."""
        for t in incoming:
            wid = t['worker_id']
            acc = self.acc.setdefault(wid, [])
            hist = self.event_hist.setdefault(wid, deque(maxlen=self.cL))
            if acc and not np.allclose(acc[-1]['next_state'], t['state'], atol=1e-4):
                self._commit(acc)          # continuity break: keep what we have, start fresh
                acc.clear()
                hist.clear()
            elif hist and not np.allclose(hist[-1]['next_state'], t['state'], atol=1e-4):
                hist.clear()
            acc.append(t)
            hist.append(t)
            if t['done']:
                # Store the actual approach ending at the event, not the short terminal remainder
                # created by the independent H32 ordinary chunk boundary.
                event = list(hist)
                if any(s['c'] > 0 for s in event) and len(event) >= RSSM_MIN_PARTIAL:
                    self._write_chunk(self._res_bufs(), self.c_ptr, event, len(event), align_end=True)
                    self.c_ptr = (self.c_ptr + 1) % RSSM_COST_RESERVOIR_CAP
                    self.c_count = min(self.c_count + 1, RSSM_COST_RESERVOIR_CAP)
                hist.clear()
            if t['done'] or len(acc) == self.L:
                self._commit(acc)
                acc.clear()

    def _write_chunk(self, bufs, i, steps, n, align_end=False):
        emb, act, rew, cost, done, mask = bufs
        for buf in bufs:
            buf[i].zero_()
        obs_np = np.stack([np.concatenate([s['state'], s['route']]) for s in steps])
        start = bufs[0].shape[1] - n if align_end else 0
        sl = slice(start, start + n)
        emb[i, sl] = torch.from_numpy(obs_np).to(self.device)
        act[i, sl] = torch.from_numpy(np.stack([s['action'] for s in steps])).to(self.device)
        rew[i, sl] = torch.tensor([s['r'] for s in steps], device=self.device)
        cost[i, sl] = torch.tensor([s['c'] for s in steps], device=self.device)
        done[i, sl] = torch.tensor([float(s['done']) for s in steps], device=self.device)
        mask[i, sl] = 1.0

    def _commit(self, steps):
        n = len(steps)
        if n < RSSM_MIN_PARTIAL:
            return
        self._write_chunk(self._main_bufs(), self.ptr, steps, n)
        self.ptr = (self.ptr + 1) % self.cap
        self.count = min(self.count + 1, self.cap)
    def sample(self, batch):
        if self.count < max(batch, RSSM_MIN_CHUNKS):
            return None
        k = min(int(round(batch * RSSM_COST_SAMPLE_FRAC)), self.c_count)
        idx = torch.randint(0, self.count, (batch - k,), device=self.device)
        out = [buf[idx] for buf in self._main_bufs()]
        if k > 0:
            cidx = torch.randint(0, self.c_count, (k,), device=self.device)
            # Immediate-head training keeps L32 and uses the terminal-aligned end of each H64
            # failure window. Long precursor losses use sample_event() below.
            out = [torch.cat([a, buf[cidx, -self.L:]], dim=0)
                   for a, buf in zip(out, self._res_bufs())]
        return tuple(out)

    def sample_event(self, batch):
        """H64 terminal-aligned windows for overshooting and multi-horizon safety objectives."""
        if self.c_count == 0 or batch <= 0:
            return None
        idx = torch.randint(0, self.c_count, (min(batch, self.c_count),), device=self.device)
        return tuple(buf[idx] for buf in self._res_bufs())

    def save_ring(self, path=RSSM_SEQ_RING_FILE):
        """Persist the MAIN chunk ring. The original design left this volatile on the
        premise that it 'refills within minutes' -- that was true at 20 Hz, but 5 Hz decimation cut
        ingestion ~4x and 4096 chunks == 131k transitions, i.e. TENS OF HOURS. Measured on the
        A later restart showed: chunks went 4096 -> 343 and were still only ~1200 after 95k updates,
        while MVE kept blending at w=0.4 the whole time (the ramp keys off update_count, which
        resumes). Saved fp16 on the checkpoint cadence (~140 MB); the ring is a plain ring so
        restoring [0:count] with ptr=count%cap is exact."""
        if self.count == 0:
            return
        n = self.count
        tmp = path + '.tmp'
        torch.save({'emb': self.emb[:n].half().cpu(), 'act': self.act[:n].half().cpu(),
                    'rew': self.rew[:n].half().cpu(), 'cost': self.cost[:n].half().cpu(),
                    'done': self.done[:n].half().cpu(), 'mask': self.mask[:n].half().cpu(),
                    'count': n, 'ptr': self.ptr}, tmp)
        os.replace(tmp, path)

    def load_ring(self, path=RSSM_SEQ_RING_FILE):
        if not os.path.exists(path):
            return
        try:
            d = torch.load(path, map_location='cpu')
            n = min(int(d['count']), self.cap)
            if tuple(d['emb'].shape[1:]) != tuple(self.emb.shape[1:]):
                raise ValueError(f"shape mismatch {tuple(d['emb'].shape[1:])} vs "
                                 f"{tuple(self.emb.shape[1:])}")
            for buf, key in zip(self._main_bufs(), ('emb', 'act', 'rew', 'cost', 'done', 'mask')):
                buf[:n] = d[key][:n].to(self.device, torch.float32)
            self.count = n
            self.ptr = n % self.cap
            print(f"🌀 [SeqBuffer] Main chunk ring loaded: {n} chunks from {path} "
                  f"(no MVE starvation transient on this restart).")
        except Exception as e:
            print(f"⚠️ [SeqBuffer] Could not load main chunk ring ({e}) — starting empty; "
                  f"the MVE chunk gate will hold w at 0 until it refills.")

    def save_reservoir(self, path=RSSM_COST_RESERVOIR_FILE):
        if self.c_count == 0:
            return
        tmp = path + '.tmp'
        torch.save({'emb': self.c_emb[:self.c_count].cpu(), 'act': self.c_act[:self.c_count].cpu(),
                    'rew': self.c_rew[:self.c_count].cpu(), 'cost': self.c_cost[:self.c_count].cpu(),
                    'done': self.c_done[:self.c_count].cpu(), 'mask': self.c_mask[:self.c_count].cpu(),
                    'count': self.c_count, 'ptr': self.c_ptr}, tmp)
        os.replace(tmp, path)

    def load_reservoir(self, path=RSSM_COST_RESERVOIR_FILE):
        if not os.path.exists(path):
            return
        try:
            d = torch.load(path, map_location=self.device)
            n = min(int(d['count']), RSSM_COST_RESERVOIR_CAP)
            if d['emb'].shape[1:] != self.c_emb.shape[1:]:
                raise ValueError(f"shape mismatch {tuple(d['emb'].shape[1:])} vs "
                                 f"{tuple(self.c_emb.shape[1:])}")
            for buf, key in zip(self._res_bufs(), ('emb', 'act', 'rew', 'cost', 'done', 'mask')):
                buf[:n] = d[key][:n].to(self.device)
            self.c_count = n
            self.c_ptr = n % RSSM_COST_RESERVOIR_CAP
            print(f"🌀 [SeqBuffer] Cost reservoir loaded: {n} chunks from {path}.")
        except Exception as e:
            print(f"⚠️ [SeqBuffer] Could not load cost reservoir ({e}) — starting empty.")


class StratifiedGpuReplayBuffer:
    """
    GPU replay buffer with two PHYSICALLY SEPARATE partitions, so rare unsafe transitions are
    never evicted by the flood of safe ones (the shared-pool eviction trap that GpuReplayBuffer
    suffers from):

      - SAFE   partition : global slots [0, cap_safe)            (no collision AND cost <= threshold)
      - UNSAFE partition : global slots [cap_safe, capacity)     (collision OR cost > UNSAFE_COST_THRESHOLD)

    Each partition has its own ring pointer / fill size / eviction (lowest-priority WITHIN the
    partition: reward priority for safe, cost priority for unsafe). Because a safe transition can
    only ever land in a safe slot, it can never displace an unsafe one. Sampling draws an unsafe
    share of the candidate pool that SCALES with the partition's live size,
    clamp(UNSAFE_REPLAY_BOOST * unsafe/total, UNSAFE_FRAC_MIN, UNSAFE_FRAC_MAX), so each unsafe
    transition is replayed a bounded BOOST-x as often as a safe one (safe by reward-UPER priority,
    unsafe by cost-UPER priority); if no unsafe data has arrived yet it tops up entirely from safe
    so prefetch never stalls. One global index space + monotonic transition ids
    keep update_priorities race-safe, exactly as in GpuReplayBuffer. IS-weights are returned as ones
    (the mixture density is intractable; prioritization is via sampling only).
    """
    def __init__(self, capacity, state_dim, action_dim, device='cuda', save_path='GREG_RL_Trainer/replay_buffer.pkl', prefetch_size=3, batch_size=1024):
        self.save_path = save_path
        self.capacity = capacity
        self.device = device
        self.cap_unsafe = min(CAP_UNSAFE, capacity // 2)
        self.cap_safe = capacity - self.cap_unsafe

        # Core data storage on the GPU (single allocation; partitions are slot ranges).
        self.states = torch.zeros((capacity, state_dim), dtype=torch.float32, device=device)
        self.actions = torch.zeros((capacity, action_dim), dtype=torch.float32, device=device)
        self.rewards = torch.zeros((capacity, NUM_REWARD_TERM), dtype=torch.float32, device=device)
        self.next_states = torch.zeros((capacity, state_dim), dtype=torch.float32, device=device)
        self.dones = torch.zeros((capacity, 1), dtype=torch.float32, device=device)

        # Privileged GT box/route tokens (fp16 to halve VRAM: ~1.2 GB total for both at 1M cap).
        # Stored RAW (not pre-encoded) because the box encoder trains online. Last col = class id (0=pad).
        self.use_boxes = USE_BOX_CRITIC
        if self.use_boxes:
            self.boxes = torch.zeros((capacity, MAX_BOX_TOKENS, BOX_COL_DIM), dtype=torch.float16, device=device)
            self.next_boxes = torch.zeros((capacity, MAX_BOX_TOKENS, BOX_COL_DIM), dtype=torch.float16, device=device)

        # Route scalars [speed, target_point(2), command(6)] for s and s' (critic state + actor adapter).
        self.use_route = USE_ROUTE
        if self.use_route:
            self.route_scalars = torch.zeros((capacity, ROUTE_DIM), dtype=torch.float32, device=device)
            self.next_route_scalars = torch.zeros((capacity, ROUTE_DIM), dtype=torch.float32, device=device)

        self.priorities_reward = torch.zeros(capacity, dtype=torch.float32, device=device)
        self.priorities_cost = torch.zeros(capacity, dtype=torch.float32, device=device)
        self.max_priority_reward = torch.tensor(100.0, dtype=torch.float32, device=device)
        self.max_priority_cost = torch.tensor(100.0, dtype=torch.float32, device=device)
        self.ages = torch.zeros(capacity, dtype=torch.int64, device=device)
        self.transition_ids = torch.zeros(capacity, dtype=torch.int64, device=device)
        self.env_metadata = np.empty(capacity, dtype=object)
        self.seen_class_counts = Counter()
        self.id_counter = 0

        self.nstep_rewards = torch.zeros((capacity, 1), dtype=torch.float32, device=device)
        self.nstep_costs = torch.zeros((capacity, 1), dtype=torch.float32, device=device)
        self.nstep_ns = torch.ones((capacity, 1), dtype=torch.float32, device=device)
        # 1.0 => nstep_costs is an EXACT return to an in-window terminal (no cost bootstrap);
        # 0.0 => cost bootstraps at the stored s_{t+n} like the reward channel. See N_STEP_COST_LOOKAHEAD.
        self.nstep_cost_dones = torch.zeros((capacity, 1), dtype=torch.float32, device=device)
        self.nstep_dists = torch.zeros((capacity, 1), dtype=torch.float32, device=device)
        self.nstep_s2t = torch.full((capacity, 1), NSTEP_S2T_NONE, dtype=torch.float32, device=device)
        self._nstep_pending = {}   # worker_id -> deque of (exp_dict, r_scalar, c_eff, done) awaiting future steps
        self._burnin_roll = {}     # worker_id -> deque(maxlen=RSSM_BURNIN_L) of the most recent steps,
                                   # snapshotted onto each step as its own pre-history (see _nstep_process)

        self.seq_buffer = None
        if RSSM_ENABLED and RSSM_BURNIN_L > 0:
            self.burnin_cur = torch.zeros((capacity, RSSM_BURNIN_L, RSSM_BURNIN_FEAT), dtype=torch.float16, device=device)
            self.burnin_cur_mask = torch.zeros((capacity, RSSM_BURNIN_L), dtype=torch.float16, device=device)
            # Only the three frames after t are needed to reconstruct reward s_(t+4) burn-in.
            self.burnin_bridge = torch.zeros((capacity, max(N_STEP_RETURN - 1, 0),
                                              RSSM_BURNIN_FEAT), dtype=torch.float16, device=device)
            self.burnin_bridge_mask = torch.zeros((capacity, max(N_STEP_RETURN - 1, 0)),
                                                   dtype=torch.float16, device=device)
            # Cost landing storage is safe-partition-only; unsafe rows have exact terminal returns.
            self.cost_next_states = torch.zeros((self.cap_safe, STATE_DIM),
                                                dtype=torch.float16, device=device)
            self.cost_next_routes = torch.zeros((self.cap_safe, ROUTE_DIM),
                                                dtype=torch.float16, device=device)
            self.cost_burnin = torch.zeros((self.cap_safe, RSSM_BURNIN_L, RSSM_BURNIN_FEAT),
                                           dtype=torch.float16, device=device)
            self.cost_burnin_mask = torch.zeros((self.cap_safe, RSSM_BURNIN_L),
                                                dtype=torch.float16, device=device)
            self.cost_landing_valid = torch.zeros(self.cap_safe, dtype=torch.bool, device=device)
            nq = 32  # Critic default; construction test asserts this matches before cache use.
            self.safety_cache = torch.zeros((self.cap_safe, nq), dtype=torch.float16, device=device)
            self.safety_cache_ids = torch.full((self.cap_safe,), -1, dtype=torch.int64, device=device)
            self.safety_cache_updates = torch.full((self.cap_safe,), -10**9, dtype=torch.int64,
                                                   device=device)
            self.safety_refresh_queue = deque()
        else:
            self.burnin_cur = self.burnin_cur_mask = None
            self.burnin_bridge = self.burnin_bridge_mask = None
            self.cost_next_states = self.cost_next_routes = None
            self.cost_burnin = self.cost_burnin_mask = self.cost_landing_valid = None
            self.safety_cache = self.safety_cache_ids = self.safety_cache_updates = None
            self.safety_refresh_queue = None

        # Per-partition ring state.
        self.safe_ptr, self.safe_size = 0, 0
        self.unsafe_ptr, self.unsafe_size = 0, 0
        self.live_unsafe_frac = 0.0   # last unsafe candidate-pool share used by the prefetch worker (for logging)
        self.last_forced_new = 0      # never-sampled rows force-included in the last batch (NEW_ENTRY_BATCH_QUOTA)
        self.last_priority_elite = 0  # updated-priority rows protected from diversity filtering
        self.beta_is = 0.4

        self._field_names = ['states', 'actions', 'rewards', 'next_states', 'dones',
                             'priorities_reward', 'priorities_cost',
                             'ages', 'transition_ids', 'nstep_rewards', 'nstep_costs', 'nstep_ns',
                             'nstep_cost_dones', 'nstep_dists', 'nstep_s2t']
        if self.use_boxes:
            self._field_names += ['boxes', 'next_boxes']
        if self.use_route:
            self._field_names += ['route_scalars', 'next_route_scalars']
        if self.burnin_cur is not None:
            self._field_names += ['burnin_cur', 'burnin_cur_mask', 'burnin_bridge',
                                  'burnin_bridge_mask', 'cost_next_states', 'cost_next_routes',
                                  'cost_burnin', 'cost_burnin_mask', 'cost_landing_valid']

        # Prefetching.
        self.prefetch_queue = queue.Queue(maxsize=prefetch_size)
        self.stop_event = threading.Event()
        self.prefetch_thread = threading.Thread(target=self._prefetch_worker, args=(batch_size,), daemon=True)
        self.prefetch_thread.start()
        print(f"🚀 [StratifiedReplayBuffer] Prefetching worker started. Safe cap {self.cap_safe}, Unsafe cap {self.cap_unsafe}.")

        self.load_from_disk()

    @property
    def size(self):
        return self.safe_size + self.unsafe_size

    def __len__(self):
        return self.safe_size + self.unsafe_size

    def _alloc_slots(self, n, offset, cap, ptr, size, evict_priority):
        """Pick n destination GLOBAL slots in one partition. Returns (global_indices, new_ptr, new_size).
        Sequential ring fill until the partition is full, then lowest-priority eviction within it."""
        if n <= 0:
            return torch.empty(0, dtype=torch.long, device=self.device), ptr, size
        if size < cap:
            if ptr + n <= cap:
                local = torch.arange(ptr, ptr + n, device=self.device)
            else:
                local = torch.cat([torch.arange(ptr, cap, device=self.device),
                                   torch.arange(0, n - (cap - ptr), device=self.device)])
            new_size = min(size + n, cap)
            new_ptr = (ptr + n) % cap
            return offset + local, new_ptr, new_size
        # Partition full: evict the n lowest-priority slots within it.
        part_pri = evict_priority[offset:offset + cap]
        noisy = part_pri + torch.rand_like(part_pri) * 1e-5
        evict_local = torch.topk(noisy, n, largest=False).indices
        return offset + evict_local, ptr, size

    @staticmethod
    def _nstep_make(window, gamma_r, gamma_c):
        """Aggregate a window of (exp_dict, r, c_eff, done) -- oldest first, up to
        N_STEP_COST_LOOKAHEAD deep -- ONTO the oldest dict. The two channels use different horizons:

        - REWARD: dense signal, so the horizon stays short (n_r = min(N_STEP_RETURN, len)): sum the
          first n_r rewards, rewrite the next-side fields/done to step n_r, bootstrap with gamma^n_r.
          Longer would import off-policy bias from the stale behavior policy (see constant comment).
        - COST: terminal-spike-only signal (all causes). The flush invariant guarantees a `done` can only ever be the
          LAST window entry, so if the window ends in a terminal at distance k=len-1, the cost return
          sum_j gamma_c^j c_j is the EXACT finite return (all intermediate c_j are 0; the terminal's
          absorbing c/(1-gamma_c) is folded into its c_eff) -> nstep_cost_done=1, no bootstrap.
          Otherwise cost mirrors the reward horizon and bootstraps at the same stored s_{t+n_r}.

        Returns the mutated oldest dict."""
        def _fwd_speed(exp):
            r = exp.get('reward')
            if r is None:
                return 0.0
            return max(float(np.asarray(r, dtype=np.float32).reshape(-1)[6]), 0.0)

        n_r = min(N_STEP_RETURN, len(window))
        e0 = window[0][0]
        R = 0.0
        for j in range(n_r):
            R += (gamma_r ** j) * window[j][1]
        if window[-1][3]:   # window ends in a terminal -> exact cost return over the FULL window
            C = 0.0
            for j, (_, _, c, _) in enumerate(window):
                C += (gamma_c ** j) * c
            D = 0.0
            for j, (e_j, _, _, _) in enumerate(window):
                D += (gamma_c ** j) * _fwd_speed(e_j)
            cost_done = True
        else:               # no terminal in sight -> ordinary n_r-step cost bootstrap
            C = 0.0
            for j in range(n_r):
                C += (gamma_c ** j) * window[j][2]
            D = 0.0
            for j in range(n_r):
                D += (gamma_c ** j) * _fwd_speed(window[j][0])
            cost_done = False
        boot = window[n_r - 1][0]   # reward-channel bootstrap step (s_{t+n_r})
        # the last one before the landing state, and it never reads past the terminal because
        if RSSM_BURNIN_L > 0:
            seq = list(e0.get('_burnin_hist') or [None] * RSSM_BURNIN_L)
            seq += [w[0] for w in window]
            e0['burnin_cur'] = seq[0:RSSM_BURNIN_L]
            # Memory-neutral reward landing: current frame is already stored, so retain only
            # t+1..t+n_r-1. Sampling reconstructs the complete shifted L-frame window.
            e0['burnin_bridge'] = [window[j][0] for j in range(1, n_r)]
            # Cost landing exists only when the complete exact H30 window was observed and did not
            # terminate. Truncated/discontinuous rows safely fall back to the exact/model-free tail.
            cost_valid = (not cost_done and len(window) >= N_STEP_COST_LOOKAHEAD)
            if cost_valid:
                e0['cost_burnin'] = seq[N_STEP_COST_LOOKAHEAD:
                                        N_STEP_COST_LOOKAHEAD + RSSM_BURNIN_L]
                cost_boot = window[N_STEP_COST_LOOKAHEAD - 1][0]
                e0['cost_next_state'] = cost_boot['next_state']
                e0['cost_next_route_scalars'] = cost_boot.get('next_route_scalars')
            e0['cost_landing_valid'] = cost_valid
        e0['nstep_reward'] = R
        e0['nstep_cost'] = C
        e0['nstep_dist'] = D
        e0['nstep_n'] = n_r
        e0['nstep_cost_done'] = cost_done
        # Steps-to-terminal for THIS transition. The flush invariant guarantees a
        e0['nstep_s2t'] = float(len(window) - 1) if cost_done else NSTEP_S2T_NONE
        e0['done'] = bool(window[n_r - 1][3])
        e0['next_state'] = boot['next_state']
        e0['action_queue_next'] = boot['action_queue_next']
        if 'next_boxes' in boot:
            e0['next_boxes'] = boot['next_boxes']
        if 'next_route_scalars' in boot:
            e0['next_route_scalars'] = boot['next_route_scalars']
        return e0

    def _nstep_flush(self, pend, emitted, gamma_r, gamma_c):
        """Emit every pending transition with whatever (truncated) horizon is available -- used at
        episode end (shrinking windows down to the terminal step) and at stream discontinuities
        (bootstrap at the last available next_state; shorter n is still an unbiased target)."""
        while pend:
            emitted.append(self._nstep_make(list(pend), gamma_r, gamma_c))
            pend.popleft()

    def _nstep_process(self, batch: list, agent):
        """Per-worker n-step aggregation over the (temporally ordered) incoming chunk. Transitions
        wait in a small pending queue until N_STEP_COST_LOOKAHEAD future steps (or a terminal) are
        known, then are emitted for storage (reward horizon stays N_STEP_RETURN; see _nstep_make). The per-step 'reward' VECTOR is left untouched (it still feeds
        the online cost EMA / logging / routing); only the added scalar fields carry the aggregates."""
        with torch.no_grad():
            rewards_t = torch.from_numpy(np.array([e['reward'] for e in batch], dtype=np.float32)).to(self.device)
            actions_t = torch.from_numpy(np.array([e['action'] for e in batch], dtype=np.float32)).to(self.device)
            r_scalar, c_scalar, _ = agent.calculate_reward(rewards_t, actions_t)
            r_np = r_scalar.squeeze(-1).float().cpu().numpy()
            c_np = c_scalar.squeeze(-1).float().cpu().numpy()

        if self.seq_buffer is not None:
            seq_records = []
            for i, e in enumerate(batch):
                rt = e.get('route_scalars')
                route_np = (np.asarray(rt, dtype=np.float32).reshape(-1)[:ROUTE_DIM]
                            if rt else np.zeros(ROUTE_DIM, dtype=np.float32))
                if route_np.shape[0] < ROUTE_DIM:
                    route_np = np.pad(route_np, (0, ROUTE_DIM - route_np.shape[0]))
                seq_records.append({
                    'worker_id': e.get('worker_id', -1),
                    'state': np.asarray(e['state'], dtype=np.float32),
                    'route': route_np,
                    'action': np.asarray(e['action'], dtype=np.float32),
                    'r': float(r_np[i]),
                    'c': float(c_np[i]),
                    'done': bool(e['done']),
                    'next_state': np.asarray(e['next_state'], dtype=np.float32),
                })
            self.seq_buffer.ingest(seq_records)

        gamma_r, gamma_c = agent.gamma, agent.gamma_cost
        emitted = []
        for i, e in enumerate(batch):
            done_i = bool(e['done'])
            # Fold the absorbing terminal cost c/(1-gamma_c) into the terminal step's effective cost.
            c_eff = float(c_np[i]) * (COST_TERMINAL_MASS if done_i else 1.0)
            wid = e.get('worker_id', -1)
            pend = self._nstep_pending.setdefault(wid, deque())
            roll = self._burnin_roll.setdefault(wid, deque(maxlen=RSSM_BURNIN_L)) if RSSM_BURNIN_L > 0 else None
            # Discontinuity check: the new transition must chain from the pending tail (worker
            if pend:
                tail_next = np.asarray(pend[-1][0]['next_state'], dtype=np.float32)
                if not np.allclose(tail_next, np.asarray(e['state'], dtype=np.float32), atol=1e-4):
                    self._nstep_flush(pend, emitted, gamma_r, gamma_c)
                    if roll is not None:
                        roll.clear()   # stream discontinuity: the history before `e` is not e's past
            if roll is not None:
                e['_burnin_hist'] = [None] * (RSSM_BURNIN_L - len(roll)) + list(roll)
                roll.append(e)
            pend.append((e, float(r_np[i]), c_eff, done_i))
            if done_i:
                self._nstep_flush(pend, emitted, gamma_r, gamma_c)
                if roll is not None:
                    roll.clear()       # next step starts a new episode: h must restart from zeros
            elif len(pend) >= max(N_STEP_RETURN, N_STEP_COST_LOOKAHEAD):
                # Window depth = the COST lookahead (reward still only uses its first N_STEP_RETURN
                # entries): a transition is emitted once we know no terminal follows within ~1.5 s.
                emitted.append(self._nstep_make(list(pend), gamma_r, gamma_c))
                pend.popleft()
        return emitted

    def add_batch(self, batch: list, agent_update_count: int, agent=None):
        if len(batch) == 0:
            return
        # --- n-step preprocessing: only transitions whose horizon is complete are stored this call;
        # the rest wait in _nstep_pending until the worker's next chunk arrives (a few seconds). ---
        if N_STEP_RETURN > 1 and agent is not None:
            batch = self._nstep_process(batch, agent)
        batch_size = len(batch)
        if batch_size == 0:
            return

        pre_states_t = torch.from_numpy(np.array([e['pre_state'] for e in batch], dtype=np.float32)).to(self.device)
        states_t = torch.from_numpy(np.array([e['state'] for e in batch], dtype=np.float32)).to(self.device)
        actions_t = torch.from_numpy(np.array([e['action'] for e in batch], dtype=np.float32)).to(self.device)
        rewards_t = torch.from_numpy(np.array([e['reward'] for e in batch], dtype=np.float32)).to(self.device)
        next_states_t = torch.from_numpy(np.array([e['next_state'] for e in batch], dtype=np.float32)).to(self.device)
        dones_t = torch.from_numpy(np.array([[float(e['done'])] for e in batch], dtype=np.float32)).to(self.device)
        action_queue_t = torch.from_numpy(np.array([e['action_queue'] for e in batch], dtype=np.float32)).to(self.device)
        action_queue_next_t = torch.from_numpy(np.array([e['action_queue_next'] for e in batch], dtype=np.float32)).to(self.device)
        metadata_list = [e.get('env_metadata', '') for e in batch]

        if self.use_boxes:
            # Each e['boxes'] / e['next_boxes'] is a fixed [MAX_BOX_TOKENS, BOX_COL_DIM] nested list
            # (zeros-padded, last col = class id 0 for pad). Tolerate a missing/empty key as an empty scene.
            def _stack_boxes(key):
                arr = np.zeros((batch_size, MAX_BOX_TOKENS, BOX_COL_DIM), dtype=np.float16)
                for i, e in enumerate(batch):
                    b = e.get(key)
                    if b:
                        b = np.asarray(b, dtype=np.float16)
                        n = min(b.shape[0], MAX_BOX_TOKENS)
                        arr[i, :n] = b[:n]
                return torch.from_numpy(arr).to(self.device)
            boxes_t = _stack_boxes('boxes')
            next_boxes_t = _stack_boxes('next_boxes')

        if self.use_route:
            # [ROUTE_DIM] per transition; a missing key becomes zeros (the route adapter is a no-op).
            def _stack_route(key):
                arr = np.zeros((batch_size, ROUTE_DIM), dtype=np.float32)
                for i, e in enumerate(batch):
                    r = e.get(key)
                    if r:
                        arr[i] = np.asarray(r, dtype=np.float32).reshape(-1)[:ROUTE_DIM]
                return torch.from_numpy(arr).to(self.device)
            route_t = _stack_route('route_scalars')
            next_route_t = _stack_route('next_route_scalars')

        burnin_t = burnin_m_t = bridge_t = bridge_m_t = None
        cost_burnin_t = cost_burnin_m_t = cost_state_t = cost_route_t = cost_valid_t = None
        if self.burnin_cur is not None:
            def _stack_burnin(key, length):
                arr = np.zeros((batch_size, length, RSSM_BURNIN_FEAT), dtype=np.float16)
                msk = np.zeros((batch_size, length), dtype=np.float16)
                for i, e in enumerate(batch):
                    for j, f in enumerate((e.get(key) or [])[:length]):
                        if f is None:
                            continue
                        rt = f.get('route_scalars')
                        route_np = (np.asarray(rt, dtype=np.float32).reshape(-1)[:ROUTE_DIM]
                                    if rt else np.zeros(ROUTE_DIM, dtype=np.float32))
                        if route_np.shape[0] < ROUTE_DIM:
                            route_np = np.pad(route_np, (0, ROUTE_DIM - route_np.shape[0]))
                        arr[i, j, :STATE_DIM] = np.asarray(f['state'], dtype=np.float32)
                        arr[i, j, STATE_DIM:RSSM_OBS_DIM] = route_np
                        arr[i, j, RSSM_OBS_DIM:] = np.asarray(f['action'], dtype=np.float32)
                        msk[i, j] = 1.0
                return (torch.from_numpy(arr).to(self.device),
                        torch.from_numpy(msk).to(self.device))
            burnin_t, burnin_m_t = _stack_burnin('burnin_cur', RSSM_BURNIN_L)
            bridge_t, bridge_m_t = _stack_burnin('burnin_bridge', max(N_STEP_RETURN - 1, 0))
            cost_burnin_t, cost_burnin_m_t = _stack_burnin('cost_burnin', RSSM_BURNIN_L)
            cost_state_np = np.zeros((batch_size, STATE_DIM), dtype=np.float16)
            cost_route_np = np.zeros((batch_size, ROUTE_DIM), dtype=np.float16)
            cost_valid_np = np.zeros(batch_size, dtype=np.bool_)
            for i, e in enumerate(batch):
                if not e.get('cost_landing_valid', False):
                    continue
                cost_state_np[i] = np.asarray(e['cost_next_state'], dtype=np.float16)
                cr = e.get('cost_next_route_scalars')
                if cr:
                    cost_route_np[i] = np.asarray(cr, dtype=np.float16).reshape(-1)[:ROUTE_DIM]
                cost_valid_np[i] = True
            cost_state_t = torch.from_numpy(cost_state_np).to(self.device)
            cost_route_t = torch.from_numpy(cost_route_np).to(self.device)
            cost_valid_t = torch.from_numpy(cost_valid_np).to(self.device)

        # --- Route each transition to a partition (collision OR cost > threshold => unsafe) ---
        cost_log_dict = None
        with torch.no_grad():
            if rewards_t.shape[1] > 10:
                collision_flag = rewards_t[:, 10].round() >= 1.0
            else:
                collision_flag = rewards_t[:, COLLISION_REWARD_INDEX] > 0.5
            if agent is not None:
                task_r_t, cost_t, cost_log_dict = agent.calculate_reward(rewards_t, actions_t)
                speed_t = rewards_t[:, 6].clamp(min=0.0)
                agent.update_online_cost_ema(cost_t.mean().item(), speed_t.mean().item(), cost_t.shape[0])
                # n-step scalar targets (precomputed in _nstep_process); the 1-step fallback folds
                # the terminal absorbing cost in here instead.
                if N_STEP_RETURN > 1:
                    nstep_r_t = torch.tensor([[float(e['nstep_reward'])] for e in batch], dtype=torch.float32, device=self.device)
                    nstep_c_t = torch.tensor([[float(e['nstep_cost'])] for e in batch], dtype=torch.float32, device=self.device)
                    nstep_n_t = torch.tensor([[float(e['nstep_n'])] for e in batch], dtype=torch.float32, device=self.device)
                    # Cost-channel done: exact-return-to-terminal transitions must not bootstrap
                    # (missing key = pre-lookahead producer -> fall back to the reward-channel done).
                    nstep_cd_t = torch.tensor([[float(e.get('nstep_cost_done', e['done']))] for e in batch], dtype=torch.float32, device=self.device)
                    # Distance leg of the CMDP surrogate (missing key = pre-surrogate producer -> 0,
                    # which just makes that row's distance credit vanish, never negative).
                    nstep_d_t = torch.tensor([[float(e.get('nstep_dist', 0.0))] for e in batch], dtype=torch.float32, device=self.device)
                    # simply not engage on that row (safe default, never a spurious 9x price).
                    nstep_s2t_t = torch.tensor([[float(e.get('nstep_s2t', NSTEP_S2T_NONE))] for e in batch], dtype=torch.float32, device=self.device)
                else:
                    nstep_r_t = task_r_t
                    nstep_c_t = cost_t + dones_t * (cost_t / (1.0 - agent.gamma_cost))
                    nstep_n_t = torch.ones((batch_size, 1), dtype=torch.float32, device=self.device)
                    nstep_cd_t = dones_t.clone()
                    nstep_d_t = speed_t.unsqueeze(-1).clone()   # 1-step fallback: D^(1) = max(v,0)
                    # 1-step fallback: a terminal row IS the terminal (s2t=0), everything else far.
                    nstep_s2t_t = torch.where(dones_t > 0.5, torch.zeros_like(dones_t),
                                              torch.full_like(dones_t, NSTEP_S2T_NONE))
                unsafe_mask = collision_flag | (nstep_c_t.squeeze(-1) > UNSAFE_COST_THRESHOLD)
            else:
                nstep_r_t = torch.zeros((batch_size, 1), dtype=torch.float32, device=self.device)
                nstep_c_t = torch.zeros((batch_size, 1), dtype=torch.float32, device=self.device)
                nstep_n_t = torch.ones((batch_size, 1), dtype=torch.float32, device=self.device)
                nstep_cd_t = dones_t.clone()
                nstep_d_t = torch.zeros((batch_size, 1), dtype=torch.float32, device=self.device)
                nstep_s2t_t = torch.full((batch_size, 1), NSTEP_S2T_NONE, dtype=torch.float32, device=self.device)
                unsafe_mask = collision_flag
        safe_src = torch.nonzero(~unsafe_mask, as_tuple=False).squeeze(1)
        unsafe_src = torch.nonzero(unsafe_mask, as_tuple=False).squeeze(1)

        # --- Allocate destination slots in each partition ---
        safe_dst, self.safe_ptr, self.safe_size = self._alloc_slots(
            safe_src.numel(), 0, self.cap_safe, self.safe_ptr, self.safe_size, self.priorities_reward)
        unsafe_dst, self.unsafe_ptr, self.unsafe_size = self._alloc_slots(
            unsafe_src.numel(), self.cap_safe, self.cap_unsafe, self.unsafe_ptr, self.unsafe_size, self.priorities_cost)

        dst = torch.cat([safe_dst, unsafe_dst])
        src = torch.cat([safe_src, unsafe_src])
        if dst.numel() == 0:
            return

        # --- Write data (reordered by src so dst<->source align) ---
        self.states[dst] = states_t[src]
        self.actions[dst] = actions_t[src]
        self.rewards[dst] = rewards_t[src]
        self.next_states[dst] = next_states_t[src]
        if self.use_boxes:
            self.boxes[dst] = boxes_t[src]
            self.next_boxes[dst] = next_boxes_t[src]
        if self.use_route:
            self.route_scalars[dst] = route_t[src]
            self.next_route_scalars[dst] = next_route_t[src]
        if self.burnin_cur is not None:
            self.burnin_cur[dst] = burnin_t[src]
            self.burnin_cur_mask[dst] = burnin_m_t[src]
            self.burnin_bridge[dst] = bridge_t[src]
            self.burnin_bridge_mask[dst] = bridge_m_t[src]
            # Safe destinations are exactly the prefix [0, cap_safe); do not index the compact
            # cost arrays with unsafe global slots.
            if safe_dst.numel() > 0:
                self.cost_next_states[safe_dst] = cost_state_t[safe_src]
                self.cost_next_routes[safe_dst] = cost_route_t[safe_src]
                self.cost_burnin[safe_dst] = cost_burnin_t[safe_src]
                self.cost_burnin_mask[safe_dst] = cost_burnin_m_t[safe_src]
                self.cost_landing_valid[safe_dst] = cost_valid_t[safe_src]
                self.safety_cache_ids[safe_dst] = -1
                self.safety_cache_updates[safe_dst] = -10**9
        self.dones[dst] = dones_t[src]
        self.nstep_rewards[dst] = nstep_r_t[src]
        self.nstep_costs[dst] = nstep_c_t[src]
        self.nstep_dists[dst] = nstep_d_t[src]
        self.nstep_s2t[dst] = nstep_s2t_t[src]
        self.nstep_ns[dst] = nstep_n_t[src]
        self.nstep_cost_dones[dst] = nstep_cd_t[src]
        self.priorities_reward[dst] = self.max_priority_reward
        self.priorities_cost[dst] = self.max_priority_cost
        self.ages[dst] = agent_update_count

        new_ids = torch.arange(self.id_counter, self.id_counter + dst.numel(), device=self.device, dtype=torch.int64)
        self.transition_ids[dst] = new_ids
        self.id_counter += int(dst.numel())
        if self.safety_refresh_queue is not None and safe_dst.numel() > 0:
            # New data gets its imagined tail before replay. Queue stores transition ID so an
            # eviction while work is pending invalidates it safely.
            self.safety_refresh_queue.extend(zip(
                safe_dst.detach().cpu().tolist(),
                self.transition_ids[safe_dst].detach().cpu().tolist()))

        meta_np = np.array(metadata_list, dtype=object)
        self.env_metadata[dst.cpu().numpy()] = meta_np[src.cpu().numpy()]

        # --- Logging (scenario distribution + incoming reward/cost + partition sizes) ---
        valid_incoming = [m for m in metadata_list if m]
        self.seen_class_counts.update(valid_incoming)
        table = wandb.Table(data=[[c, n] for c, n in self.seen_class_counts.items()],
                            columns=["Scenario Class", "Total Frames Seen"])
        class_bar_chart = wandb.plot.bar(table, "Scenario Class", "Total Frames Seen", title="All-Time Scenario Distribution")
        log_payload = {
            "Buffer/Safe_Size": float(self.safe_size),
            "Buffer/Unsafe_Size": float(self.unsafe_size),
            "Buffer/Unsafe_Incoming_Fraction": unsafe_mask.float().mean().item(),
            "Buffer/Unsafe_Sample_Frac": float(self.live_unsafe_frac),
            "Incoming_Reward/All_Time_Classes": class_bar_chart,
        }
        if cost_log_dict is not None:
            for k, v in cost_log_dict.items():
                log_payload[f"Incoming_Reward/{k}"] = v
        run_wandb.log(log_payload)

    def _prefetch_worker(self, batch_size):
        while not self.stop_event.is_set():
            if len(self) < UPER_CANDIDATE_SET_SIZE or self.prefetch_queue.full():
                time.sleep(0.05)
                continue
            try:
                self._prefetch_once(batch_size)
            except Exception as e:
                # A dead prefetch thread hangs the learner forever at the next sample() with a
                # live-looking process; log loudly and keep the thread alive instead.
                print(f"❌ [StratifiedReplayBuffer] Prefetch iteration failed: {e!r}. Retrying in 1s.")
                time.sleep(1.0)

    def _prefetch_once(self, batch_size):
            with torch.no_grad():
                total = self.safe_size + self.unsafe_size
                unsafe_frac = min(UNSAFE_FRAC_MAX,
                                  max(UNSAFE_FRAC_MIN, UNSAFE_REPLAY_BOOST * self.unsafe_size / max(total, 1)))
                self.live_unsafe_frac = unsafe_frac if self.unsafe_size > 0 else 0.0
                num_unsafe = int(UPER_CANDIDATE_SET_SIZE * unsafe_frac)
                num_safe = UPER_CANDIDATE_SET_SIZE - num_unsafe
                if self.unsafe_size == 0:
                    # No unsafe data yet: top the candidate pool up entirely from the safe partition.
                    num_safe, num_unsafe = UPER_CANDIDATE_SET_SIZE, 0
                elif self.safe_size == 0:
                    # (Defensive) only unsafe data so far: draw it all from the unsafe partition.
                    num_safe, num_unsafe = 0, UPER_CANDIDATE_SET_SIZE

                cand = []
                if num_safe > 0:
                    pri_safe = self.priorities_reward[:self.safe_size].pow(UPER_ALPHA) + UPER_EPSILON
                    cand.append(torch.multinomial(pri_safe, num_samples=num_safe, replacement=True)) # global (offset 0)
                if num_unsafe > 0:
                    pri_unsafe = self.priorities_cost[self.cap_safe:self.cap_safe + self.unsafe_size].pow(UPER_ALPHA) + UPER_EPSILON
                    cand.append(self.cap_safe + torch.multinomial(pri_unsafe, num_samples=num_unsafe, replacement=True))
                candidate_indices = torch.cat(cand)

                candidate_states = self.states[candidate_indices]
                candidate_states_norm = candidate_states / (torch.linalg.norm(candidate_states, dim=1, keepdim=True) + 1e-8)
                anchor_indices = torch.randperm(UPER_CANDIDATE_SET_SIZE, device=self.device)[:DIVERSITY_ANCHORS]
                anchor_features = candidate_states_norm[anchor_indices]
                similarities = torch.matmul(candidate_states_norm, anchor_features.T)
                max_similarities, _ = torch.max(similarities, dim=1)
                # Batch quotas mirror the candidate-pool composition (candidate_indices is
                # ordered [safe..., unsafe...] by construction above).
                n_unsafe_batch = min(num_unsafe, int(round(batch_size * num_unsafe / UPER_CANDIDATE_SET_SIZE)))
                n_safe_batch = batch_size - n_unsafe_batch
                if n_safe_batch > num_safe:  # defensive: pool is mostly/entirely unsafe
                    n_safe_batch = num_safe
                    n_unsafe_batch = batch_size - n_safe_batch
                # --- NEVER-SAMPLED QUOTA (see NEW_ENTRY_BATCH_QUOTA) ------------------
                forced = None
                if NEW_ENTRY_BATCH_QUOTA > 0 and n_safe_batch > 0:
                    cand_safe = candidate_indices[:num_safe]
                    is_new = self.priorities_reward[cand_safe] >= self.max_priority_reward
                    new_pos = torch.nonzero(is_new, as_tuple=False).squeeze(-1)
                    if new_pos.numel() > 0:
                        # de-duplicate: the pool is drawn WITH replacement, so one hot new row can
                        # otherwise consume the whole quota.
                        uniq = torch.unique(cand_safe[new_pos])
                        take = min(int(NEW_ENTRY_BATCH_QUOTA), uniq.numel(), n_safe_batch)
                        if take > 0:
                            forced = uniq[:take]
                            n_safe_batch -= take

                elite = []
                elite_quota = min(int(PRIORITY_ELITE_BATCH_QUOTA),
                                  n_safe_batch + n_unsafe_batch)
                elite_unsafe_quota = min(
                    n_unsafe_batch,
                    int(round(elite_quota * n_unsafe_batch
                              / max(n_safe_batch + n_unsafe_batch, 1))))
                elite_safe_quota = min(n_safe_batch, elite_quota - elite_unsafe_quota)

                if elite_safe_quota > 0:
                    cand_safe_updated = cand_safe[
                        self.priorities_reward[cand_safe] < self.max_priority_reward]
                    uniq_safe = torch.unique(cand_safe_updated)
                    if forced is not None and uniq_safe.numel() > 0:
                        uniq_safe = uniq_safe[~torch.isin(uniq_safe, forced)]
                    take = min(elite_safe_quota, int(uniq_safe.numel()))
                    if take > 0:
                        elite_safe = uniq_safe[torch.topk(
                            self.priorities_reward[uniq_safe], k=take).indices]
                        elite.append(elite_safe)
                        n_safe_batch -= take

                if elite_unsafe_quota > 0:
                    cand_unsafe = candidate_indices[num_safe:]
                    cand_unsafe_updated = cand_unsafe[
                        self.priorities_cost[cand_unsafe] < self.max_priority_cost]
                    uniq_unsafe = torch.unique(cand_unsafe_updated)
                    take = min(elite_unsafe_quota, int(uniq_unsafe.numel()))
                    if take > 0:
                        elite_unsafe = uniq_unsafe[torch.topk(
                            self.priorities_cost[uniq_unsafe], k=take).indices]
                        elite.append(elite_unsafe)
                        n_unsafe_batch -= take

                elite = torch.cat(elite) if elite else None

                picks = []
                if n_safe_batch > 0:
                    safe_scores = max_similarities[:num_safe].clone()
                    protected = elite
                    if forced is not None:
                        protected = forced if protected is None else torch.cat([protected, forced])
                    if protected is not None:
                        safe_scores[torch.isin(candidate_indices[:num_safe], protected)] = torch.inf
                    _, top_safe = torch.topk(safe_scores, k=n_safe_batch, largest=False)
                    picks.append(top_safe)
                if n_unsafe_batch > 0:
                    unsafe_scores = max_similarities[num_safe:].clone()
                    if elite is not None:
                        unsafe_scores[
                            torch.isin(candidate_indices[num_safe:], elite)] = torch.inf
                    _, top_unsafe = torch.topk(unsafe_scores, k=n_unsafe_batch, largest=False)
                    picks.append(top_unsafe + num_safe)
                final_indices = candidate_indices[torch.cat(picks)] if picks else \
                    torch.empty(0, dtype=torch.long, device=self.device)
                if forced is not None:
                    final_indices = torch.cat([final_indices, forced])
                if elite is not None:
                    final_indices = torch.cat([final_indices, elite])
                self.last_forced_new = 0 if forced is None else int(forced.numel())
                self.last_priority_elite = 0 if elite is None else int(elite.numel())

                is_weight = torch.ones((batch_size, 1), device=self.device)
                burn_next = burn_next_mask = None
                cost_state = cost_route = cost_burn = cost_burn_mask = cost_valid = None
                cache_tail = cache_ids = cache_updates = None
                if self.burnin_cur is not None:
                    route_now = (self.route_scalars[final_indices] if self.use_route else
                                 torch.zeros((batch_size, ROUTE_DIM), device=self.device))
                    frame_now = torch.cat([self.states[final_indices], route_now,
                                           self.actions[final_indices]], dim=-1).half().unsqueeze(1)
                    tail = torch.cat([frame_now, self.burnin_bridge[final_indices]], dim=1)
                    tail_mask = torch.cat([
                        torch.ones((batch_size, 1), dtype=torch.float16, device=self.device),
                        self.burnin_bridge_mask[final_indices]], dim=1)
                    joined = torch.cat([self.burnin_cur[final_indices], tail], dim=1)
                    joined_m = torch.cat([self.burnin_cur_mask[final_indices], tail_mask], dim=1)
                    shift = self.nstep_ns[final_indices].long().clamp(1, N_STEP_RETURN)
                    gi = shift + torch.arange(RSSM_BURNIN_L, device=self.device).view(1, -1)
                    gi3 = gi.unsqueeze(-1).expand(-1, -1, RSSM_BURNIN_FEAT)
                    burn_next = torch.gather(joined, 1, gi3)
                    burn_next_mask = torch.gather(joined_m, 1, gi)

                    safe_f = final_indices < self.cap_safe
                    cost_state = torch.zeros((batch_size, STATE_DIM), dtype=torch.float16,
                                             device=self.device)
                    cost_route = torch.zeros((batch_size, ROUTE_DIM), dtype=torch.float16,
                                             device=self.device)
                    cost_burn = torch.zeros((batch_size, RSSM_BURNIN_L, RSSM_BURNIN_FEAT),
                                            dtype=torch.float16, device=self.device)
                    cost_burn_mask = torch.zeros((batch_size, RSSM_BURNIN_L),
                                                 dtype=torch.float16, device=self.device)
                    cost_valid = torch.zeros(batch_size, dtype=torch.bool, device=self.device)
                    cache_tail = torch.zeros((batch_size, self.safety_cache.shape[1]),
                                             dtype=torch.float16, device=self.device)
                    cache_ids = torch.full((batch_size,), -1, dtype=torch.int64, device=self.device)
                    cache_updates = torch.full((batch_size,), -10**9, dtype=torch.int64,
                                               device=self.device)
                    if safe_f.any():
                        bi = torch.nonzero(safe_f, as_tuple=False).squeeze(1)
                        si = final_indices[bi]
                        cost_state[bi] = self.cost_next_states[si]
                        cost_route[bi] = self.cost_next_routes[si]
                        cost_burn[bi] = self.cost_burnin[si]
                        cost_burn_mask[bi] = self.cost_burnin_mask[si]
                        cost_valid[bi] = self.cost_landing_valid[si]
                        cache_tail[bi] = self.safety_cache[si]
                        cache_ids[bi] = self.safety_cache_ids[si]
                        cache_updates[bi] = self.safety_cache_updates[si]
                sample_data = (
                    self.states[final_indices],  # pre_state placeholder; no persistent copy
                    self.states[final_indices],
                    self.actions[final_indices],
                    self.rewards[final_indices],
                    self.next_states[final_indices],
                    self.dones[final_indices],
                    None,
                    None,
                    is_weight,
                    is_weight.clone(),
                    # Privileged box tokens appended at the END (kept fp16; cast to fp32 in update()).
                    self.boxes[final_indices] if self.use_boxes else None,
                    self.next_boxes[final_indices] if self.use_boxes else None,
                    # Route scalars (s, s') appended after boxes.
                    self.route_scalars[final_indices] if self.use_route else None,
                    self.next_route_scalars[final_indices] if self.use_route else None,
                    # n-step scalar targets appended LAST (update() unpacks the first 14 positionally
                    # and treats these as optional extras, so other buffers stay compatible).
                    self.nstep_rewards[final_indices],
                    self.nstep_costs[final_indices],
                    self.nstep_ns[final_indices],
                    self.nstep_cost_dones[final_indices],
                    # RSSM burn-in windows + masks (positions 18-21): fp16 (state, route, action)
                    # frames preceding s_t and s_{t+n}. None when burn-in is off -> zero-h belief.
                    self.burnin_cur[final_indices] if self.burnin_cur is not None else None,
                    burn_next,
                    self.burnin_cur_mask[final_indices] if self.burnin_cur is not None else None,
                    burn_next_mask,
                    # n-step DISTANCE target (position 22): appended after the burn-in block so no
                    # existing positional index moves. See nstep_dists / DIST_CREDIT_ENABLED.
                    self.nstep_dists[final_indices],
                    # Steps-to-terminal (position 23, appended LAST): actor cost gate only.
                    self.nstep_s2t[final_indices],
                    # Cost-specific t+30 landing and cache (positions 24-30).
                    cost_state, cost_route, cost_burn, cost_burn_mask, cost_valid,
                    cache_tail, cache_ids, cache_updates,
                )
                original_ids = self.transition_ids[final_indices]
                self.prefetch_queue.put((sample_data, final_indices, original_ids))

    def sample(self, batch_size, agent_update_count: int):
        if len(self) < UPER_CANDIDATE_SET_SIZE:
            return None, None, None
        self.beta_is = min(1.0, self.beta_is + 2e-6)
        return self.prefetch_queue.get()

    def update_priorities(self, indices: torch.Tensor, original_ids: torch.Tensor,
                          priorities_r: torch.Tensor, priorities_c: torch.Tensor):
        """Version-checked priority write over the single global index space (same as GpuReplayBuffer)."""
        with torch.no_grad():
            current_ids_in_buffer = self.transition_ids[indices]
            mask = (current_ids_in_buffer == original_ids)
            valid_indices = indices[mask]

            EPS = 1e-6
            priorities_r = torch.nan_to_num(priorities_r, nan=0.0, posinf=1e6, neginf=0.0).abs() + EPS
            valid_priorities_r = priorities_r.squeeze(-1)[mask]
            if valid_indices.numel() > 0:
                self.priorities_reward[valid_indices] = valid_priorities_r
                self.max_priority_reward = max(self.max_priority_reward, valid_priorities_r.max().item())

            priorities_c = torch.nan_to_num(priorities_c, nan=0.0, posinf=1e6, neginf=0.0).abs() + EPS
            valid_priorities_c = priorities_c.squeeze(-1)[mask]
            if valid_indices.numel() > 0:
                self.priorities_cost[valid_indices] = valid_priorities_c
                self.max_priority_cost = max(self.max_priority_cost, valid_priorities_c.max().item())

    def reset_priorities_and_ages(self):
        if len(self) == 0: return
        print("✨ Resetting stratified buffer priorities and ages for new agent.")
        cs = self.cap_safe
        self.priorities_reward[:self.safe_size] = self.max_priority_reward
        self.priorities_cost[:self.safe_size] = self.max_priority_cost
        self.ages[:self.safe_size] = 0
        self.priorities_reward[cs:cs + self.unsafe_size] = self.max_priority_reward
        self.priorities_cost[cs:cs + self.unsafe_size] = self.max_priority_cost
        self.ages[cs:cs + self.unsafe_size] = 0

    def save_to_disk(self, save_path=None):
        target_path = save_path if save_path else self.save_path
        temp_path = target_path + ".tmp"
        if len(self) == 0: return

        cs = self.cap_safe
        data = {
            'safe_size': self.safe_size, 'unsafe_size': self.unsafe_size,
            'safe_ptr': self.safe_ptr, 'unsafe_ptr': self.unsafe_ptr,
            'cap_safe': self.cap_safe, 'cap_unsafe': self.cap_unsafe,
            'id_counter': self.id_counter, 'seen_class_counts': self.seen_class_counts,
            # Without these, a resume resets the ceilings to 100 while restored priorities are
            # on the ~0.01 scale -> new data out-samples the restored buffer by ~10^3-10^4x.
            'max_priority_reward': float(self.max_priority_reward),
            'max_priority_cost': float(self.max_priority_cost),
        }
        for f in self._field_names:
            t = getattr(self, f)
            data[f + '_safe'] = t[:self.safe_size].cpu().numpy()
            data[f + '_unsafe'] = t[cs:cs + self.unsafe_size].cpu().numpy()
        data['env_metadata_safe'] = self.env_metadata[:self.safe_size]
        data['env_metadata_unsafe'] = self.env_metadata[cs:cs + self.unsafe_size]

        print(f"💾 Saving stratified buffer (safe {self.safe_size}, unsafe {self.unsafe_size}) to {target_path}...")
        try:
            with open(temp_path, 'wb') as fh:
                pickle.dump(data, fh)
            os.replace(temp_path, target_path)
            print("💾 Save complete.")
        except Exception as e:
            print(f"❌ Error saving stratified buffer: {e}")

    def load_from_disk(self):
        if not os.path.exists(self.save_path):
            print("💾 No buffer file found. Starting fresh.")
            return
        print(f"💾 Loading stratified buffer from {self.save_path}...")
        try:
            with open(self.save_path, 'rb') as fh:
                data = pickle.load(fh)
            if 'safe_size' not in data:
                print("⚠️ Buffer file is not in stratified format (pre-CMDP). Starting fresh.")
                return
            cs = self.cap_safe
            safe_size = min(int(data['safe_size']), self.cap_safe)
            unsafe_size = min(int(data['unsafe_size']), self.cap_unsafe)
            for f in self._field_names:
                if f + '_safe' not in data:
                    print(f"⚠️ Buffer file missing '{f}'; leaving it at its constructor default.")
                    continue
                t = getattr(self, f)
                t[:safe_size] = torch.from_numpy(data[f + '_safe'][:safe_size]).to(self.device, dtype=t.dtype)
                t[cs:cs + unsafe_size] = torch.from_numpy(data[f + '_unsafe'][:unsafe_size]).to(self.device, dtype=t.dtype)
            if 'nstep_cost_dones_safe' not in data:
                self.nstep_cost_dones.copy_(self.dones)
                print("⚠️ Buffer file predates nstep_cost_dones; defaulted it to `dones` (legacy cost-target semantics).")
            self.env_metadata[:safe_size] = data['env_metadata_safe'][:safe_size]
            self.env_metadata[cs:cs + unsafe_size] = data['env_metadata_unsafe'][:unsafe_size]
            self.safe_size, self.unsafe_size = safe_size, unsafe_size
            self.safe_ptr = (int(data['safe_ptr']) % self.cap_safe) if self.cap_safe else 0
            self.unsafe_ptr = (int(data['unsafe_ptr']) % self.cap_unsafe) if self.cap_unsafe else 0
            self.id_counter = data.get('id_counter', 0)
            self.seen_class_counts = data.get('seen_class_counts', Counter())
            # Fall back to the max of the restored priorities so the ceiling stays consistent
            # with the data.
            self.max_priority_reward = float(data.get('max_priority_reward',
                max(1e-2, self.priorities_reward[:safe_size].max().item() if safe_size else 1e-2)))
            self.max_priority_cost = float(data.get('max_priority_cost',
                max(1e-2, self.priorities_cost[cs:cs + unsafe_size].max().item() if unsafe_size else 1e-2)))
            print(f"💾 Stratified buffer loaded. Safe {self.safe_size}, Unsafe {self.unsafe_size}.")
        except Exception as e:
            print(f"❌ Error loading stratified buffer: {e}. Starting fresh.")
            self.safe_size = self.unsafe_size = 0
            self.safe_ptr = self.unsafe_ptr = 0

    def close(self):
        print("🛑 [StratifiedReplayBuffer] Stopping prefetching worker...")
        self.stop_event.set()
        while not self.prefetch_queue.empty():
            try:
                self.prefetch_queue.get_nowait()
            except queue.Empty:
                continue
        self.prefetch_thread.join(timeout=2)
        print("✅ [StratifiedReplayBuffer] Prefetching worker stopped.")


def calculate_dynamic_sleep_time(current_sleep_time, integral_error, updates_in_window, experiences_in_window):
    """
    Calculates the new sleep time using a PI controller on the LOGARITHM 
    of the UTD ratio to match the TARGET_UTD_RATIO.
    """
    if experiences_in_window == 0:
        # No new data, no adjustment needed.
        return current_sleep_time, integral_error

    # Add a small epsilon to prevent log(0) errors
    epsilon = 1e-6
    actual_utd = updates_in_window / experiences_in_window

    # --- PI controller operating on the log of the ratios ---
    log_target_utd = np.log(TARGET_UTD_RATIO + epsilon)
    log_actual_utd = np.log(actual_utd + epsilon)
    
    error = log_target_utd - log_actual_utd
    integral_error += error
    
    # The adjustment is now in log-space
    adjustment = (UTD_KP * error) + (UTD_KI * integral_error)
    
    # Adjust the log of the sleep time
    log_current_sleep = np.log(current_sleep_time + epsilon)
    log_new_sleep = log_current_sleep - adjustment # Subtract: if we are below target (pos error), we need to sleep less
    
    # Convert back from log space to time
    new_sleep_time = np.exp(log_new_sleep) - epsilon
    
    # Clamp sleep time to a reasonable range to prevent instability
    new_sleep_time = max(0.0, min(new_sleep_time, 2.0))
    
    # Log the metrics for monitoring
    run_wandb.log({"utd_actual": actual_utd, "utd_log_error": error, "dynamic_sleep_time": new_sleep_time})
    print(f"🔧 [UTD Controller] Actual UTD: {actual_utd:.2f} | Target: {TARGET_UTD_RATIO} | New sleep time: {new_sleep_time:.4f}s")

    return new_sleep_time, integral_error

def run_learner():
    print("🧠 [Learner] Process started.")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"🧠 [Learner] Using device: {device}")

    shared_queue = mp.Queue()
    QueueManager.register('get_queue', callable=lambda: shared_queue)
    queue_manager = QueueManager(address=('', QUEUE_PORT), authkey=AUTH_KEY)
    queue_manager.start()
    print(f"🧠 [Learner] Shared queue exposed on port {QUEUE_PORT}.")

    global run_wandb
    if mp.current_process().name == 'MainProcess' and run_wandb is None:
        run_wandb = wandb.init(
            entity=os.environ.get("WANDB_ENTITY") or None,
            project=os.environ.get("WANDB_PROJECT", "greg-rl"),
            id=HARDCODED_RUN_ID,
            resume="allow",
            settings=wandb.Settings(code_dir=".")
        )

    if GPU_REPLAY_BUFFER and STRATIFIED_REPLAY_BUFFER:
        replay_buffer = StratifiedGpuReplayBuffer(REPLAY_BUFFER_CAPACITY, STATE_DIM, ACTION_DIM, batch_size=TRAINING_BATCH_SIZE)
    elif GPU_REPLAY_BUFFER:
        replay_buffer = GpuReplayBuffer(REPLAY_BUFFER_CAPACITY, STATE_DIM, ACTION_DIM, batch_size=TRAINING_BATCH_SIZE)
    else:
        replay_buffer = LearnerReplayBuffer(REPLAY_BUFFER_CAPACITY, batch_size=TRAINING_BATCH_SIZE)

    # the rare-event cost reservoir (would never refill live) and the main chunk ring
    seq_buffer = None
    if RSSM_ENABLED:
        seq_buffer = SequenceReplayBuffer()
        seq_buffer.load_reservoir()
        seq_buffer.load_ring()
        if hasattr(replay_buffer, 'seq_buffer'):
            replay_buffer.seq_buffer = seq_buffer
        else:
            print("⚠️ [Learner] RSSM_ENABLED but the active replay buffer has no seq_buffer hook "
                  "(only StratifiedGpuReplayBuffer ingests sequences) — world model will not train.")
        print(f"🌀 [Learner] RSSM Level-1 active: obs={RSSM_OBS_DIM}-d [emb+route], belief={RSSM_BELIEF_DIM}-d, "
              f"critic_in={STATE_DIM + RSSM_BELIEF_DIM}-d; MVE {'ON' if MVE_ENABLED else 'OFF'} "
              f"(horizon {MVE_HORIZON}, w={MVE_WEIGHT}, ramp {MVE_WARMUP_START}→{MVE_WARMUP_START + MVE_WARMUP_STEPS}).")

    agent = SACAgent(STATE_DIM, ACTION_DIM, run_wandb)


    if agent.update_count == 0:
        delete_generated_files(config_readds, START_TIME_FILE)
        save_current_time(START_TIME_FILE, TIME_FORMAT)
    start_time = get_start_time(START_TIME_FILE, TIME_FORMAT)

    if agent.update_count == 0 and len(replay_buffer) > 0:
        replay_buffer.reset_priorities_and_ages()

    # UTD Controller State Variables
    dynamic_sleep_time = SLEEP_INIT
    integral_error = 0.0
    last_adjustment_time = time.time()
    updates_since_adjustment = 0
    experiences_since_adjustment = 0
    
    last_buffer_save = time.time()
    last_model_save = time.time()
    last_versioned_save = time.time()
    

    config_readds['start_time'] = start_time
    run_id_ds = HARDCODED_RUN_ID
    synchronizer = FileSynchronizer(config_readds, run_id=run_id_ds)
    background_thread_ds = threading.Thread(target=synchronizer.start, daemon=True)
    background_thread_ds.start()
    print("File synchronizer has been started in the background.")

    
    print("🚀 Prefetch queue populated! Starting training loop.")

    while True:


        # Step 1: Drain the queue and count new experiences
        while not shared_queue.empty():
            experience_batch = shared_queue.get()
            experiences_since_adjustment += len(experience_batch)
            replay_buffer.add_batch(experience_batch, agent.update_count, agent=agent)

        if len(replay_buffer) > 10 * TRAINING_BATCH_SIZE:
            agent.update(replay_buffer, TRAINING_BATCH_SIZE, seq_buffer=seq_buffer)
            updates_since_adjustment += 1
            
            if agent.update_count % 100 == 0:
                print(f"🧠 [Learner] Updates: {agent.update_count} | Buffer: {len(replay_buffer)} | Sleep: {dynamic_sleep_time:.4f}s")
        else:
            time.sleep(1)

        # Step 3: Periodically adjust the sleep time to control UTD
        current_time = time.time()
        if current_time - last_adjustment_time > UTD_ADJUSTMENT_INTERVAL:
            dynamic_sleep_time, integral_error = calculate_dynamic_sleep_time(
                dynamic_sleep_time, integral_error, updates_since_adjustment, experiences_since_adjustment
            )
            # Reset for the next window
            updates_since_adjustment = 0
            experiences_since_adjustment = 0
            last_adjustment_time = current_time

        # Step 4: Dynamic sleep
        time.sleep(dynamic_sleep_time)

        # Saving logic remains the same
        current_time = time.time()
        if current_time - last_model_save > MODEL_SAVE_INTERVAL:
            agent.save_checkpoint(SAC_CHECKPOINT_FILE)
            agent.save_policy(LATEST_MODEL_FILE)
            last_model_save = current_time
        
        if current_time - last_versioned_save > VERSIONED_SAVE_INTERVAL_SECONDS:
            timestamp = time.strftime("%Y-%m-%d_%H-%M-%S")
            versioned_filepath = os.path.join(MODEL_DIR, f"sac_checkpoint_{timestamp}.pth")
            print(f"🧠 [Learner] Saving versioned backup checkpoint to {versioned_filepath}")
            agent.save_checkpoint(versioned_filepath)
            last_versioned_save = current_time
            
        if current_time - last_buffer_save > SAVE_INTERVAL_SECONDS:
            replay_buffer.save_to_disk()
            if seq_buffer is not None:
                seq_buffer.save_reservoir()   # rare-event chunks (would never refill live)
                seq_buffer.save_ring()        # main ring: ~140 MB fp16, negligible next to the 8.7 GB buffer dump
            last_buffer_save = current_time

if __name__ == '__main__':
    run_learner()
